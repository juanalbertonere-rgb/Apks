# Weaver Android — Agente funcional (Kotlin / Compose)

Esta versión convierte la app **100% funcional**, con la misma arquitectura del agente de Weaver PC (Tauri):

- Bucle **ReAct** completo (piensa → tool → observa → repite) con protocolo `RESULT:` / `STUCK:`, detección de bloqueo y modo **Perseguir**.
- **Provider LLM configurable**: OpenRouter, OpenAI, Ollama (LAN) o base URL propia — API key y modelo desde Ajustes (drawer → Ajustes).
- **Objetivo de ejecución** móvil/PC con el segmented control de arriba del chat (persistente).
- **Persistencia Room**: chats, mensajes (con tool_calls), memoria del agente, bitácora por chat, notas/tareas/eventos/listas/notebooks, tareas agendadas.
- **Widget interactivo `ask_user_input`** (opciones + texto libre + omitir) con reanudación que **sí lleva la respuesta al modelo** (mismo fix de reanudación con historial que el agente de PC).
- **Voz real**: STT continuo con `SpeechRecognizer` (modo voz del chat) y lectura de respuestas con TTS (Ajustes).
- **QR reales** (ZXing): el onboarding muestra el QR de emparejamiento del teléfono y escanea el QR de la PC. Exportar/importar chats por QR (multi-página) o archivo JSON.
- **MCP por HTTP**: agrega servidores streamable-HTTP en Ajustes; sus tools se registran solas en el agente.

## El cuerpo del agente en Android

| Capacidad PC (Tauri/AT-SPI) | Equivalente Android |
|---|---|
| `shell_exec` | `termux_exec` (Termux RUN_COMMAND, sin root) |
| abrir programas | `list_apps` / `open_app` |
| leer árbol AT-SPI | `screen_tree` / `screen_find` (AccessibilityService) |
| clic / doble clic / focus | `screen_click` / `screen_long_click` (gestos) |
| escribir | `screen_type` (SET_TEXT → portapapeles+pegar) |
| teclado | `screen_key` (atrás/home/recientes/notificaciones/ajustes rápidos) |
| scroll | `screen_scroll` (swipe) |
| — | `screen_zoom` (pellizco 2 dedos), `screen_swipe` (arrastre libre), `screen_screenshot` (Android 11+) |
| web_search / web_fetch | `web_search` (DuckDuckGo) / `web_fetch` |
| memoria / bitácora | `memory_save_fact` / `project_memory_save` (Room) |
| ME (notas, agenda, listas) | `me_create_note` / `me_create_task` / `me_create_event` / `me_add_shopping` / `me_list` … |
| MCP | `mcp__<server>__<tool>` (HTTP streamable) |

## Configuración inicial (5 pasos)

1. **Proveedor LLM** — Drawer → *Ajustes* → Proveedor: pega tu API key (OpenRouter por defecto), elige/ajusta el modelo y la base URL. Ollama no necesita key (usa `http://IP-DE-TU-PC:11434/v1`).
2. **Accesibilidad** — Ajustes → *Cuerpo del agente* → activar "Servicio de accesibilidad de Weaver" (Ajustes del sistema → Accesibilidad → Weaver). Sin esto, las tools `screen_*` fallan con mensaje claro.
3. **Termux** — Instala Termux (F-Droid o GitHub, no Play Store) → Ajustes → concedes permiso **RUN_COMMAND** (Ajustes del sistema → Apps → Weaver → Permisos) → dentro de Termux ejecuta `termux-setup-storage` (acepta el diálogo). El intercambio vive en `/sdcard/Weaver/intercambio`.
4. **Almacenamiento** — Ajustes → concede "Todos los archivos" para leer la salida de Termux.
5. **Opcional — Modo PC** — en la PC: `node pc-bridge/weaver-bridge.mjs` (Node 18+). Escanea el QR del bridge desde la app (Ajustes → Emparejamiento → *Escanear QR PC*) y el segmented control quedará en modo PC. Para emparejar también en sentido PC→teléfono, activa "Servidor local" y corre en la PC: `node weaver-bridge.mjs --link "weaver://phone?..."` (el payload del QR del teléfono).

### Config del bridge de la PC (`.env` junto al script o variables de entorno)

```
WEAVER_LLM_BASE=https://openrouter.ai/api/v1
WEAVER_LLM_KEY=sk-or-...
WEAVER_LLM_MODEL=openrouter/auto
```

El bridge ejecuta en la PC: `shell_exec` (bash/PowerShell), `file_read`, `file_write`, `list_dir`, `web_fetch`, `web_search` — y transmite cada evento por SSE al chat del teléfono.

## Cómo probar que todo funciona

- *"Usa tu herramienta ask_user_input para preguntarme algo aleatorio"* → widget → responde → el modelo **sí** recibe tu respuesta (con historial completo).
- *"Ejecuta uname -a en Termux y dime la arquitectura"* → `termux_exec` real.
- *"Abre la calculadora, escribe 12*7 y dime el resultado"* → `open_app` + `screen_tree` + `screen_click`/`screen_type` + `screen_tree` para leer.
- *"Guarda: mi color favorito es azul"* → memoria persistente; en otro chat *"¿cuál es mi color favorito?"*.
- *"En MI apunta una nota: comprar café"* → aparece en Complementos/Notebooks.
- Ajustes → crea una tarea en Schedules → al llegar la hora, el agente la ejecuta en un chat nuevo.

## Notas técnicas

- JSON con `org.json` (sin codegen), streaming SSE con OkHttp, QR con ZXing core, Room con KSP, Compose M3.
- `RUN_COMMAND` de Termux: la salida se recupera por archivos de intercambio (cero puentes de red), con timeout configurable (5–300 s) y limpieza automática.
- El `ask_user_input` es una *pause tool*: pausa la sesión (`awaiting_user_input`), persiste el tool call, y la reanudación reconstruye el prompt con system → historial (pregunta + tool call + tu respuesta) → objetivo (instrucción de continuación).
- Si ignoras el widget y mandas otro mensaje, el historial se **sanitiza** (tool_calls sin respuesta → texto descriptivo) para no romper la API del proveedor.
- Los servidores MCP caídos no tumban el agente: se registra una tool de diagnóstico que reporta el fallo.

## Compilar

Android Studio (Ladybug+) → Open `App-weaver-main` → Sync → `Run`. Min SDK 24, Target 36. Si tu Studio no soporta AGP 9.1.1, baja `agp` en `gradle/libs.versions.toml` a la versión de tu instalación y ajusta `compileSdk`.
