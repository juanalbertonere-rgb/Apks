package com.example.agent.provider

import com.example.agent.core.LMessage
import com.example.agent.core.LToolCall
import com.example.agent.core.ToolDef
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Cliente LLM OpenAI-compatible con streaming SSE y function calling.
 * Sirve para OpenRouter, OpenAI, Ollama (/v1) o cualquier base URL propia.
 */
class LlmClient(
  private val baseUrl: String,
  private val apiKey: String?,
  private val providerId: String = "custom"
) {

  private val client: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(300, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()

  private var inFlight: Call? = null

  /** Chat streaming con tools. Lanza excepción con el mensaje del proveedor si falla. */
  suspend fun chatStream(
    model: String,
    messages: List<LMessage>,
    tools: List<ToolDef>,
    extraHeaders: Map<String, String> = emptyMap(),
    onTextDelta: suspend (String) -> Unit = {},
    onReasoningDelta: suspend (String) -> Unit = {}
  ): StreamResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
    val body = JSONObject().apply {
      put("model", model)
      put("stream", true)
      put("messages", JSONArray().apply { messages.forEach { put(it.toJson()) } })
      if (tools.isNotEmpty()) {
        put("tools", JSONArray().apply { tools.forEach { put(it.toJson()) } })
        put("tool_choice", "auto")
      }
      // Algunos servidores locales requieren esto para habilitar tools.
      put("parallel_tool_calls", false)
    }.toString()

    val reqBuilder = Request.Builder()
      .url(baseUrl.trimEnd('/') + "/chat/completions")
      .post(body.toRequestBody("application/json".toMediaType()))
    if (!apiKey.isNullOrBlank()) reqBuilder.header("Authorization", "Bearer $apiKey")
    if (providerId == "openrouter") {
      reqBuilder.header("HTTP-Referer", "https://weaver.app")
      reqBuilder.header("X-Title", "Weaver Android")
    }
    extraHeaders.forEach { (k, v) -> reqBuilder.header(k, v) }

    val call = client.newCall(reqBuilder.build())
    inFlight = call

    val text = StringBuilder()
    val reasoning = StringBuilder()
    val toolCalls = mutableListOf<ToolCallAcc>()

    call.execute().use { resp ->
      if (!resp.isSuccessful) {
        val errBody = runCatching { resp.body?.string() }.getOrNull()
        val msg = parseErrorMessage(errBody) ?: "HTTP ${resp.code}"
        throw LlmException(msg, resp.code)
      }
      val source = resp.body?.source() ?: throw LlmException("Respuesta vacía del proveedor", resp.code)

      while (true) {
        val line = source.readUtf8Line() ?: break
        if (!line.startsWith("data:")) continue
        val data = line.removePrefix("data:").trim()
        if (data == "[DONE]") break
        val json = runCatching { JSONObject(data) }.getOrElse { continue }
        if (json.optString("error", null) != null) {
          throw LlmException(json.optJSONObject("error")?.optString("message") ?: "Error del proveedor", 200)
        }
        val choices = json.optJSONArray("choices") ?: continue
        val delta = choices.optJSONObject(0)?.optJSONObject("delta") ?: continue

        // OpenRouter/OpenAI: content y reasoning (deepseek/openrouter usan "reasoning")
        delta.optString("content", null)?.let { if (it.isNotEmpty()) { text.append(it); onTextDelta(it) } }
        val rd = delta.optString("reasoning", null) ?: delta.optString("reasoning_content", null)
        if (!rd.isNullOrEmpty()) { reasoning.append(rd); onReasoningDelta(rd) }

        // Tool calls en streaming: fragments por index
        val tcs = delta.optJSONArray("tool_calls")
        if (tcs != null) for (i in 0 until tcs.length()) {
          val tc = tcs.optJSONObject(i) ?: continue
          val idx = tc.optInt("index", i)
          val acc = toolCalls.firstOrNull { it.index == idx } ?: ToolCallAcc(idx).also { toolCalls.add(it) }
          tc.optString("id", null)?.let { if (it.isNotEmpty()) acc.id = it }
          tc.optJSONObject("function")?.let { fn ->
            fn.optString("name", null)?.let { if (it.isNotEmpty()) acc.name = it }
            fn.optString("arguments", null)?.let { if (it.isNotEmpty()) acc.arguments.append(it) }
          }
        }
      }
    }

    inFlight = null
    StreamResult(
      text = text.toString(),
      reasoning = reasoning.toString(),
      toolCalls = toolCalls.sortedBy { it.index }.map { LToolCall(it.id.ifBlank { "call_${it.index}" }, it.name, it.arguments.toString()) }
    )
    }

  /** Chat no-streaming (fallback para servidores sin SSE). */
  suspend fun chatSimple(model: String, messages: List<LMessage>, tools: List<ToolDef>): StreamResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
    val body = JSONObject().apply {
      put("model", model)
      put("messages", JSONArray().apply { messages.forEach { put(it.toJson()) } })
      if (tools.isNotEmpty()) {
        put("tools", JSONArray().apply { tools.forEach { put(it.toJson()) } })
        put("tool_choice", "auto")
      }
    }.toString()

    val rb = Request.Builder()
      .url(baseUrl.trimEnd('/') + "/chat/completions")
      .post(body.toRequestBody("application/json".toMediaType()))
    if (!apiKey.isNullOrBlank()) rb.header("Authorization", "Bearer $apiKey")

    client.newCall(rb.build()).execute().use { resp ->
      val errBody = runCatching { resp.body?.string() }.getOrNull()
      if (!resp.isSuccessful) throw LlmException(parseErrorMessage(errBody) ?: "HTTP ${resp.code}", resp.code)
      val json = JSONObject(errBody ?: "{}")
      val choice = json.optJSONArray("choices")?.optJSONObject(0)
      val msg = choice?.optJSONObject("message")
      val calls = mutableListOf<LToolCall>()
      msg?.optJSONArray("tool_calls")?.let { arr ->
        for (i in 0 until arr.length()) {
          val tc = arr.optJSONObject(i) ?: continue
          val fn = tc.optJSONObject("function") ?: continue
          calls.add(LToolCall(tc.optString("id"), fn.optString("name"), fn.optString("arguments", "{}")))
        }
      }
      StreamResult(msg?.optString("content", null), msg?.optString("reasoning", null), calls)
    }
    }

  /** Lista modelos disponibles del proveedor (/models). */
  suspend fun listModels(): List<Pair<String, String>> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
    val rb = Request.Builder().url(baseUrl.trimEnd('/') + "/models")
    if (!apiKey.isNullOrBlank()) rb.header("Authorization", "Bearer $apiKey")
    client.newCall(rb.build()).execute().use { resp ->
      if (!resp.isSuccessful) throw LlmException("HTTP ${resp.code} listando modelos", resp.code)
      val json = JSONObject(resp.body?.string() ?: "{}")
      val data = json.optJSONArray("data") ?: return@withContext emptyList()
      val out = mutableListOf<Pair<String, String>>()
      for (i in 0 until data.length()) {
        val o = data.optJSONObject(i) ?: continue
        val id = o.optString("id")
        if (id.isNotEmpty()) out.add(id to (o.optString("name", id).ifBlank { id }))
      }
      out
    }
  }

  fun cancel() { runCatching { inFlight?.cancel() } }

  private fun parseErrorMessage(body: String?): String? {
    if (body.isNullOrBlank()) return null
    return runCatching {
      val o = JSONObject(body)
      o.optJSONObject("error")?.optString("message", null)
        ?: o.optString("message", null)
        ?: o.optString("error", null)
    }.getOrNull() ?: body.take(300)
  }

  class LlmException(message: String, val code: Int = 0) : Exception(message)

  data class StreamResult(val text: String?, val reasoning: String?, val toolCalls: List<LToolCall>)

  private class ToolCallAcc(val index: Int) {
    var id: String = ""
    var name: String = ""
    val arguments = StringBuilder()
  }

  companion object {
    /** Adaptador para el AgentRunner (implementa LlmApi del core). */
    fun asApi(client: LlmClient): com.example.agent.core.LlmApi = com.example.agent.core.LlmApi {
      model, messages, tools, onTextDelta, onReasoningDelta ->
      try {
        val r = client.chatStream(model, messages, tools, onTextDelta = onTextDelta, onReasoningDelta = onReasoningDelta)
        com.example.agent.core.LlmApiResult(r.text ?: "", r.toolCalls)
      } catch (e: LlmException) {
        // Servidores sin SSE/tool-streaming: reintento no-streaming.
        if (e.code == 400 || e.code == 404 || e.message?.contains("stream", ignoreCase = true) == true) {
          val r = client.chatSimple(model, messages, tools)
          com.example.agent.core.LlmApiResult(r.text ?: "", r.toolCalls)
        } else throw e
      }
    }
  }
}
