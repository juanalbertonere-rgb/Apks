package com.example.agent.tools

import android.content.Context
import android.content.Intent
import com.example.service.WeaverAccessibilityService
import org.json.JSONArray
import org.json.JSONObject

/** Helpers para construir schemas JSON de tools sin boilerplate. */
object Schema {
  fun obj(vararg props: Pair<String, String>, required: List<String> = emptyList()): JSONObject {
    val properties = JSONObject()
    props.forEach { (name, type) -> properties.put(name, JSONObject().put("type", type)) }
    val o = JSONObject().put("type", "object").put("properties", properties)
    if (required.isNotEmpty()) o.put("required", JSONArray(required))
    return o
  }

  fun enumObj(vararg props: Pair<String, String>, enums: Map<String, List<String>>, required: List<String> = emptyList()): JSONObject {
    val properties = JSONObject()
    props.forEach { (name, type) ->
      val p = JSONObject().put("type", type)
      enums[name]?.let { values ->
        p.put("enum", JSONArray(values))
        p.put("description", "Valores: ${values.joinToString(", ")}")
      }
      properties.put(name, p)
    }
    val o = JSONObject().put("type", "object").put("properties", properties)
    if (required.isNotEmpty()) o.put("required", JSONArray(required))
    return o
  }
}

/**
 * Tools del cuerpo Android del agente:
 *  - list_apps / open_app: lanzar apps instaladas
 *  - screen_tree / screen_find: LEER la pantalla vía accesibilidad
 *  - screen_click / screen_long_click / screen_scroll / screen_zoom / screen_swipe: GESTOS
 *  - screen_type: escribir en campos editables
 *  - screen_key: teclas globales (atrás/home/recientes/notificaciones)
 *  - screen_screenshot: captura (Android 11+, opcional)
 */
object AndroidTools {

  fun listApps(context: Context): JSONArray {
    val pm = context.packageManager
    val launchables = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
    val seen = HashSet<String>()
    val arr = JSONArray()
    for (info in launchables) {
      val pkg = info.activityInfo?.applicationInfo?.packageName ?: continue
      if (!seen.add(pkg)) continue
      if (pkg == context.packageName) continue
      val label = runCatching { pm.getApplicationLabel(info.activityInfo.applicationInfo).toString() }.getOrDefault(pkg)
      arr.put(JSONObject().put("app", label).put("package", pkg))
    }
    return arr
  }

  fun openApp(context: Context, query: String): JSONObject {
    val pm = context.packageManager
    val apps = listApps(context)
    val q = query.trim().lowercase()
    // 1) match exacto de package
    for (i in 0 until apps.length()) {
      val o = apps.getJSONObject(i)
      if (o.getString("package").lowercase() == q || o.getString("app").lowercase() == q) {
        return launch(context, o.getString("package"), o.getString("app"))
      }
    }
    // 2) match parcial por label o package
    for (i in 0 until apps.length()) {
      val o = apps.getJSONObject(i)
      if (o.getString("app").lowercase().contains(q) || o.getString("package").lowercase().contains(q)) {
        return launch(context, o.getString("package"), o.getString("app"))
      }
    }
    return JSONObject().put("ok", false).put("error", "No encontré una app llamada '$query'").put("hint", "Usa list_apps para ver las apps instaladas")
  }

  private fun launch(context: Context, pkg: String, label: String): JSONObject {
    val intent = context.packageManager.getLaunchIntentForPackage(pkg)
    return if (intent != null) {
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      JSONObject().put("ok", true).put("opened", label).put("package", pkg).put("hint", "Espera ~1.5s y usa screen_tree para ver la pantalla.")
    } else {
      JSONObject().put("ok", false).put("error", "La app '$label' no tiene actividad de lanzamiento")
    }
  }

  /** Fábrica de specs que dependen del contexto/accesibilidad. */
  fun specs(context: Context): List<com.example.agent.core.ToolSpec> {
    val reg = com.example.agent.core.ToolRegistry()
    val a11y = { WeaverAccessibilityService.instance }

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "list_apps",
          "Lista las apps instaladas en el teléfono (nombre + package). Úsala antes de open_app si dudas del nombre.",
          Schema.obj()
        ),
        group = "Apps Android"
      ) { _, _ ->
        val apps = listApps(context)
        JSONObject().put("ok", true).put("count", apps.length()).put("apps", apps).toString()
          .let { com.example.agent.core.ToolOutput(true, it) }
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "open_app",
          "Abre una app del teléfono por nombre o package (ej: 'whatsapp', 'com.whatsapp'). Luego usa screen_tree para verla.",
          Schema.obj("query" to "string", required = listOf("query"))
        ),
        group = "Apps Android"
      ) { args, ctx ->
        if (ctx.cancelled) return@ToolSpec com.example.agent.core.ToolOutput(false, "", "cancelado")
        openApp(context, args.optString("query"))
          .let { com.example.agent.core.ToolOutput(it.optBoolean("ok"), it.toString(), it.optString("error", null).ifEmpty { null }) }
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "screen_tree",
          "Lee el árbol de accesibilidad de la pantalla actual: elementos con clase, texto, id, bounds y centro (cx/cy) para clics. Consume tokens: usa max_depth y desde_texto para acotar.",
          Schema.obj("max_depth" to "number", "max_nodes" to "number")
        ),
        group = "Pantalla (accesibilidad)"
      ) { args, _ ->
        val svc = a11y() ?: return@ToolSpec com.example.agent.core.ToolOutput(false, "", "El servicio de accesibilidad de Weaver no está activo. Pide al usuario: Ajustes → Accesibilidad → Weaver → activar.")
        val tree = svc.readTree(args.optInt("max_depth", 10), args.optInt("max_nodes", 250))
        com.example.agent.core.ToolOutput(true, tree.toString())
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "screen_find",
          "Busca elementos en la pantalla por texto, id, class o description y devuelve sus coordenadas (cx/cy) para clics. Más barato que screen_tree.",
          Schema.obj(
            "text" to "string", "id" to "string", "class" to "string", "description" to "string",
            "limit" to "number"
          )
        ),
        group = "Pantalla (accesibilidad)"
      ) { args, _ ->
        val svc = a11y() ?: return@ToolSpec com.example.agent.core.ToolOutput(false, "", "El servicio de accesibilidad no está activo.")
        val res = svc.findNodes(args)
        com.example.agent.core.ToolOutput(res.optBoolean("ok"), res.toString(), res.optString("error", null).ifEmpty { null })
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "screen_click",
          "Hace tap en coordenadas de pantalla (usa cx/cy de screen_find o screen_tree).",
          Schema.obj("x" to "number", "y" to "number", required = listOf("x", "y"))
        ),
        group = "Pantalla (accesibilidad)",
        destructive = true
      ) { args, _ ->
        val svc = a11y() ?: return@ToolSpec com.example.agent.core.ToolOutput(false, "", "El servicio de accesibilidad no está activo.")
        val ok = svc.tap(args.optDouble("x").toFloat(), args.optDouble("y").toFloat())
        com.example.agent.core.ToolOutput(ok, if (ok) "Tap ejecutado en (${args.optDouble("x")}, ${args.optDouble("y")})" else "El gesto no se pudo ejecutar")
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "screen_long_click",
          "Mantiene pulsado (long press) en coordenadas. Útil para menús contextuales, arrastre inicial, selección.",
          Schema.obj("x" to "number", "y" to "number", required = listOf("x", "y"))
        ),
        group = "Pantalla (accesibilidad)",
        destructive = true
      ) { args, _ ->
        val svc = a11y() ?: return@ToolSpec com.example.agent.core.ToolOutput(false, "", "El servicio de accesibilidad no está activo.")
        val ok = svc.longClick(args.optDouble("x").toFloat(), args.optDouble("y").toFloat())
        com.example.agent.core.ToolOutput(ok, if (ok) "Long press ejecutado" else "El gesto no se pudo ejecutar")
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "screen_scroll",
          "Desplaza la pantalla: 'up' (sube contenido/ver arriba), 'down', 'left', 'right'.",
          Schema.enumObj(
            "direction" to "string",
            enums = mapOf("direction" to listOf("up", "down", "left", "right")),
            required = listOf("direction")
          )
        ),
        group = "Pantalla (accesibilidad)"
      ) { args, _ ->
        val svc = a11y() ?: return@ToolSpec com.example.agent.core.ToolOutput(false, "", "El servicio de accesibilidad no está activo.")
        val ok = svc.scroll(args.optString("direction", "down"))
        com.example.agent.core.ToolOutput(ok, if (ok) "Scroll '${args.optString("direction")}' ejecutado" else "Dirección inválida")
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "screen_zoom",
          "Gesto de pellizco con dos dedos: mode 'in' = acercar (zoom+), 'out' = alejar (zoom-). Coordenadas del centro del gesto.",
          Schema.obj("mode" to "string", "x" to "number", "y" to "number", required = listOf("mode"))
        ),
        group = "Pantalla (accesibilidad)"
      ) { args, _ ->
        val svc = a11y() ?: return@ToolSpec com.example.agent.core.ToolOutput(false, "", "El servicio de accesibilidad no está activo.")
        val m = resources_displayMetrics()
        val x = (if (args.has("x")) args.optDouble("x") else m.widthPixels / 2.0).toFloat()
        val y = (if (args.has("y")) args.optDouble("y") else m.heightPixels / 2.0).toFloat()
        val ok = svc.pinch(x, y, args.optString("mode", "in"))
        com.example.agent.core.ToolOutput(ok, if (ok) "Zoom '${args.optString("mode")}' ejecutado" else "El gesto no se pudo ejecutar")
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "screen_swipe",
          "Arrastre libre de (x1,y1) a (x2,y2) en duration_ms. Para sliders, drawers, reorderables.",
          Schema.obj("x1" to "number", "y1" to "number", "x2" to "number", "y2" to "number", "duration_ms" to "number", required = listOf("x1", "y1", "x2", "y2"))
        ),
        group = "Pantalla (accesibilidad)",
        destructive = true
      ) { args, _ ->
        val svc = a11y() ?: return@ToolSpec com.example.agent.core.ToolOutput(false, "", "El servicio de accesibilidad no está activo.")
        val ok = svc.swipe(
          args.optDouble("x1").toFloat(), args.optDouble("y1").toFloat(),
          args.optDouble("x2").toFloat(), args.optDouble("y2").toFloat(),
          args.optLong("duration_ms", 400)
        )
        com.example.agent.core.ToolOutput(ok, if (ok) "Swipe ejecutado" else "El gesto no se pudo ejecutar")
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "screen_type",
          "Escribe texto en un campo editable de la pantalla. Con 'match' localiza el campo por texto/hint/desc; sin 'match' usa el primer campo editable.",
          Schema.obj("text" to "string", "match" to "string", required = listOf("text"))
        ),
        group = "Pantalla (accesibilidad)",
        destructive = true
      ) { args, _ ->
        val svc = a11y() ?: return@ToolSpec com.example.agent.core.ToolOutput(false, "", "El servicio de accesibilidad no está activo.")
        val res = svc.typeText(
          args.optString("text", ""),
          args.optString("match", null).ifEmpty { null }
        )
        com.example.agent.core.ToolOutput(res.optBoolean("ok"), res.toString(), res.optString("error", null).ifEmpty { null })
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "screen_key",
          "Pulsa una tecla global del sistema: 'back', 'home', 'recents', 'notifications', 'quick_settings'.",
          Schema.enumObj(
            "key" to "string",
            enums = mapOf("key" to listOf("back", "home", "recents", "notifications", "quick_settings")),
            required = listOf("key")
          )
        ),
        group = "Pantalla (accesibilidad)"
      ) { args, _ ->
        val svc = a11y() ?: return@ToolSpec com.example.agent.core.ToolOutput(false, "", "El servicio de accesibilidad no está activo.")
        val action = when (args.optString("key")) {
          "back" -> WeaverAccessibilityService.GLOBAL_BACK
          "home" -> WeaverAccessibilityService.GLOBAL_HOME
          "recents" -> WeaverAccessibilityService.GLOBAL_RECENTS
          "notifications" -> WeaverAccessibilityService.GLOBAL_NOTIFICATIONS
          "quick_settings" -> WeaverAccessibilityService.GLOBAL_QUICK_SETTINGS
          else -> return@ToolSpec com.example.agent.core.ToolOutput(false, "", "Tecla desconocida")
        }
        val ok = svc.globalAction(action)
        com.example.agent.core.ToolOutput(ok, if (ok) "Tecla '${args.optString("key")}' ejecutada" else "No se pudo ejecutar")
      }
    )

    reg.register(
      com.example.agent.core.ToolSpec(
        com.example.agent.core.ToolDef(
          "screen_screenshot",
          "Captura la pantalla actual (Android 11+, requiere permiso de captura en el diálogo de accesibilidad). Guarda el PNG en cache y devuelve la ruta.",
          Schema.obj()
        ),
        group = "Pantalla (accesibilidad)"
      ) { _, _ ->
        val svc = a11y() ?: return@ToolSpec com.example.agent.core.ToolOutput(false, "", "El servicio de accesibilidad no está activo.")
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
          svc.takeScreenshot { json ->
            cont.resumeWith(Result.success(com.example.agent.core.ToolOutput(json.optBoolean("ok"), json.toString(), json.optString("error", null).ifEmpty { null })))
          }
        }
      }
    )

    return reg.list()
  }

  private fun resources_displayMetrics(): android.util.DisplayMetrics =
    android.content.res.Resources.getSystem().displayMetrics
}
