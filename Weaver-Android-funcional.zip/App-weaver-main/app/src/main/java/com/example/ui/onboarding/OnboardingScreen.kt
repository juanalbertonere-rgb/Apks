package com.example.ui.onboarding

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.WeaverLogo
import com.example.ui.theme.ChatGptBlack
import com.example.ui.theme.ChatGptBorderSubtle
import com.example.ui.theme.ChatGptInputBg
import com.example.ui.theme.ChatGptPillSelected
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptTextSecondary

data class LanguageOption(
  val code: String,
  val name: String,
  val nativeName: String,
  val badgeCode: String
)

val availableLanguages = listOf(
  LanguageOption("es", "Español", "Español", "ES"),
  LanguageOption("en", "English", "English", "EN"),
  LanguageOption("pt", "Português", "Português", "PT"),
  LanguageOption("fr", "Français", "Français", "FR"),
  LanguageOption("de", "Deutsch", "Deutsch", "DE"),
  LanguageOption("it", "Italiano", "Italiano", "IT")
)

@Composable
fun OnboardingScreen(
  onComplete: (name: String, language: String) -> Unit,
  modifier: Modifier = Modifier
) {
  var currentStep by remember { mutableIntStateOf(0) }
  var selectedLanguage by remember { mutableStateOf("Español") }
  var agentCallingName by remember { mutableStateOf("") }

  Surface(
    modifier = modifier
      .fillMaxSize()
      .statusBarsPadding()
      .navigationBarsPadding(),
    color = ChatGptBlack
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
      // Step indicator (Dots / Bars)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp, bottom = 20.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
      ) {
        for (i in 0..2) {
          val isActive = i == currentStep
          val isPassed = i < currentStep
          Box(
            modifier = Modifier
              .padding(horizontal = 4.dp)
              .height(4.dp)
              .width(if (isActive) 28.dp else 16.dp)
              .clip(CircleShape)
              .background(
                when {
                  isActive -> Color.White
                  isPassed -> Color(0xFF52525B)
                  else -> Color(0xFF27272A)
                }
              )
          )
        }
      }

      // Step Contents with smooth transition
      AnimatedContent(
        targetState = currentStep,
        transitionSpec = {
          if (targetState > initialState) {
            (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
              slideOutHorizontally { width -> -width } + fadeOut()
            )
          } else {
            (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(
              slideOutHorizontally { width -> width } + fadeOut()
            )
          }
        },
        modifier = Modifier.weight(1f),
        label = "OnboardingStepAnimation"
      ) { step ->
        when (step) {
          0 -> StepWelcomeAndLanguage(
            selectedLanguage = selectedLanguage,
            onLanguageSelected = { selectedLanguage = it },
            onNext = { currentStep = 1 }
          )
          1 -> StepAgentCallingName(
            agentCallingName = agentCallingName,
            onNameChanged = { agentCallingName = it },
            onNext = { currentStep = 2 }
          )
          2 -> StepLinkChatsWithQr(
            onComplete = {
              onComplete(
                agentCallingName.ifBlank { "Usuario" },
                selectedLanguage
              )
            },
            onSkip = {
              onComplete(
                agentCallingName.ifBlank { "Usuario" },
                selectedLanguage
              )
            }
          )
        }
      }
    }
  }
}

// ---------------------------------------------------------------------------------
// STEP 1: Bienvenido & Elegir idioma
// ---------------------------------------------------------------------------------
@Composable
private fun StepWelcomeAndLanguage(
  selectedLanguage: String,
  onLanguageSelected: (String) -> Unit,
  onNext: () -> Unit
) {
  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Spacer(modifier = Modifier.height(16.dp))

    // Weaver stylized logo
    Box(
      modifier = Modifier
        .size(64.dp)
        .clip(RoundedCornerShape(18.dp))
        .background(ChatGptPillSelected)
        .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(18.dp)),
      contentAlignment = Alignment.Center
    ) {
      WeaverLogo(size = 36.dp, color = Color.White)
    }

    Spacer(modifier = Modifier.height(18.dp))

    Text(
      text = "Bienvenido a Weaver",
      fontSize = 26.sp,
      fontWeight = FontWeight.Bold,
      color = ChatGptTextPrimary,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = "Tu agente autónomo con presencia real en tus dispositivos y flujos de trabajo.",
      fontSize = 14.sp,
      color = ChatGptTextSecondary,
      textAlign = TextAlign.Center,
      modifier = Modifier.padding(horizontal = 16.dp)
    )

    Spacer(modifier = Modifier.height(28.dp))

    // Subtitle for language selection
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = Icons.Outlined.Translate,
        contentDescription = null,
        tint = Color(0xFF60A5FA),
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "Elige tu idioma",
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold,
        color = ChatGptTextPrimary
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(availableLanguages) { lang ->
        val isSelected = lang.name == selectedLanguage
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) ChatGptPillSelected else ChatGptInputBg)
            .border(
              width = 1.dp,
              color = if (isSelected) Color(0xFF3B82F6) else ChatGptBorderSubtle,
              shape = RoundedCornerShape(12.dp)
            )
            .clickable { onLanguageSelected(lang.name) }
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag("language_option_${lang.code}"),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF27272A))
                .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(8.dp)),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = lang.badgeCode,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else Color(0xFFA1A1AA)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = lang.name,
                fontSize = 15.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                color = ChatGptTextPrimary
              )
              Text(
                text = lang.nativeName,
                fontSize = 12.sp,
                color = ChatGptTextMuted
              )
            }
          }

          if (isSelected) {
            Box(
              modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(Color(0xFF3B82F6)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Seleccionado",
                tint = Color.White,
                modifier = Modifier.size(14.dp)
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Button(
      onClick = onNext,
      modifier = Modifier
        .fillMaxWidth()
        .height(50.dp)
        .testTag("onboarding_next_step_1"),
      shape = RoundedCornerShape(12.dp),
      colors = ButtonDefaults.buttonColors(
        containerColor = Color.White,
        contentColor = Color.Black
      )
    ) {
      Text(
        text = "Continuar",
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold
      )
      Spacer(modifier = Modifier.width(6.dp))
      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = null,
        modifier = Modifier.size(16.dp)
      )
    }
  }
}

// ---------------------------------------------------------------------------------
// STEP 2: ¿Cómo quieres que te llame el agente?
// ---------------------------------------------------------------------------------
@Composable
private fun StepAgentCallingName(
  agentCallingName: String,
  onNameChanged: (String) -> Unit,
  onNext: () -> Unit
) {
  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Spacer(modifier = Modifier.height(24.dp))

    Box(
      modifier = Modifier
        .size(64.dp)
        .clip(RoundedCornerShape(18.dp))
        .background(ChatGptPillSelected)
        .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(18.dp)),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Outlined.Person,
        contentDescription = null,
        tint = Color(0xFF60A5FA),
        modifier = Modifier.size(32.dp)
      )
    }

    Spacer(modifier = Modifier.height(22.dp))

    Text(
      text = "¿Cómo quieres que te llame el agente?",
      fontSize = 22.sp,
      fontWeight = FontWeight.Bold,
      color = ChatGptTextPrimary,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
      text = "Weaver personalizará tu experiencia y usará este nombre para dirigirse a ti en tus tareas, notas y respuestas.",
      fontSize = 14.sp,
      color = ChatGptTextSecondary,
      textAlign = TextAlign.Center,
      modifier = Modifier.padding(horizontal = 16.dp)
    )

    Spacer(modifier = Modifier.height(36.dp))

    // Name text field
    OutlinedTextField(
      value = agentCallingName,
      onValueChange = onNameChanged,
      placeholder = {
        Text("Introduce tu nombre o apodo...", color = ChatGptTextMuted, fontSize = 15.sp)
      },
      singleLine = true,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("onboarding_name_input"),
      shape = RoundedCornerShape(12.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = ChatGptInputBg,
        unfocusedContainerColor = ChatGptInputBg,
        focusedBorderColor = Color(0xFF3B82F6),
        unfocusedBorderColor = ChatGptBorderSubtle,
        focusedTextColor = ChatGptTextPrimary,
        unfocusedTextColor = ChatGptTextPrimary,
        cursorColor = Color(0xFF3B82F6)
      )
    )

    Spacer(modifier = Modifier.height(14.dp))

    // Suggestion chips
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      listOf("Alex", "Usuario", "Compañero", "Boss").forEach { suggestion ->
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(ChatGptPillSelected)
            .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(16.dp))
            .clickable { onNameChanged(suggestion) }
            .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Text(text = suggestion, fontSize = 12.5.sp, color = ChatGptTextSecondary)
        }
      }
    }

    Spacer(modifier = Modifier.weight(1f))

    Button(
      onClick = onNext,
      modifier = Modifier
        .fillMaxWidth()
        .height(50.dp)
        .testTag("onboarding_next_step_2"),
      shape = RoundedCornerShape(12.dp),
      colors = ButtonDefaults.buttonColors(
        containerColor = Color.White,
        contentColor = Color.Black
      )
    ) {
      Text(
        text = "Continuar",
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold
      )
      Spacer(modifier = Modifier.width(6.dp))
      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = null,
        modifier = Modifier.size(16.dp)
      )
    }
  }
}

// ---------------------------------------------------------------------------------
// STEP 3: Vincular chats (QR code de momento sin funcionalidad + Botón omitir abajo a la izquierda en otro color que resalte)
// ---------------------------------------------------------------------------------
@Composable
private fun StepLinkChatsWithQr(
  onComplete: () -> Unit,
  onSkip: () -> Unit
) {
  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Spacer(modifier = Modifier.height(16.dp))

    Box(
      modifier = Modifier
        .size(54.dp)
        .clip(RoundedCornerShape(16.dp))
        .background(ChatGptPillSelected)
        .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(16.dp)),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.QrCodeScanner,
        contentDescription = null,
        tint = Color(0xFF60A5FA),
        modifier = Modifier.size(28.dp)
      )
    }

    Spacer(modifier = Modifier.height(14.dp))

    Text(
      text = "Vincular chats",
      fontSize = 24.sp,
      fontWeight = FontWeight.Bold,
      color = ChatGptTextPrimary,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = "Escanea este código QR desde tu sesión de Weaver en la computadora u otro dispositivo para sincronizar tus chats.",
      fontSize = 13.5.sp,
      color = ChatGptTextSecondary,
      textAlign = TextAlign.Center,
      modifier = Modifier.padding(horizontal = 20.dp)
    )

    Spacer(modifier = Modifier.height(20.dp))

    // ─── QR REAL de emparejamiento del teléfono (payload weaver://phone) ───
    val context = androidx.compose.ui.platform.LocalContext.current
    val settings = remember { com.example.data.Settings(context) }
    val host = remember { com.example.sync.PhoneServer.lanAddress() ?: "0.0.0.0" }
    val payload = remember {
      com.example.sync.QrPayloads.phonePairing(
        settings.deviceName, host, settings.phonePort, settings.phoneToken, settings.deviceId
      )
    }
    val qrBitmap = remember(payload) { com.example.sync.QrCodec.encode(payload, 620) }

    Box(
      modifier = Modifier
        .size(230.dp)
        .clip(RoundedCornerShape(20.dp))
        .background(Color.White)
        .padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      androidx.compose.foundation.Image(
        bitmap = qrBitmap.asImageBitmap(),
        contentDescription = "QR de emparejamiento de Weaver",
        modifier = Modifier.fillMaxSize()
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Estado del vínculo con la PC
    Text(
      text = if (settings.isPcPaired) "PC vinculada: ${settings.pcBridgeName} ✓" else "Corre 'npm run bridge' en tu PC y escanea su QR aquí ↓",
      fontSize = 12.sp,
      color = if (settings.isPcPaired) Color(0xFF4ADE80) else ChatGptTextMuted
    )

    var showScanner by remember { mutableStateOf(false) }
    Text(
      text = if (showScanner) "Cerrar escáner" else "📷 Escanear QR de la PC",
      fontSize = 13.sp,
      color = Color(0xFF60A5FA),
      modifier = Modifier
        .clip(RoundedCornerShape(10.dp))
        .clickable { showScanner = !showScanner }
        .padding(horizontal = 10.dp, vertical = 8.dp)
    )

    if (showScanner) {
      com.example.ui.scan.QrScanScreen(
        onScanned = { scanned ->
          val parsed = com.example.sync.QrPayloads.parse(scanned)
          if (parsed != null && parsed.first == "bridge") {
            settings.pcBridgeUrl = "http://${parsed.second["host"]}:${parsed.second["port"]}"
            settings.pcBridgeToken = parsed.second["token"]
            settings.pcBridgeName = parsed.second["name"] ?: "PC"
            showScanner = false
          }
        },
        onClose = { showScanner = false }
      )
    }

    Spacer(modifier = Modifier.weight(1f))

    // Bottom Navigation Bar
    // User requested explicitly: "y abajo a la izquierda un este de omitir en otro color para que resalte"
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // OMITIR BUTTON: Abajo a la izquierda, color llamativo (Ámbar / Amarillo brillante #F59E0B) para resaltar
      Button(
        onClick = onSkip,
        modifier = Modifier
          .height(48.dp)
          .testTag("onboarding_skip_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = Color(0xFFF59E0B), // Vibrant Amber Orange to stand out boldly!
          contentColor = Color(0xFF000000)   // High-contrast bold dark label
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
      ) {
        Text(
          text = "Omitir",
          fontSize = 14.5.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.3.sp
        )
      }

      // Continuar / Finalizar button on the right
      Button(
        onClick = onComplete,
        modifier = Modifier
          .height(48.dp)
          .testTag("onboarding_finish_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = Color.White,
          contentColor = Color.Black
        )
      ) {
        Text(
          text = "Continuar",
          fontSize = 14.5.sp,
          fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.width(6.dp))
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowForward,
          contentDescription = null,
          modifier = Modifier.size(16.dp)
        )
      }
    }
  }
}

// ---------------------------------------------------------------------------------
// PROCEDURAL QR CODE CANVAS
// ---------------------------------------------------------------------------------
@Composable
private fun QrCodeCanvas(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val canvasSize = size.minDimension
    val modules = 21 // standard version 1 QR grid size
    val cellSize = canvasSize / modules

    // Draw background white
    drawRect(color = Color.White, size = size)

    val black = Color(0xFF111111)

    // Finder pattern helper
    fun drawFinderPattern(startX: Int, startY: Int) {
      // Outer 7x7
      for (r in 0 until 7) {
        for (c in 0 until 7) {
          val isBorder = r == 0 || r == 6 || c == 0 || c == 6
          val isInner = r in 2..4 && c in 2..4
          if (isBorder || isInner) {
            drawRoundRect(
              color = black,
              topLeft = Offset((startX + c) * cellSize, (startY + r) * cellSize),
              size = Size(cellSize, cellSize),
              cornerRadius = CornerRadius(cellSize * 0.15f)
            )
          }
        }
      }
    }

    // Draw 3 standard corner finder patterns
    drawFinderPattern(0, 0)
    drawFinderPattern(modules - 7, 0)
    drawFinderPattern(0, modules - 7)

    // Deterministic pseudo-random pattern for data bits
    val seedMatrix = arrayOf(
      intArrayOf(1, 0, 1, 1, 0, 1, 0),
      intArrayOf(0, 1, 0, 0, 1, 0, 1),
      intArrayOf(1, 1, 0, 1, 1, 0, 0),
      intArrayOf(0, 0, 1, 0, 1, 1, 1),
      intArrayOf(1, 0, 1, 1, 0, 0, 1),
      intArrayOf(0, 1, 0, 1, 0, 1, 0),
      intArrayOf(1, 1, 1, 0, 1, 0, 1)
    )

    for (r in 0 until modules) {
      for (c in 0 until modules) {
        // Skip finder areas
        val inTopLeft = r < 8 && c < 8
        val inTopRight = r < 8 && c >= modules - 8
        val inBottomLeft = r >= modules - 8 && c < 8

        if (inTopLeft || inTopRight || inBottomLeft) continue

        // Timing patterns
        val isTimingH = r == 6 && c % 2 == 0
        val isTimingV = c == 6 && r % 2 == 0

        // Data pattern
        val isData = ((r * 7 + c * 13 + seedMatrix[r % 7][c % 7]) % 3 == 0)

        if (isTimingH || isTimingV || isData) {
          drawRoundRect(
            color = black,
            topLeft = Offset(c * cellSize + (cellSize * 0.05f), r * cellSize + (cellSize * 0.05f)),
            size = Size(cellSize * 0.9f, cellSize * 0.9f),
            cornerRadius = CornerRadius(cellSize * 0.2f)
          )
        }
      }
    }
  }
}
