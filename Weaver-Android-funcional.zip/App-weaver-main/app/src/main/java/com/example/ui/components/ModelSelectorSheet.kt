package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChatGptBorderSubtle
import com.example.ui.theme.ChatGptDrawerBg
import com.example.ui.theme.ChatGptPillSelected
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptTextSecondary

data class ModelOption(
  val id: String,
  val name: String,
  val description: String,
  val icon: ImageVector,
  val isPlus: Boolean = false
)

val availableModels = listOf(
  ModelOption(
    id = "gpt-4o",
    name = "ChatGPT (GPT-4o)",
    description = "Nuestro modelo más inteligente para texto, visión y audio.",
    icon = Icons.Outlined.AutoAwesome
  ),
  ModelOption(
    id = "gpt-4o-mini",
    name = "GPT-4o mini",
    description = "Rápido y ligero para tareas cotidianas.",
    icon = Icons.Outlined.Bolt
  ),
  ModelOption(
    id = "o1",
    name = "Razonamiento (o1)",
    description = "Piensa detenidamente para resolver problemas difíciles.",
    icon = Icons.Outlined.Psychology,
    isPlus = true
  ),
  ModelOption(
    id = "dalle",
    name = "DALL·E",
    description = "Crea y edita imágenes a partir de lenguaje natural.",
    icon = Icons.Outlined.Science,
    isPlus = true
  )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelSelectorSheet(
  selectedModelId: String,
  models: List<ModelOption> = availableModels,
  onModelSelected: (ModelOption) -> Unit,
  onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState()

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = ChatGptDrawerBg,
    contentColor = ChatGptTextPrimary,
    dragHandle = {
      Box(
        modifier = Modifier
          .padding(top = 10.dp, bottom = 10.dp)
          .size(width = 36.dp, height = 4.dp)
          .clip(RoundedCornerShape(2.dp))
          .background(ChatGptBorderSubtle)
      )
    },
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
        .navigationBarsPadding()
        .padding(bottom = 16.dp)
    ) {
      Text(
        text = "Seleccionar modelo",
        fontSize = 18.sp,
        fontWeight = FontWeight.SemiBold,
        color = ChatGptTextPrimary,
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp)
      )

      models.forEach { model ->
        val isSelected = model.id == selectedModelId
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) ChatGptPillSelected else Color.Transparent)
            .clickable {
              onModelSelected(model)
              onDismiss()
            }
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(ChatGptPillSelected),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = model.icon,
              contentDescription = null,
              tint = ChatGptTextPrimary,
              modifier = Modifier.size(20.dp)
            )
          }

          Spacer(modifier = Modifier.width(14.dp))

          Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = model.name,
                fontWeight = FontWeight.Medium,
                fontSize = 15.sp,
                color = ChatGptTextPrimary
              )
              if (model.isPlus) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF2A2A2A))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = "PLUS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFD4AF37)
                  )
                }
              }
            }
            Text(
              text = model.description,
              fontSize = 12.sp,
              color = ChatGptTextSecondary,
              lineHeight = 16.sp
            )
          }

          if (isSelected) {
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
              imageVector = Icons.Default.Check,
              contentDescription = "Selected",
              tint = ChatGptTextPrimary,
              modifier = Modifier.size(20.dp)
            )
          }
        }
        Spacer(modifier = Modifier.height(4.dp))
      }
    }
  }
}
