#!/usr/bin/env node
/**
 * Weaver PC Bridge — pc-bridge/weaver-bridge.mjs
 *
 * Ejecuta el agente Weaver EN TU PC cuando el teléfono está en modo "PC".
 * Sin dependencias externas: Node puro (http + child_process + fetch).
 *
 * USO:
 *   node weaver-bridge.mjs
 *   node weaver-bridge.mjs --port 8787 --name "Mi PC" --link "weaver://phone?host=192.168.1.5&port=8765&token=abc"
 *
 * Qué hace:
 *   1. Arranca un servidor HTTP en 0.0.0.0:<port> con token propio.
 *   2. Imprime su payload de emparejamiento (weaver://bridge?...) para que la
 *      app Android lo escanee en el onboarding o en Ajustes.
 *   3. Si le pasas --link con el QR del teléfono, se registra en él
 *      (POST /api/bridge/register) para quedar emparejado en ambos lados.
 *   4. POST /api/run ejecuta un turno agéntico ReAct real en la PC con tools:
 *        shell_exec  → child_process (bash/PowerShell)
 *        file_read   → leer archivos
 *        file_write  → escribir archivos
 *        list_dir    → listar directorios
 *        web_fetch   → GET http(s) y extraer texto
 *        web_search  → DuckDuckGo HTML (best-effort)
 *      y transmite los eventos por SSE al teléfono, igual que el agente móvil.
 *
 * Config del LLM: variables de entorno o .env en la carpeta donde lo corras:
 *   WEAVER_LLM_BASE=https://openrouter.ai/api/v1
 *   WEAVER_LLM_KEY=sk-or-...
 *   WEAVER_LLM_MODEL=openrouter/auto
 *
 * Requisitos: Node 18+ (fetch nativo).
 */

import http from 'node:http';
import crypto from 'node:crypto';
import { exec } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// ─────────────────────────── Configuración ──────────────────────────────────

const args = process.argv.slice(2);
function arg(name, fallback) {
  const i = args.indexOf(`--${name}`);
  return i >= 0 && args[i + 1] ? args[i + 1] : fallback;
}

const PORT = Number(arg('port', 8787));
const NAME = arg('name', os.hostname());
const LINK = arg('link', null);
const TOKEN = arg('token', crypto.randomBytes(8).toString('hex'));

let ENV = {};
try {
  const envFile = fs.readFileSync(path.join(process.cwd(), '.env'), 'utf8');
  for (const line of envFile.split('\n')) {
    const m = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (m) ENV[m[1]] = m[2].trim().replace(/^["']|["']$/g, '');
  }
} catch {}

const LLM_BASE = process.env.WEAVER_LLM_BASE || ENV.WEAVER_LLM_BASE || 'https://openrouter.ai/api/v1';
const LLM_KEY = process.env.WEAVER_LLM_KEY || ENV.WEAVER_LLM_KEY || '';
const LLM_MODEL = process.env.WEAVER_LLM_MODEL || ENV.WEAVER_LLM_MODEL || 'openrouter/auto';
const LLM_PROVIDER = LLM_BASE.includes('openrouter') ? 'openrouter' : LLM_BASE.includes('openai') ? 'openai' : 'custom';

// ───────────────────────────── Tools de la PC ───────────────────────────────

const MAX_OUTPUT = 8000;

const TOOLS = [
  {
    name: 'shell_exec', description: 'Ejecuta un comando en la shell de la PC (bash en Linux/macOS, PowerShell en Windows). Devuelve stdout, stderr y código.',
    parameters: { type: 'object', properties: { command: { type: 'string' }, cwd: { type: 'string' } }, required: ['command'] },
    run: (a) => new Promise((resolve) => {
      const isWin = process.platform === 'win32';
      const cmd = isWin ? `powershell -Command "${a.command.replace(/"/g, '\\"')}"` : a.command;
      exec(cmd, { cwd: a.cwd || os.homedir(), timeout: 120_000, maxBuffer: 10 * 1024 * 1024 }, (err, stdout, stderr) => {
        resolve({ ok: !err, output: JSON.stringify({ exitCode: err?.code ?? 0, stdout: (stdout || '').slice(0, MAX_OUTPUT), stderr: (stderr || '').slice(0, 4000) }) });
      });
    })
  },
  {
    name: 'file_read', description: 'Lee un archivo de texto de la PC (máx 8000 chars).',
    parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] },
    run: (a) => new Promise((resolve) => {
      fs.readFile(a.path, 'utf8', (err, data) => {
        resolve(err ? { ok: false, output: '', error: err.message } : { ok: true, output: data.slice(0, MAX_OUTPUT) });
      });
    })
  },
  {
    name: 'file_write', description: 'Escribe/crea un archivo en la PC (sobrescribe).',
    parameters: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] },
    run: (a) => new Promise((resolve) => {
      fs.mkdir(path.dirname(path.resolve(a.path)), { recursive: true }, () => {
        fs.writeFile(a.path, a.content ?? '', (err) =>
          resolve(err ? { ok: false, output: '', error: err.message } : { ok: true, output: `Escrito ${a.path}` }));
      });
    })
  },
  {
    name: 'list_dir', description: 'Lista el contenido de un directorio de la PC.',
    parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] },
    run: (a) => new Promise((resolve) => {
      fs.readdir(a.path, { withFileTypes: true }, (err, entries) => {
        if (err) return resolve({ ok: false, output: '', error: err.message });
        const list = entries.slice(0, 300).map(e => `${e.isDirectory() ? 'd' : '-'} ${e.name}`).join('\n');
        resolve({ ok: true, output: list });
      });
    })
  },
  {
    name: 'web_fetch', description: 'Descarga una URL HTTP(S) desde la PC y devuelve el texto (HTML → texto).',
    parameters: { type: 'object', properties: { url: { type: 'string' } }, required: ['url'] },
    run: async (a) => {
      try {
        const resp = await fetch(a.url, { headers: { 'User-Agent': 'Mozilla/5.0 WeaverBridge/1.0' }, signal: AbortSignal.timeout(25_000) });
        const ct = resp.headers.get('content-type') || '';
        let text = await resp.text();
        if (ct.includes('html')) {
          text = text.replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s{2,}/g, ' ');
        }
        return { ok: resp.ok, output: text.slice(0, MAX_OUTPUT) };
      } catch (e) { return { ok: false, output: '', error: e.message }; }
    }
  },
  {
    name: 'web_search', description: 'Busca en la web (DuckDuckGo HTML) y devuelve títulos, URLs y snippets.',
    parameters: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] },
    run: async (a) => {
      try {
        const url = 'https://html.duckduckgo.com/html/?q=' + encodeURIComponent(a.query);
        const resp = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, signal: AbortSignal.timeout(25_000) });
        const html = await resp.text();
        const results = [];
        const re = /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
        let m;
        while ((m = re.exec(html)) && results.length < 6) {
          let href = m[1];
          const uddg = /uddg=([^&]+)/.exec(href);
          if (uddg) href = decodeURIComponent(uddg[1]);
          if (href.startsWith('//')) href = 'https:' + href;
          results.push({ title: m[2].replace(/<[^>]+>/g, '').trim(), url: href });
        }
        if (!results.length) return { ok: false, output: '', error: 'Sin resultados (posible bloqueo)' };
        return { ok: true, output: JSON.stringify(results, null, 1) };
      } catch (e) { return { ok: false, output: '', error: e.message }; }
    }
  }
];

// ───────────────────────────── Bucle agéntico ───────────────────────────────

function systemPrompt() {
  return [
    `Eres Weaver, el agente de escritorio en la PC "${NAME}". Hablas español.`,
    'Operas en ciclos ReAct: piensa, invoca UNA herramienta, observa el resultado, repite.',
    'Cuando el objetivo esté cumplido responde exactamente: RESULT: <resumen final para el usuario>.',
    'Si no puedes continuar (bloqueo real): STUCK: <motivo>.',
    'No emitas RESULT/STUCK y un tool call en el mismo turno.',
    'Cuando termines de usar herramientas, cierra SIEMPRE con una respuesta final: resumen, resultados y pregunta de seguimiento.',
    'Los resultados de las herramientas SON VERDAD — repórtalos tal cual, no los contradigas.'
  ].join('\n');
}

async function chatLLM(messages, tools) {
  const body = {
    model: LLM_MODEL,
    messages: messages.map(m => ({
      role: m.role,
      content: m.content ?? null,
      ...(m.tool_calls ? { tool_calls: m.tool_calls } : {}),
      ...(m.role === 'tool' ? { tool_call_id: m.tool_call_id } : {})
    })),
    tools: tools.map(t => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.parameters } })),
    tool_choice: 'auto'
  };
  const headers = { 'Content-Type': 'application/json' };
  if (LLM_KEY) headers.Authorization = `Bearer ${LLM_KEY}`;
  if (LLM_PROVIDER === 'openrouter') { headers['HTTP-Referer'] = 'https://weaver.app'; headers['X-Title'] = 'Weaver Bridge'; }
  const resp = await fetch(`${LLM_BASE.replace(/\/$/, '')}/chat/completions`, {
    method: 'POST', headers, body: JSON.stringify(body), signal: AbortSignal.timeout(300_000)
  });
  const text = await resp.text();
  if (!resp.ok) throw new Error(`LLM HTTP ${resp.status}: ${text.slice(0, 300)}`);
  const json = JSON.parse(text);
  const msg = json.choices?.[0]?.message || {};
  return { content: msg.content || '', tool_calls: msg.tool_calls || [] };
}

async function runAgentLoop(prompt, emit) {
  const messages = [
    { role: 'system', content: systemPrompt() },
    { role: 'user', content: `Objetivo: ${prompt}` }
  ];
  let round = 0;
  let noProgress = 0;
  let lastFp = '';
  const MAX_ROUNDS = 24;

  while (round < MAX_ROUNDS) {
    round++;
    let result;
    try {
      result = await chatLLM(messages, TOOLS);
    } catch (e) {
      emit({ type: 'error', message: `LLM: ${e.message}` });
      return e.message;
    }
    const { content, tool_calls } = result;

    if (content) emit({ type: 'text', delta: content });

    if (!tool_calls.length) {
      if (content.trim().startsWith('RESULT:')) {
        const final = content.trim().slice(7).trim();
        emit({ type: 'final', text: final });
        return final;
      }
      if (content.trim().startsWith('STUCK:')) {
        const reason = content.trim().slice(6).trim();
        emit({ type: 'final', text: `Me quedé atascado: ${reason}` });
        return reason;
      }
      if (content.trim()) {
        const final = content.trim();
        emit({ type: 'final', text: final });
        return final;
      }
      noProgress++;
    } else {
      messages.push({
        role: 'assistant',
        content: content || null,
        tool_calls: tool_calls
      });
      for (const tc of tool_calls) {
        const fn = tc.function;
        emit({ type: 'tool_call', id: tc.id, name: fn.name, args: safeParse(fn.arguments), round });
        const tool = TOOLS.find(t => t.name === fn.name);
        let out;
        if (!tool) out = { ok: false, output: '', error: `Tool desconocida: ${fn.name}` };
        else {
          try { out = await tool.run(safeParse(fn.arguments)); }
          catch (e) { out = { ok: false, output: '', error: e.message }; }
        }
        const payload = out.ok ? (out.output || '').slice(0, MAX_OUTPUT) : `ERROR: ${out.error || 'desconocido'}`;
        emit({ type: 'tool_result', id: tc.id, name: fn.name, ok: out.ok, output: payload.slice(0, 600), round });
        messages.push({ role: 'tool', tool_call_id: tc.id, content: payload });
      }
      const fp = tool_calls.map(t => `${t.function.name}:${t.function.arguments}`).sort().join('|');
      if (fp === lastFp) noProgress++; else noProgress = 0;
      lastFp = fp;
    }
    if (noProgress >= 3) {
      const msg = 'Bloqueo detectado: 3 rounds sin progreso.';
      emit({ type: 'error', message: msg });
      return msg;
    }
  }
  const msg = `Se alcanzó el límite de ${MAX_ROUNDS} rounds.`;
  emit({ type: 'error', message: msg });
  return msg;
}

function safeParse(s) { try { return JSON.parse(s || '{}'); } catch { return {}; } }

// ───────────────────────────── Servidor HTTP ────────────────────────────────

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);

  if (url.pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, app: 'weaver-bridge', name: NAME, model: LLM_MODEL }));
    return;
  }

  if (url.pathname === '/api/run' && req.method === 'POST') {
    let body = '';
    req.on('data', c => { body += c; if (body.length > 5e6) req.destroy(); });
    req.on('end', async () => {
      let prompt = '', token = '';
      try { const o = JSON.parse(body); prompt = o.prompt || ''; token = o.token || ''; } catch {}
      if (!token || token !== TOKEN) {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Token inválido — escanea el QR de este bridge' }));
        return;
      }
      if (!prompt) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Falta prompt' }));
        return;
      }
      if (!LLM_KEY && LLM_PROVIDER !== 'custom') {
        // Sin key solo puede funcionar contra servidores locales (Ollama/LM Studio)
        if (!/localhost|127\.|192\.168\.|10\./.test(LLM_BASE)) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Configura WEAVER_LLM_KEY en .env o variable de entorno' }));
          return;
        }
      }
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive'
      });
      const emit = (obj) => {
        try { res.write(`data: ${JSON.stringify(obj)}\n\n`); } catch {}
      };
      try {
        await runAgentLoop(prompt, emit);
      } catch (e) {
        emit({ type: 'error', message: e.message });
      }
      res.write('data: [DONE]\n\n');
      res.end();
    });
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Ruta desconocida' }));
});

// ─────────────────────────────── Arranque ───────────────────────────────────

function lanIp() {
  const ifs = os.networkInterfaces();
  for (const list of Object.values(ifs)) {
    for (const i of list || []) {
      if (i.family === 'IPv4' && !i.internal) return i.address;
    }
  }
  return '127.0.0.1';
}

server.listen(PORT, '0.0.0.0', () => {
  const payload = `weaver://bridge?v=1&name=${encodeURIComponent(NAME)}&host=${lanIp()}&port=${PORT}&token=${TOKEN}`;
  console.log('──────────────────────────────────────────────────────');
  console.log(`  Weaver PC Bridge escuchando en http://${lanIp()}:${PORT}`);
  console.log(`  Nombre: ${NAME}   Modelo: ${LLM_MODEL}`);
  console.log('');
  console.log('  Escanea este payload con la app Weaver Android');
  console.log('  (Ajustes → Emparejamiento → Escanear QR PC):');
  console.log('');
  console.log(`  ${payload}`);
  console.log('');
  console.log('  Tip: node weaver-bridge.mjs --link "<QR del teléfono>" para emparejar en ambos sentidos.');
  console.log('──────────────────────────────────────────────────────');
  if (LINK) registerWithPhone(LINK);
});

async function registerWithPhone(linkPayload) {
  try {
    const u = new URL(linkPayload.replace('weaver://phone', 'http://phone'));
    const host = u.searchParams.get('host');
    const port = u.searchParams.get('port');
    const token = u.searchParams.get('token');
    const resp = await fetch(`http://${host}:${port}/api/bridge/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ host: lanIp(), port: PORT, token: TOKEN, name: NAME }),
      signal: AbortSignal.timeout(8000)
    });
    console.log(resp.ok ? '✓ Registrado en el teléfono (emparejamiento bidireccional)' : `✗ Registro falló: HTTP ${resp.status}`);
  } catch (e) {
    console.log(`✗ No se pudo registrar en el teléfono: ${e.message}`);
  }
}
