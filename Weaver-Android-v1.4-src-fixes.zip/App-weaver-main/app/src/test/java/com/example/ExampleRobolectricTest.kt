package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.UserPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Weaver", appName)
  }

  @Test
  fun `verify user preferences onboarding flow defaults and update`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = UserPreferences(context)

    prefs.resetOnboarding()
    assertFalse(prefs.isOnboardingCompleted)

    prefs.agentCallingName = "Jonathan"
    prefs.preferredLanguage = "Español"
    prefs.isOnboardingCompleted = true

    assertTrue(prefs.isOnboardingCompleted)
    assertEquals("Jonathan", prefs.agentCallingName)
    assertEquals("Español", prefs.preferredLanguage)
  }

  @Test
  fun `verify device segment modes`() {
    val movil = com.example.ui.components.DeviceSegmentMode.MOVIL
    val pc = com.example.ui.components.DeviceSegmentMode.PC
    assertEquals("MOVIL", movil.name)
    assertEquals("PC", pc.name)
  }
}
