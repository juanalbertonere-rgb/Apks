package com.example.ui.complementos

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Message
import androidx.compose.material.icons.outlined.NoteAlt
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChatGptBlack
import com.example.ui.theme.ChatGptBorderSubtle
import com.example.ui.theme.ChatGptDrawerBg
import com.example.ui.theme.ChatGptIconColor
import com.example.ui.theme.ChatGptIconMuted
import com.example.ui.theme.ChatGptInputBg
import com.example.ui.theme.ChatGptPillSelected
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptTextSecondary

enum class ComplementosTab {
  SERVIDORES_MCP,
  SKILLS,
  INTEGRACIONES_NATIVAS
}

data class NativeIntegrationItem(
  val id: String,
  val category: String,
  val name: String,
  val description: String,
  val iconColor: Color,
  val iconText: String,
  var isActivated: Boolean = false,
  var configDetails: String = ""
)

data class McpServerItem(
  val id: String,
  val name: String,
  val description: String,
  val iconColor: Color,
  val iconChar: String,
  val isInstalled: Boolean,
  val command: String = "",
  var isActive: Boolean = true
)

@Composable
fun ComplementosScreen(
  onOpenDrawer: () -> Unit,
  onBackToChat: () -> Unit,
  viewModel: com.example.ui.chat.ChatViewModel? = null,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableStateOf(ComplementosTab.INTEGRACIONES_NATIVAS) }
  var searchQuery by remember { mutableStateOf("") }
  var showAllIntegrations by remember { mutableStateOf(true) }

  // Configure dialog state
  var selectedIntegrationForConfig by remember { mutableStateOf<NativeIntegrationItem?>(null) }
  var configInputText by remember { mutableStateOf("") }

  // Sample data states
  val integrations = remember {
    mutableStateListOf(
      NativeIntegrationItem("email", "CORREO", "Correo (IMAP/SMTP)", "Conecta tu cuenta de correo para enviar y recibir mensajes directamente desde...", Color(0xFF2563EB), "@"),
      NativeIntegrationItem("gcal", "CALENDARIOS PC", "Google Calendar", "Sincroniza eventos con tu Google Calendar. El agente puede preguntar...", Color(0xFF3B82F6), "Cal"),
      NativeIntegrationItem("outlook_cal", "CALENDARIOS PC", "Outlook Calendar", "Sincroniza con tu calendario de Outlook/Microsoft 365.", Color(0xFF0284C7), "Out"),
      NativeIntegrationItem("apple_cal", "CALENDARIOS PC", "Apple Calendar", "Calendario de macOS via EventKit (solo en macOS).", Color(0xFFEF4444), "Ap"),
      NativeIntegrationItem("gdrive", "NUBE", "Google Drive", "Acceso a tus archivos de Drive.", Color(0xFF10B981), "D"),
      NativeIntegrationItem("onedrive", "NUBE", "OneDrive", "Acceso a tus archivos de OneDrive.", Color(0xFF0284C7), "OD"),
      NativeIntegrationItem("dropbox", "NUBE", "Dropbox", "Acceso a tus archivos de Dropbox.", Color(0xFF2563EB), "Db"),
      NativeIntegrationItem("todoist", "TAREAS EXTERNAS", "Todoist", "Sincroniza tareas con tu cuenta Todoist.", Color(0xFFDC2626), "T"),
      NativeIntegrationItem("ticktick", "TAREAS EXTERNAS", "TickTick", "Sincroniza tareas con TickTick.", Color(0xFF3B82F6), "Tt"),
      NativeIntegrationItem("notion", "NOTAS EXTERNAS", "Notion", "Acceso a tus bases de datos y páginas de Notion.", Color(0xFF18181B), "N"),
      NativeIntegrationItem("obsidian", "NOTAS EXTERNAS", "Obsidian", "Lee y escribe notas en tu bóveda de Obsidian (vía ruta local).", Color(0xFF8B5CF6), "Ob"),
      NativeIntegrationItem("telegram", "MENSAJERÍA", "Telegram", "Envía mensajes vía Telegram Bot API.", Color(0xFF0EA5E9), "Tg", isActivated = true),
      NativeIntegrationItem("whatsapp", "MENSAJERÍA", "WhatsApp (Twilio)", "Envía mensajes por WhatsApp Business API vía Twilio.", Color(0xFF22C55E), "Wa"),
      NativeIntegrationItem("slack", "MENSAJERÍA", "Slack", "Publica mensajes en canales de Slack.", Color(0xFF9333EA), "Sl"),
      NativeIntegrationItem("openweather", "CLIMA", "OpenWeather", "Datos meteorológicos extendidos (ya integrado en ME > Clima con Open-...", Color(0xFF0284C7), "W"),
      NativeIntegrationItem("gmaps", "MAPAS", "Google Maps", "Rutas, lugares y direcciones.", Color(0xFF10B981), "M"),
      NativeIntegrationItem("osm", "MAPAS", "OpenStreetMap", "Geocoding y rutas vía OSRM / Nominatim (gratis, sin API key).", Color(0xFF15803D), "OSM"),
      NativeIntegrationItem("homeassistant", "SMART HOME", "Home Assistant", "Controla luces, sensores y dispositivos de tu casa.", Color(0xFF0284C7), "HA"),
      NativeIntegrationItem("philipshue", "SMART HOME", "Philips Hue", "Controla tus bombillas Hue.", Color(0xFFEAB308), "H")
    )
  }

  val mcpCatalog = remember {
    mutableStateListOf(
      McpServerItem("github", "GitHub", "Repositorios, issues, PRs, commits, actions y más desde GitHub.", Color(0xFF24292F), "GH", isInstalled = true, command = "stdio: npx -y @modelcontextprotocol/server-github", isActive = true),
      McpServerItem("playwright", "Playwright", "Automatización de navegador: navegar, capturar pantalla y rellenar formularios.", Color(0xFF22C55E), "PW", isInstalled = false),
      McpServerItem("gdrive_mcp", "Google Drive", "Buscar y leer archivos de tu Google Drive.", Color(0xFF10B981), "GD", isInstalled = false),
      McpServerItem("notion_mcp", "Notion", "Buscar, leer y editar páginas y bases de datos de Notion.", Color(0xFF18181B), "NO", isInstalled = false),
      McpServerItem("figma", "Figma", "Leer diseños, componentes y estilos de archivos de Figma.", Color(0xFFEA580C), "FG", isInstalled = false),
      McpServerItem("memory", "Memory", "Grafo de conocimiento y memoria persistente basada en grafos.", Color(0xFF8B5CF6), "ME", isInstalled = false)
    )
  }

  val installedSkills = remember { mutableStateListOf<String>() }
  var isFindSkillsInstalled by remember { mutableStateOf(false) }
  var skillUrlInput by remember { mutableStateOf("") }
  var skillNameInput by remember { mutableStateOf("") }

  Surface(
    modifier = modifier
      .fillMaxSize()
      .statusBarsPadding()
      .navigationBarsPadding(),
    color = ChatGptBlack
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
    ) {
      // Top Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onOpenDrawer,
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Menu,
              contentDescription = "Abrir menú",
              tint = ChatGptIconColor,
              modifier = Modifier.size(22.dp)
            )
          }

          Spacer(modifier = Modifier.width(4.dp))

          IconButton(
            onClick = onBackToChat,
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
              contentDescription = "Volver al chat",
              tint = ChatGptTextSecondary,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      // Title & Subtitle matching Screenshot 1, 2, 3, 9
      Text(
        text = "Complementos",
        fontSize = 26.sp,
        fontWeight = FontWeight.Bold,
        color = ChatGptTextPrimary
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "Haz que Weaver se adapte a tu estilo. Conecta servidores MCP, instala skills de skills.sh y aprende de tus flujos.",
        fontSize = 13.5.sp,
        color = ChatGptTextSecondary,
        lineHeight = 18.sp
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Tab selector header (Servidores MCP 1 · Skills 0 · Integraciones nativas)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        TabPill(
          title = "Servidores MCP",
          badge = mcpCatalog.count { it.isInstalled }.toString(),
          isSelected = selectedTab == ComplementosTab.SERVIDORES_MCP,
          onClick = { selectedTab = ComplementosTab.SERVIDORES_MCP }
        )

        TabPill(
          title = "Skills",
          badge = (installedSkills.size + if (isFindSkillsInstalled) 1 else 0).toString(),
          isSelected = selectedTab == ComplementosTab.SKILLS,
          onClick = { selectedTab = ComplementosTab.SKILLS }
        )

        TabPill(
          title = "Integraciones nativas",
          icon = Icons.Outlined.Bolt,
          iconColor = Color(0xFFFBBF24),
          isSelected = selectedTab == ComplementosTab.INTEGRACIONES_NATIVAS,
          onClick = { selectedTab = ComplementosTab.INTEGRACIONES_NATIVAS }
        )
      }

      Spacer(modifier = Modifier.height(12.dp))
      HorizontalDivider(color = ChatGptBorderSubtle, thickness = 1.dp)
      Spacer(modifier = Modifier.height(12.dp))

      // Tab Content
      when (selectedTab) {
        ComplementosTab.INTEGRACIONES_NATIVAS -> {
          IntegracionesNativasContent(
            integraciones = integrations,
            searchQuery = searchQuery,
            onSearchChanged = { searchQuery = it },
            showAll = showAllIntegrations,
            onToggleShowAll = { showAllIntegrations = !showAllIntegrations },
            onToggleActivate = { item ->
              val index = integrations.indexOfFirst { it.id == item.id }
              if (index != -1) {
                integrations[index] = integrations[index].copy(isActivated = !integrations[index].isActivated)
              }
            },
            onConfigure = { item ->
              selectedIntegrationForConfig = item
              configInputText = item.configDetails
            }
          )
        }
        ComplementosTab.SKILLS -> {
          SkillsContent(
            isFindSkillsInstalled = isFindSkillsInstalled,
            onToggleFindSkills = { isFindSkillsInstalled = !isFindSkillsInstalled },
            skillUrlInput = skillUrlInput,
            onUrlChanged = { skillUrlInput = it },
            skillNameInput = skillNameInput,
            onNameChanged = { skillNameInput = it },
            installedSkills = installedSkills,
            onInstallSkill = {
              if (skillUrlInput.isNotBlank()) {
                val name = skillNameInput.ifBlank { skillUrlInput.substringAfterLast("/") }
                installedSkills.add(name)
                skillUrlInput = ""
                skillNameInput = ""
              }
            },
            onDeleteSkill = { installedSkills.remove(it) }
          )
        }
        ComplementosTab.SERVIDORES_MCP -> {
          // Tarjeta REAL: servidores MCP HTTP configurados en este teléfono
          // (Settings → Servidores MCP). Estos son los que el agente usa.
          RealMcpServersCard(viewModel = viewModel)
          McpServersContent(
            catalog = mcpCatalog,
            onInstall = { item ->
              val index = mcpCatalog.indexOfFirst { it.id == item.id }
              if (index != -1) {
                mcpCatalog[index] = mcpCatalog[index].copy(
                  isInstalled = true,
                  command = "stdio: npx -y @modelcontextprotocol/server-${item.id}",
                  isActive = true
                )
              }
            },
            onToggleActive = { item ->
              val index = mcpCatalog.indexOfFirst { it.id == item.id }
              if (index != -1) {
                mcpCatalog[index] = mcpCatalog[index].copy(isActive = !mcpCatalog[index].isActive)
              }
            },
            onDelete = { item ->
              val index = mcpCatalog.indexOfFirst { it.id == item.id }
              if (index != -1) {
                mcpCatalog[index] = mcpCatalog[index].copy(isInstalled = false)
              }
            },
            onAddCustom = { name, cmd ->
              mcpCatalog.add(
                McpServerItem(
                  id = name.lowercase().replace(" ", "_"),
                  name = name,
                  description = "Servidor MCP personalizado.",
                  iconColor = Color(0xFF3F3F46),
                  iconChar = "MCP",
                  isInstalled = true,
                  command = cmd,
                  isActive = true
                )
              )
            }
          )
        }
      }
    }
  }

  // Configuration Dialog
  val configItem = selectedIntegrationForConfig
  if (configItem != null) {
    AlertDialog(
      onDismissRequest = { selectedIntegrationForConfig = null },
      containerColor = ChatGptDrawerBg,
      title = {
        Text("Configurar ${configItem.name}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
      },
      text = {
        Column {
          Text(
            text = "Introduce credenciales, servidor o tokens para conectar con tu cuenta de ${configItem.name}:",
            color = ChatGptTextSecondary,
            fontSize = 13.5.sp
          )
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = configInputText,
            onValueChange = { configInputText = it },
            placeholder = { Text("API Key, URL o credencial...", color = ChatGptTextMuted, fontSize = 13.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = ChatGptInputBg,
              unfocusedContainerColor = ChatGptInputBg,
              focusedBorderColor = Color(0xFF3B82F6),
              unfocusedBorderColor = ChatGptBorderSubtle,
              focusedTextColor = ChatGptTextPrimary,
              unfocusedTextColor = ChatGptTextPrimary
            )
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val index = integrations.indexOfFirst { it.id == configItem.id }
            if (index != -1) {
              integrations[index] = integrations[index].copy(
                configDetails = configInputText,
                isActivated = true
              )
            }
            selectedIntegrationForConfig = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
        ) {
          Text("Guardar y activar")
        }
      },
      dismissButton = {
        TextButton(onClick = { selectedIntegrationForConfig = null }) {
          Text("Cancelar", color = ChatGptTextMuted)
        }
      }
    )
  }
}

@Composable
private fun TabPill(
  title: String,
  badge: String? = null,
  icon: ImageVector? = null,
  iconColor: Color = Color.Unspecified,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .background(if (isSelected) ChatGptPillSelected else Color.Transparent)
      .border(
        width = 1.dp,
        color = if (isSelected) Color(0xFF3F3F46) else Color.Transparent,
        shape = RoundedCornerShape(8.dp)
      )
      .clickable { onClick() }
      .padding(horizontal = 10.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    if (icon != null) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = iconColor,
        modifier = Modifier.size(15.dp)
      )
      Spacer(modifier = Modifier.width(6.dp))
    }
    Text(
      text = title,
      fontSize = 13.sp,
      fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
      color = if (isSelected) Color.White else ChatGptTextSecondary
    )
    if (badge != null) {
      Spacer(modifier = Modifier.width(6.dp))
      Box(
        modifier = Modifier
          .clip(CircleShape)
          .background(if (isSelected) Color(0xFF3F3F46) else Color(0xFF27272A))
          .padding(horizontal = 6.dp, vertical = 1.dp)
      ) {
        Text(
          text = badge,
          fontSize = 11.sp,
          color = if (isSelected) Color.White else ChatGptTextMuted
        )
      }
    }
  }
}

// ---------------------------------------------------------------------------------
// TAB 1: INTEGRACIONES NATIVAS CONTENT (Screenshots 1 & 2)
// ---------------------------------------------------------------------------------
@Composable
private fun IntegracionesNativasContent(
  integraciones: List<NativeIntegrationItem>,
  searchQuery: String,
  onSearchChanged: (String) -> Unit,
  showAll: Boolean,
  onToggleShowAll: () -> Unit,
  onToggleActivate: (NativeIntegrationItem) -> Unit,
  onConfigure: (NativeIntegrationItem) -> Unit
) {
  val filtered = remember(integraciones, searchQuery) {
    if (searchQuery.isBlank()) integraciones
    else integraciones.filter {
      it.name.contains(searchQuery, ignoreCase = true) ||
      it.category.contains(searchQuery, ignoreCase = true) ||
      it.description.contains(searchQuery, ignoreCase = true)
    }
  }

  val displayList = if (showAll || searchQuery.isNotBlank()) filtered else filtered.take(5)

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Outlined.Bolt,
          contentDescription = null,
          tint = Color(0xFFFBBF24),
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Integraciones nativas",
          fontSize = 14.sp,
          fontWeight = FontWeight.SemiBold,
          color = ChatGptTextPrimary
        )
      }
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Conexiones directas (no MCP) con servicios externos. El agente puede usar estas integraciones cuando le pidas cosas como \"envía un correo\", \"enciende las luces\", \"¿cómo llego a...?\" o \"organiza mi calendario de la PC\".",
        fontSize = 12.5.sp,
        color = ChatGptTextMuted,
        lineHeight = 17.sp
      )
      Spacer(modifier = Modifier.height(10.dp))

      // Search input
      OutlinedTextField(
        value = searchQuery,
        onValueChange = onSearchChanged,
        placeholder = { Text("Buscar integraciones...", fontSize = 13.sp, color = ChatGptTextMuted) },
        leadingIcon = {
          Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = ChatGptTextMuted, modifier = Modifier.size(18.dp))
        },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = ChatGptInputBg,
          unfocusedContainerColor = ChatGptInputBg,
          focusedBorderColor = Color(0xFF3F3F46),
          unfocusedBorderColor = ChatGptBorderSubtle,
          focusedTextColor = ChatGptTextPrimary,
          unfocusedTextColor = ChatGptTextPrimary
        )
      )
      Spacer(modifier = Modifier.height(12.dp))
    }

    // Group items by category
    val categories = displayList.groupBy { it.category }
    categories.forEach { (cat, items) ->
      item {
        Text(
          text = cat,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = ChatGptTextMuted,
          letterSpacing = 0.5.sp,
          modifier = Modifier.padding(vertical = 4.dp)
        )
      }

      items(items) { item ->
        IntegrationCard(
          item = item,
          onToggle = { onToggleActivate(item) },
          onConfigure = { onConfigure(item) }
        )
      }
    }

    item {
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onToggleShowAll() }
          .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = if (showAll) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
          contentDescription = null,
          tint = ChatGptTextMuted,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = if (showAll) "Mostrar menos" else "Mostrar todos (${integraciones.size})",
          fontSize = 13.sp,
          color = ChatGptTextSecondary
        )
      }
      Spacer(modifier = Modifier.height(20.dp))
    }
  }
}

@Composable
private fun IntegrationCard(
  item: NativeIntegrationItem,
  onToggle: () -> Unit,
  onConfigure: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(ChatGptInputBg)
      .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(12.dp))
      .padding(12.dp)
  ) {
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          // Icon badge
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(item.iconColor),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = item.iconText,
              color = Color.White,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Text(
            text = item.name,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = ChatGptTextPrimary
          )

          if (item.isActivated) {
            Spacer(modifier = Modifier.width(6.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF064E3B))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = "activa",
                fontSize = 10.sp,
                color = Color(0xFF34D399),
                fontWeight = FontWeight.Medium
              )
            }
          }
        }

        // Action button (Activar or Activada)
        if (item.isActivated) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFF064E3B))
              .border(1.dp, Color(0xFF059669), RoundedCornerShape(8.dp))
              .clickable { onToggle() }
              .padding(horizontal = 10.dp, vertical = 5.dp)
          ) {
            Text(
              text = "Activada",
              fontSize = 12.sp,
              color = Color(0xFF34D399),
              fontWeight = FontWeight.Medium
            )
          }
        } else {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(ChatGptPillSelected)
              .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(8.dp))
              .clickable { onToggle() }
              .padding(horizontal = 10.dp, vertical = 5.dp)
          ) {
            Text(
              text = "Activar",
              fontSize = 12.sp,
              color = ChatGptTextSecondary,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = item.description,
        fontSize = 12.sp,
        color = ChatGptTextMuted,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "Configurar",
        fontSize = 11.5.sp,
        color = ChatGptTextSecondary,
        modifier = Modifier
          .clickable { onConfigure() }
          .padding(vertical = 2.dp)
      )
    }
  }
}

// ---------------------------------------------------------------------------------
// TAB 2: SKILLS CONTENT (Screenshot 3)
// ---------------------------------------------------------------------------------
@Composable
private fun SkillsContent(
  isFindSkillsInstalled: Boolean,
  onToggleFindSkills: () -> Unit,
  skillUrlInput: String,
  onUrlChanged: (String) -> Unit,
  skillNameInput: String,
  onNameChanged: (String) -> Unit,
  installedSkills: List<String>,
  onInstallSkill: () -> Unit,
  onDeleteSkill: (String) -> Unit
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Recommendation card
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(ChatGptInputBg)
          .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(12.dp))
          .padding(14.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
          ) {
            Icon(
              imageVector = Icons.Outlined.AutoAwesome,
              contentDescription = null,
              tint = Color(0xFF60A5FA),
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Instalar find-skills (recomendado)",
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = ChatGptTextPrimary
              )
              Text(
                text = "Permite a Weaver descubrir nuevas skills de la comunidad.",
                fontSize = 12.sp,
                color = ChatGptTextMuted
              )
            }
          }

          Button(
            onClick = onToggleFindSkills,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isFindSkillsInstalled) Color(0xFF064E3B) else Color.White,
              contentColor = if (isFindSkillsInstalled) Color(0xFF34D399) else Color.Black
            ),
            modifier = Modifier.height(34.dp)
          ) {
            if (isFindSkillsInstalled) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Instalado", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
              }
            } else {
              Text(text = "+ Instalar", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }

    // Instalar skill desde URL
    item {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Outlined.Link,
          contentDescription = null,
          tint = ChatGptTextPrimary,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Instalar skill desde URL",
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = ChatGptTextPrimary
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      OutlinedTextField(
        value = skillUrlInput,
        onValueChange = onUrlChanged,
        placeholder = { Text("https://github.com/vercel-labs/skills", fontSize = 13.sp, color = ChatGptTextMuted) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = ChatGptInputBg,
          unfocusedContainerColor = ChatGptInputBg,
          focusedBorderColor = Color(0xFF3F3F46),
          unfocusedBorderColor = ChatGptBorderSubtle,
          focusedTextColor = ChatGptTextPrimary,
          unfocusedTextColor = ChatGptTextPrimary
        )
      )

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = skillNameInput,
          onValueChange = onNameChanged,
          placeholder = { Text("nombre (opcional)", fontSize = 13.sp, color = ChatGptTextMuted) },
          singleLine = true,
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = ChatGptInputBg,
            unfocusedContainerColor = ChatGptInputBg,
            focusedBorderColor = Color(0xFF3F3F46),
            unfocusedBorderColor = ChatGptBorderSubtle,
            focusedTextColor = ChatGptTextPrimary,
            unfocusedTextColor = ChatGptTextPrimary
          )
        )

        Button(
          onClick = onInstallSkill,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
          modifier = Modifier.height(48.dp)
        ) {
          Text("Instalar", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
      }

      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Equivale a: npx skills add <url> --skill <name>",
        fontSize = 11.5.sp,
        color = ChatGptTextMuted
      )
    }

    // Skills instaladas list
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "Skills instaladas (${installedSkills.size + if (isFindSkillsInstalled) 1 else 0})",
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = ChatGptTextPrimary
      )
      Spacer(modifier = Modifier.height(6.dp))

      if (installedSkills.isEmpty() && !isFindSkillsInstalled) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ChatGptInputBg)
            .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(10.dp))
            .padding(24.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "Aún no hay skills instaladas.",
            fontSize = 13.sp,
            color = ChatGptTextMuted
          )
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          if (isFindSkillsInstalled) {
            SkillInstalledRow(name = "find-skills (oficial)", onRemove = onToggleFindSkills)
          }
          installedSkills.forEach { skill ->
            SkillInstalledRow(name = skill, onRemove = { onDeleteSkill(skill) })
          }
        }
      }
    }
  }
}

@Composable
private fun SkillInstalledRow(name: String, onRemove: () -> Unit) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(10.dp))
      .background(ChatGptInputBg)
      .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(10.dp))
      .padding(horizontal = 14.dp, vertical = 10.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = Icons.Outlined.AutoAwesome,
        contentDescription = null,
        tint = Color(0xFF34D399),
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text(text = name, fontSize = 13.5.sp, color = ChatGptTextPrimary)
    }

    IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
      Icon(
        imageVector = Icons.Default.DeleteOutline,
        contentDescription = "Eliminar",
        tint = ChatGptTextMuted,
        modifier = Modifier.size(18.dp)
      )
    }
  }
}

// ---------------------------------------------------------------------------------
// TAB 3: SERVIDORES MCP CONTENT (Screenshot 9)
// ---------------------------------------------------------------------------------
@Composable
private fun McpServersContent(
  catalog: List<McpServerItem>,
  onInstall: (McpServerItem) -> Unit,
  onToggleActive: (McpServerItem) -> Unit,
  onDelete: (McpServerItem) -> Unit,
  onAddCustom: (String, String) -> Unit
) {
  var customName by remember { mutableStateOf("") }
  var customCmd by remember { mutableStateOf("") }

  val installed = catalog.filter { it.isInstalled }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Outlined.Settings,
          contentDescription = null,
          tint = ChatGptTextPrimary,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Servidores MCP — Catálogo",
          fontSize = 14.sp,
          fontWeight = FontWeight.SemiBold,
          color = ChatGptTextPrimary
        )
      }
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = "Instala servidores MCP oficiales con un solo click. Cada uno requiere credenciales que se te pedirán al instalar.",
        fontSize = 12.5.sp,
        color = ChatGptTextMuted,
        lineHeight = 17.sp
      )
    }

    // Catalog items
    items(catalog) { item ->
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(ChatGptInputBg)
          .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(12.dp))
          .padding(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
          ) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(item.iconColor),
              contentAlignment = Alignment.Center
            ) {
              Text(text = item.iconChar, fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = item.name, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = ChatGptTextPrimary)
                if (item.isInstalled) {
                  Spacer(modifier = Modifier.width(6.dp))
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color(0xFF34D399), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(text = "instalado", fontSize = 11.sp, color = Color(0xFF34D399))
                  }
                }
              }
              Text(text = item.description, fontSize = 12.sp, color = ChatGptTextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
          }

          if (item.isInstalled) {
            IconButton(onClick = { onDelete(item) }, modifier = Modifier.size(30.dp)) {
              Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Eliminar", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
            }
          } else {
            Button(
              onClick = { onInstall(item) },
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
              modifier = Modifier.height(32.dp)
            ) {
              Text("+ Instalar", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }

    // Section: Instalados (1)
    if (installed.isNotEmpty()) {
      item {
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Outlined.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF34D399),
            modifier = Modifier.size(15.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Instalados (${installed.size})",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = ChatGptTextPrimary
          )
        }
      }

      items(installed) { item ->
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ChatGptInputBg)
            .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(12.dp))
            .padding(12.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Box(
                modifier = Modifier
                  .size(30.dp)
                  .clip(RoundedCornerShape(6.dp))
                  .background(item.iconColor),
                contentAlignment = Alignment.Center
              ) {
                Text(text = item.iconChar, fontSize = 14.sp)
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(text = item.name, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = ChatGptTextPrimary)
                Text(text = item.command, fontSize = 11.5.sp, color = ChatGptTextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
              }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(if (item.isActive) Color(0xFF064E3B) else Color(0xFF27272A))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = if (item.isActive) "activo" else "inactivo",
                  fontSize = 10.sp,
                  color = if (item.isActive) Color(0xFF34D399) else ChatGptTextMuted
                )
              }

              IconButton(onClick = { onToggleActive(item) }, modifier = Modifier.size(28.dp)) {
                Icon(
                  imageVector = Icons.Default.PowerSettingsNew,
                  contentDescription = "Encender/Apagar",
                  tint = if (item.isActive) Color(0xFF34D399) else ChatGptTextMuted,
                  modifier = Modifier.size(16.dp)
                )
              }

              IconButton(onClick = { onDelete(item) }, modifier = Modifier.size(28.dp)) {
                Icon(
                  imageVector = Icons.Default.DeleteOutline,
                  contentDescription = "Eliminar",
                  tint = Color(0xFFEF4444),
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          }
        }
      }
    }

    // Section: + Añadir servidor MCP personalizado
    item {
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "+ Añadir servidor MCP personalizado",
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = ChatGptTextPrimary
      )
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedTextField(
          value = customName,
          onValueChange = { customName = it },
          placeholder = { Text("nombre del servidor", fontSize = 12.sp, color = ChatGptTextMuted) },
          singleLine = true,
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(8.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = ChatGptInputBg,
            unfocusedContainerColor = ChatGptInputBg,
            focusedBorderColor = Color(0xFF3F3F46),
            unfocusedBorderColor = ChatGptBorderSubtle,
            focusedTextColor = ChatGptTextPrimary,
            unfocusedTextColor = ChatGptTextPrimary
          )
        )

        OutlinedTextField(
          value = customCmd,
          onValueChange = { customCmd = it },
          placeholder = { Text("paquete npm o comando", fontSize = 12.sp, color = ChatGptTextMuted) },
          singleLine = true,
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(8.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = ChatGptInputBg,
            unfocusedContainerColor = ChatGptInputBg,
            focusedBorderColor = Color(0xFF3F3F46),
            unfocusedBorderColor = ChatGptBorderSubtle,
            focusedTextColor = ChatGptTextPrimary,
            unfocusedTextColor = ChatGptTextPrimary
          )
        )

        Button(
          onClick = {
            if (customName.isNotBlank() && customCmd.isNotBlank()) {
              onAddCustom(customName, customCmd)
              customName = ""
              customCmd = ""
            }
          },
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
          modifier = Modifier.height(48.dp)
        ) {
          Text("+ Añadir", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
      }

      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Para servidores MCP no incluidos en el catálogo de arriba.",
        fontSize = 11.sp,
        color = ChatGptTextMuted
      )
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

/**
 * Card con los servidores MCP HTTP REALES de este teléfono (Settings.mcpServers).
 * Son los que el AgentController registra en cada turno; un switch los activa
 * o desactiva sin reiniciar la app.
 */
@Composable
fun RealMcpServersCard(viewModel: com.example.ui.chat.ChatViewModel?) {
  if (viewModel == null) return
  val settings = viewModel.settings
  var servers by remember { mutableStateOf(settings.mcpServers) }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
      .clip(RoundedCornerShape(12.dp))
      .background(ChatGptInputBg)
      .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(12.dp))
      .padding(14.dp)
  ) {
    Text(
      "Tus servidores MCP HTTP (activos en el agente)",
      fontSize = 13.sp,
      fontWeight = FontWeight.Bold,
      color = ChatGptTextPrimary
    )
    Spacer(Modifier.height(6.dp))
    if (servers.length() == 0) {
      Text(
        "Aún no hay servidores. Agrégalos en Weaver → Drawer → Ajustes → Servidores MCP (URL http://…/mcp). En Android los servidores MCP funcionan por HTTP, no por stdio.",
        fontSize = 12.sp,
        color = ChatGptTextMuted
      )
    } else {
      for (i in 0 until servers.length()) {
        val s = servers.optJSONObject(i) ?: continue
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
        ) {
          Column(Modifier.weight(1f)) {
            Text(s.optString("name"), fontSize = 13.sp, color = ChatGptTextPrimary)
            Text(s.optString("url"), fontSize = 11.sp, color = ChatGptTextMuted, maxLines = 1)
          }
          Text(
            text = if (s.optBoolean("enabled", true)) "Activo" else "Pausado",
            fontSize = 11.sp,
            color = if (s.optBoolean("enabled", true)) Color(0xFF34D399) else ChatGptTextMuted
          )
        }
      }
    }
  }
}
