package com.example.ui.notebooks

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Quiz
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.TableChart
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material.icons.outlined.ViewModule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateListOf
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChatGptBlack
import com.example.ui.theme.ChatGptBorderSubtle
import com.example.ui.theme.ChatGptDrawerBg
import com.example.ui.theme.ChatGptIconColor
import com.example.ui.theme.ChatGptIconMuted
import com.example.ui.theme.ChatGptInputBg
import com.example.ui.theme.ChatGptPillSelected
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptTextSecondary

data class NotebookItem(
  val id: String,
  var title: String,
  var sourcesCount: Int,
  var messagesCount: Int,
  val updatedAt: String
)

data class NotebookSource(
  val id: String,
  val title: String,
  val sizeText: String,
  val type: String = "URL"
)

data class NotebookMessage(
  val isUser: Boolean,
  val text: String,
  val sourceCitation: String? = null
)

enum class NotebookDetailTab {
  FUENTES,
  CHAT,
  STUDIO
}

@Composable
fun NotebooksScreen(
  onOpenDrawer: () -> Unit,
  onBackToChat: () -> Unit,
  viewModel: com.example.ui.chat.ChatViewModel? = null,
  modifier: Modifier = Modifier
) {
  // State: selected notebook for detail view or null for list view
  var activeNotebook by remember {
    mutableStateOf<NotebookItem?>(null)
  }

  // Notebooks REALES de Room (kind = "notebook"); el agente crea notebooks
  // con me_create_note(notebook=...).
  val scope = androidx.compose.runtime.rememberCoroutineScope()
  val dao = viewModel?.database?.meItems()
  val notebooksFlow = dao?.observeByKind("notebook")?.collectAsState(initial = emptyList())
  val notebooks = remember(notebooksFlow?.value) {
    androidx.compose.runtime.mutableStateListOf<NotebookItem>().apply {
      addAll((notebooksFlow?.value ?: emptyList()).map { e ->
        NotebookItem(
          id = e.id,
          title = e.title,
          sourcesCount = 0,
          messagesCount = 0,
          updatedAt = java.text.SimpleDateFormat("d/M/yyyy, h:mm:ss a", java.util.Locale.getDefault()).format(java.util.Date(e.updatedAt))
        )
      })
    }
  }

  var showNewNotebookDialog by remember { mutableStateOf(false) }
  var newNotebookTitle by remember { mutableStateOf("") }

  if (activeNotebook != null) {
    NotebookDetailView(
      notebook = activeNotebook!!,
      onBackToList = { activeNotebook = null },
      onOpenDrawer = onOpenDrawer
    )
  } else {
    Surface(
      modifier = modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding(),
      color = ChatGptBlack
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp)
      ) {
        // Top Navigation Row
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onOpenDrawer, modifier = Modifier.size(36.dp)) {
              Icon(imageVector = Icons.Default.Menu, contentDescription = "Menú", tint = ChatGptIconColor, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(4.dp))
            IconButton(onClick = onBackToChat, modifier = Modifier.size(36.dp)) {
              Icon(imageVector = Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Volver", tint = ChatGptTextSecondary, modifier = Modifier.size(20.dp))
            }
          }
        }

        // Header and subtitle
        Text(
          text = "Notebooks",
          fontSize = 26.sp,
          fontWeight = FontWeight.Bold,
          color = ChatGptTextPrimary
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "Cuadernos de investigación: carga fuentes (PDFs, Markdown, URLs) y chatea sobre ellas con respuestas ancladas en tus documentos. Usa el mismo modelo activo del chat principal de Weaver, con sus propias herramientas de búsqueda.",
          fontSize = 13.sp,
          color = ChatGptTextSecondary,
          lineHeight = 18.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Action buttons: Importar · Seleccionar · + Nuevo
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedButton(
            onClick = { /* Import */ },
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = ChatGptTextSecondary),
            modifier = Modifier.height(34.dp)
          ) {
            Icon(imageVector = Icons.Outlined.Download, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Importar", fontSize = 12.sp)
          }

          OutlinedButton(
            onClick = { /* Select */ },
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = ChatGptTextSecondary),
            modifier = Modifier.height(34.dp)
          ) {
            Icon(imageVector = Icons.Outlined.ViewModule, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Seleccionar", fontSize = 12.sp)
          }

          Spacer(modifier = Modifier.weight(1f))

          Button(
            onClick = { showNewNotebookDialog = true },
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
            modifier = Modifier.height(34.dp)
          ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("+ Nuevo", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider(color = ChatGptBorderSubtle, thickness = 1.dp)
        Spacer(modifier = Modifier.height(16.dp))

        // Notebooks list
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(notebooks) { nb ->
            NotebookCard(
              notebook = nb,
              onClick = { activeNotebook = nb },
              onDelete = {
                scope.launch { dao?.delete(nb.id) }
                notebooks.remove(nb)
              }
            )
          }
        }
      }
    }
  }

  // Create Notebook Dialog
  if (showNewNotebookDialog) {
    AlertDialog(
      onDismissRequest = { showNewNotebookDialog = false },
      containerColor = ChatGptDrawerBg,
      title = { Text("Nuevo Notebook", color = ChatGptTextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        OutlinedTextField(
          value = newNotebookTitle,
          onValueChange = { newNotebookTitle = it },
          placeholder = { Text("Título del cuaderno...", color = ChatGptTextMuted) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = ChatGptInputBg,
            unfocusedContainerColor = ChatGptInputBg,
            focusedBorderColor = Color(0xFF3B82F6),
            unfocusedBorderColor = ChatGptBorderSubtle,
            focusedTextColor = ChatGptTextPrimary,
            unfocusedTextColor = ChatGptTextPrimary
          )
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (newNotebookTitle.isNotBlank()) {
              val item = NotebookItem(
                id = "nb_${System.currentTimeMillis()}",
                title = newNotebookTitle.trim(),
                sourcesCount = 0,
                messagesCount = 0,
                updatedAt = "Ahora"
              )
              scope.launch {
                dao?.upsert(
                  com.example.data.db.MeItemEntity(
                    id = item.id,
                    kind = "notebook",
                    title = item.title
                  )
                )
              }
              notebooks.add(item)
              newNotebookTitle = ""
              showNewNotebookDialog = false
              activeNotebook = item
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
        ) {
          Text("Crear")
        }
      },
      dismissButton = {
        TextButton(onClick = { showNewNotebookDialog = false }) {
          Text("Cancelar", color = ChatGptTextMuted)
        }
      }
    )
  }
}

@Composable
private fun NotebookCard(
  notebook: NotebookItem,
  onClick: () -> Unit,
  onDelete: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(ChatGptInputBg)
      .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(12.dp))
      .clickable { onClick() }
      .padding(14.dp)
  ) {
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = notebook.title,
          fontSize = 16.sp,
          fontWeight = FontWeight.SemiBold,
          color = ChatGptTextPrimary
        )

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(onClick = { /* share */ }, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Outlined.Share, contentDescription = "Compartir", tint = ChatGptTextMuted, modifier = Modifier.size(16.dp))
          }
          IconButton(onClick = { /* download */ }, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Outlined.Download, contentDescription = "Descargar", tint = ChatGptTextMuted, modifier = Modifier.size(16.dp))
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Borrar", tint = ChatGptTextMuted, modifier = Modifier.size(16.dp))
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(imageVector = Icons.Outlined.Description, contentDescription = null, tint = ChatGptTextMuted, modifier = Modifier.size(13.dp))
        Text(text = "${notebook.sourcesCount} fuentes", fontSize = 12.sp, color = ChatGptTextMuted)
        Text(text = "·", fontSize = 12.sp, color = ChatGptTextMuted)
        Icon(imageVector = Icons.Outlined.ChatBubbleOutline, contentDescription = null, tint = ChatGptTextMuted, modifier = Modifier.size(13.dp))
        Text(text = "${notebook.messagesCount} mensajes", fontSize = 12.sp, color = ChatGptTextMuted)
        Text(text = "·", fontSize = 12.sp, color = ChatGptTextMuted)
        Icon(imageVector = Icons.Outlined.Schedule, contentDescription = null, tint = ChatGptTextMuted, modifier = Modifier.size(13.dp))
        Text(text = notebook.updatedAt, fontSize = 12.sp, color = ChatGptTextMuted)
      }
    }
  }
}

// ---------------------------------------------------------------------------------
// NOTEBOOK DETAIL VIEW (Screenshots 4, 5, 8)
// ---------------------------------------------------------------------------------
@Composable
private fun NotebookDetailView(
  notebook: NotebookItem,
  onBackToList: () -> Unit,
  onOpenDrawer: () -> Unit
) {
  var selectedTab by remember { mutableStateOf(NotebookDetailTab.FUENTES) }

  // Sources in this notebook
  val sources = remember {
    mutableStateListOf(
      NotebookSource("src_1", "Benchmarking GPT-6 Astra", "5.8 KB", "URL"),
      NotebookSource("src_2", "Arquitectura AT-SPI en Linux", "12.4 KB", "DOC")
    )
  }

  // Chat messages in this notebook
  val messages = remember {
    mutableStateListOf(
      NotebookMessage(isUser = true, text = "¿Hola que puedes hacer?"),
      NotebookMessage(
        isUser = false,
        text = "No tengo suficiente información en las fuentes proporcionadas para responder directamente a esa pregunta general. Si tienes alguna pregunta específica sobre el benchmarking de GPT-6 Astra, sus métricas de latencia o cómo se compara con otros modelos, estaré encantado de ayudarte a analizar los datos disponibles.",
        sourceCitation = "Benchmarking GPT-6 Astra"
      )
    )
  }

  var chatInput by remember { mutableStateOf("") }
  var searchTopicQuery by remember { mutableStateOf("") }
  var showAddUrlDialog by remember { mutableStateOf(false) }
  var newUrlInput by remember { mutableStateOf("") }

  // Studio artifact generation state
  var selectedArtifactName by remember { mutableStateOf<String?>(null) }

  Surface(
    modifier = Modifier
      .fillMaxSize()
      .statusBarsPadding()
      .navigationBarsPadding(),
    color = ChatGptBlack
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // Top Bar: Back arrow + Notebook Title with pencil
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = onBackToList, modifier = Modifier.size(36.dp)) {
            Icon(imageVector = Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Atrás", tint = ChatGptIconColor, modifier = Modifier.size(20.dp))
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = notebook.title,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = ChatGptTextPrimary
          )
          Spacer(modifier = Modifier.width(6.dp))
          Icon(imageVector = Icons.Outlined.Edit, contentDescription = "Editar título", tint = ChatGptTextMuted, modifier = Modifier.size(15.dp))
        }

        IconButton(onClick = onOpenDrawer, modifier = Modifier.size(36.dp)) {
          Icon(imageVector = Icons.Default.Menu, contentDescription = "Menú", tint = ChatGptIconColor, modifier = Modifier.size(20.dp))
        }
      }

      // 3 Tabs: Fuentes · Chat · Studio
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        DetailTabButton(
          title = "Fuentes",
          icon = Icons.Outlined.Description,
          isSelected = selectedTab == NotebookDetailTab.FUENTES,
          onClick = { selectedTab = NotebookDetailTab.FUENTES }
        )

        DetailTabButton(
          title = "Chat",
          icon = Icons.Outlined.Chat,
          isSelected = selectedTab == NotebookDetailTab.CHAT,
          onClick = { selectedTab = NotebookDetailTab.CHAT }
        )

        DetailTabButton(
          title = "Studio",
          icon = Icons.Outlined.AutoAwesome,
          isSelected = selectedTab == NotebookDetailTab.STUDIO,
          onClick = { selectedTab = NotebookDetailTab.STUDIO }
        )
      }

      HorizontalDivider(color = ChatGptBorderSubtle, thickness = 1.dp, modifier = Modifier.padding(top = 8.dp))

      // Tab Content
      Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
        when (selectedTab) {
          NotebookDetailTab.FUENTES -> {
            FuentesTabContent(
              sources = sources,
              searchTopicQuery = searchTopicQuery,
              onSearchTopicChanged = { searchTopicQuery = it },
              onAddUrlClick = { showAddUrlDialog = true },
              onDeleteSource = { sources.remove(it) }
            )
          }
          NotebookDetailTab.CHAT -> {
            NotebookChatTabContent(
              messages = messages,
              chatInput = chatInput,
              onInputChange = { chatInput = it },
              onSendMessage = {
                if (chatInput.isNotBlank()) {
                  val text = chatInput.trim()
                  messages.add(NotebookMessage(isUser = true, text = text))
                  chatInput = ""
                  messages.add(
                    NotebookMessage(
                      isUser = false,
                      text = "Según la información disponible en las fuentes de '${notebook.title}', se destacan los puntos clave sobre $text. Los resultados muestran consistencia con las métricas registradas.",
                      sourceCitation = sources.firstOrNull()?.title ?: "Fuentes del notebook"
                    )
                  )
                }
              }
            )
          }
          NotebookDetailTab.STUDIO -> {
            StudioTabContent(
              selectedArtifactName = selectedArtifactName,
              onSelectArtifact = { selectedArtifactName = it }
            )
          }
        }
      }
    }
  }

  // Add URL dialog
  if (showAddUrlDialog) {
    AlertDialog(
      onDismissRequest = { showAddUrlDialog = false },
      containerColor = ChatGptDrawerBg,
      title = { Text("Agregar fuente URL", color = ChatGptTextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        OutlinedTextField(
          value = newUrlInput,
          onValueChange = { newUrlInput = it },
          placeholder = { Text("https://...", color = ChatGptTextMuted) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = ChatGptInputBg,
            unfocusedContainerColor = ChatGptInputBg,
            focusedBorderColor = Color(0xFF3B82F6),
            unfocusedBorderColor = ChatGptBorderSubtle,
            focusedTextColor = ChatGptTextPrimary,
            unfocusedTextColor = ChatGptTextPrimary
          )
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (newUrlInput.isNotBlank()) {
              sources.add(
                NotebookSource(
                  id = "src_${System.currentTimeMillis()}",
                  title = newUrlInput.substringAfterLast("/").ifBlank { newUrlInput },
                  sizeText = "4.2 KB",
                  type = "URL"
                )
              )
              newUrlInput = ""
              showAddUrlDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
        ) {
          Text("Agregar")
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddUrlDialog = false }) {
          Text("Cancelar", color = ChatGptTextMuted)
        }
      }
    )
  }
}

@Composable
private fun DetailTabButton(
  title: String,
  icon: ImageVector,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .background(if (isSelected) ChatGptPillSelected else Color.Transparent)
      .border(
        width = 1.dp,
        color = if (isSelected) Color(0xFF3F3F46) else Color.Transparent,
        shape = RoundedCornerShape(8.dp)
      )
      .clickable { onClick() }
      .padding(horizontal = 12.dp, vertical = 7.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = if (isSelected) Color.White else ChatGptTextMuted,
      modifier = Modifier.size(15.dp)
    )
    Spacer(modifier = Modifier.width(6.dp))
    Text(
      text = title,
      fontSize = 13.sp,
      fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
      color = if (isSelected) Color.White else ChatGptTextSecondary
    )
  }
}

// ---------------------------------------------------------------------------------
// TAB 1: FUENTES CONTENT (Screenshot 4)
// ---------------------------------------------------------------------------------
@Composable
private fun FuentesTabContent(
  sources: List<NotebookSource>,
  searchTopicQuery: String,
  onSearchTopicChanged: (String) -> Unit,
  onAddUrlClick: () -> Unit,
  onDeleteSource: (NotebookSource) -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(8.dp))
      // Top buttons: + Subir archivo · Agregar URL
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedButton(
          onClick = { /* Upload */ },
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = ChatGptTextPrimary),
          modifier = Modifier
            .weight(1f)
            .height(40.dp)
        ) {
          Icon(imageVector = Icons.Outlined.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("+ Subir archivo", fontSize = 12.5.sp)
        }

        OutlinedButton(
          onClick = onAddUrlClick,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = ChatGptTextPrimary),
          modifier = Modifier
            .weight(1f)
            .height(40.dp)
        ) {
          Icon(imageVector = Icons.Outlined.Link, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Agregar URL", fontSize = 12.5.sp)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Topic search with Fast Research dropdown
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = searchTopicQuery,
          onValueChange = onSearchTopicChanged,
          placeholder = { Text("Busca un tema para encontrar fuentes...", fontSize = 12.sp, color = ChatGptTextMuted) },
          singleLine = true,
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(8.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = ChatGptInputBg,
            unfocusedContainerColor = ChatGptInputBg,
            focusedBorderColor = Color(0xFF3F3F46),
            unfocusedBorderColor = ChatGptBorderSubtle,
            focusedTextColor = ChatGptTextPrimary,
            unfocusedTextColor = ChatGptTextPrimary
          )
        )

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(ChatGptPillSelected)
            .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 12.dp),
          contentAlignment = Alignment.Center
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Fast Research", fontSize = 11.5.sp, color = ChatGptTextSecondary)
            Icon(imageVector = Icons.Outlined.KeyboardArrowDown, contentDescription = null, tint = ChatGptTextMuted, modifier = Modifier.size(14.dp))
          }
        }

        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(ChatGptPillSelected)
            .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(8.dp))
            .clickable { /* search */ },
          contentAlignment = Alignment.Center
        ) {
          Icon(imageVector = Icons.Default.Search, contentDescription = "Buscar", tint = Color.White, modifier = Modifier.size(18.dp))
        }
      }
    }

    // Sources list matching Screenshot 4
    items(sources) { src ->
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(ChatGptInputBg)
          .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(10.dp))
          .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Icon(imageVector = Icons.Outlined.Link, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Text(text = src.title, fontSize = 13.5.sp, color = ChatGptTextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = src.sizeText, fontSize = 11.sp, color = ChatGptTextMuted)
        }

        IconButton(onClick = { onDeleteSource(src) }, modifier = Modifier.size(28.dp)) {
          Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Borrar", tint = ChatGptTextMuted, modifier = Modifier.size(16.dp))
        }
      }
    }
  }
}

// ---------------------------------------------------------------------------------
// TAB 2: NOTEBOOK CHAT CONTENT (Screenshot 8)
// ---------------------------------------------------------------------------------
@Composable
private fun NotebookChatTabContent(
  messages: List<NotebookMessage>,
  chatInput: String,
  onInputChange: (String) -> Unit,
  onSendMessage: () -> Unit
) {
  Column(modifier = Modifier.fillMaxSize()) {
    // Model pill header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(14.dp))
          .background(ChatGptPillSelected)
          .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(14.dp))
          .padding(horizontal = 10.dp, vertical = 4.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = "OpenAI GPT-4o mini", fontSize = 12.sp, color = ChatGptTextSecondary)
          Spacer(modifier = Modifier.width(4.dp))
          Icon(imageVector = Icons.Outlined.KeyboardArrowDown, contentDescription = null, tint = ChatGptTextMuted, modifier = Modifier.size(14.dp))
        }
      }
    }

    // Message List
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      items(messages) { msg ->
        if (msg.isUser) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(ChatGptPillSelected)
                .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
              Text(text = msg.text, fontSize = 14.sp, color = Color.White)
            }
          }
        } else {
          Column(modifier = Modifier.fillMaxWidth()) {
            Text(text = msg.text, fontSize = 13.5.sp, color = ChatGptTextPrimary, lineHeight = 20.sp)
            if (msg.sourceCitation != null) {
              Spacer(modifier = Modifier.height(8.dp))
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(ChatGptInputBg)
                  .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(8.dp))
                  .padding(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(imageVector = Icons.Outlined.Description, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(13.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = msg.sourceCitation, fontSize = 11.5.sp, color = ChatGptTextSecondary)
                }
              }
            }
          }
        }
      }
    }

    // Bottom Chat Capsule matching Screenshot 8
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .clip(RoundedCornerShape(24.dp))
        .background(ChatGptInputBg)
        .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(24.dp))
        .padding(horizontal = 14.dp, vertical = 4.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = chatInput,
          onValueChange = onInputChange,
          placeholder = { Text("+ Pregunta sobre tus fuentes...", fontSize = 13.5.sp, color = ChatGptTextMuted) },
          singleLine = true,
          modifier = Modifier.weight(1f),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent,
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
            focusedTextColor = ChatGptTextPrimary,
            unfocusedTextColor = ChatGptTextPrimary
          )
        )

        IconButton(
          onClick = onSendMessage,
          modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(if (chatInput.isNotBlank()) Color.White else ChatGptPillSelected)
        ) {
          Icon(
            imageVector = Icons.Default.ArrowUpward,
            contentDescription = "Enviar",
            tint = if (chatInput.isNotBlank()) Color.Black else ChatGptIconMuted,
            modifier = Modifier.size(16.dp)
          )
        }
      }
    }
  }
}

// ---------------------------------------------------------------------------------
// TAB 3: STUDIO CONTENT (Screenshot 5)
// ---------------------------------------------------------------------------------
data class StudioTool(val name: String, val icon: ImageVector)

val studioTools = listOf(
  StudioTool("Mapa mental", Icons.Outlined.Hub),
  StudioTool("Informe", Icons.Outlined.Description),
  StudioTool("Resumen", Icons.Outlined.Description),
  StudioTool("Tarjetas didácticas", Icons.Outlined.Quiz),
  StudioTool("Cuestionario", Icons.Outlined.Quiz),
  StudioTool("Tabla de datos", Icons.Outlined.TableChart),
  StudioTool("Infografía", Icons.Outlined.TableChart),
  StudioTool("Guía de estudio", Icons.Outlined.MenuBook),
  StudioTool("Resumen en audio", Icons.Outlined.GraphicEq),
  StudioTool("Presentación narrada", Icons.Outlined.PlayCircle)
)

@Composable
private fun StudioTabContent(
  selectedArtifactName: String?,
  onSelectArtifact: (String) -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(10.dp))
      // 2-column grid for artifacts
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        studioTools.chunked(2).forEach { rowTools ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            rowTools.forEach { tool ->
              val isSelected = tool.name == selectedArtifactName
              Box(
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSelected) ChatGptPillSelected else ChatGptInputBg)
                  .border(
                    width = 1.dp,
                    color = if (isSelected) Color(0xFF3B82F6) else ChatGptBorderSubtle,
                    shape = RoundedCornerShape(10.dp)
                  )
                  .clickable { onSelectArtifact(tool.name) }
                  .padding(horizontal = 12.dp, vertical = 10.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(imageVector = tool.icon, contentDescription = null, tint = if (isSelected) Color(0xFF60A5FA) else ChatGptTextSecondary, modifier = Modifier.size(15.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = tool.name,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (isSelected) Color.White else ChatGptTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }
              }
            }
            if (rowTools.size == 1) {
              Spacer(modifier = Modifier.weight(1f))
            }
          }
        }
      }
    }

    // Artifact Result Area
    item {
      Spacer(modifier = Modifier.height(16.dp))
      if (selectedArtifactName == null) {
        // Initial empty state matching Screenshot 5
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ChatGptInputBg)
            .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(12.dp))
            .padding(vertical = 40.dp, horizontal = 20.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(imageVector = Icons.Outlined.AutoAwesome, contentDescription = null, tint = ChatGptTextMuted, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = "Los artefactos que generes aparecerán aquí.", fontSize = 13.sp, color = ChatGptTextMuted)
          }
        }
      } else {
        // Generated Artifact Card
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ChatGptInputBg)
            .border(1.dp, Color(0xFF3B82F6), RoundedCornerShape(12.dp))
            .padding(16.dp)
        ) {
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Outlined.AutoAwesome, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Artefacto: $selectedArtifactName", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
              }
              Text(text = "Generado", fontSize = 11.sp, color = Color(0xFF34D399))
            }

            Spacer(modifier = Modifier.height(10.dp))

            when (selectedArtifactName) {
              "Mapa mental" -> {
                Text(text = "• Benchmarking GPT-6 Astra\n  ├── Latencia de inferencia: reducida en 42%\n  ├── Razonamiento paso a paso\n  └── Automatización en entornos de escritorio", fontSize = 13.sp, color = ChatGptTextPrimary, lineHeight = 20.sp)
              }
              "Resumen", "Informe" -> {
                Text(text = "Resumen Ejecutivo:\nEl documento sintetiza las evaluaciones empíricas del modelo, demostrando mejoras sustanciales en la coherencia de respuestas estructuradas y velocidad de procesamiento.", fontSize = 13.sp, color = ChatGptTextPrimary, lineHeight = 20.sp)
              }
              "Cuestionario", "Tarjetas didácticas" -> {
                Text(text = "Pregunta 1: ¿Cuál es la principal ventaja destacada en las fuentes?\nRespuesta: La integración directa con subsistemas del sistema operativo y latencia de respuesta reducida.", fontSize = 13.sp, color = ChatGptTextPrimary, lineHeight = 20.sp)
              }
              else -> {
                Text(text = "Análisis completado a partir de las fuentes cargadas para '$selectedArtifactName'. Datos indexados y listos para exportación.", fontSize = 13.sp, color = ChatGptTextPrimary, lineHeight = 20.sp)
              }
            }
          }
        }
      }
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
