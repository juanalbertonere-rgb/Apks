package com.example.ui.settings

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Settings
import com.example.service.WeaverAccessibilityService
import com.example.sync.ChatSync
import com.example.sync.PhoneServer
import com.example.sync.PcBridgeClient
import com.example.sync.QrCodec
import com.example.sync.QrPayloads
import com.example.termux.TermuxBridge
import com.example.ui.chat.ChatViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Ajustes de Weaver Android: proveedor LLM configurable, objetivo de
 * ejecución (móvil/PC), permisos del cuerpo del agente (accesibilidad,
 * Termux, almacenamiento), servidores MCP, emparejamiento QR y
 * exportar/importar chats.
 */
@Composable
fun SettingsScreen(viewModel: ChatViewModel, onBackToChat: () -> Unit) {
  val context = LocalContext.current
  val settings = viewModel.settings
  val scope = rememberCoroutineScope()
  val snackbar = remember { SnackbarHostState() }

  var providerId by remember { mutableStateOf(settings.providerId) }
  var baseUrl by remember { mutableStateOf(settings.providerBaseUrl) }
  var apiKey by remember { mutableStateOf(settings.providerApiKey) }
  var model by remember { mutableStateOf(settings.providerModel) }
  var target by remember { mutableStateOf(settings.executionTarget) }
  var ttsEnabled by remember { mutableStateOf(settings.ttsEnabled) }

  var mcpServers by remember { mutableStateOf(settings.mcpServers) }
  var showAddMcp by remember { mutableStateOf(false) }
  var mcpName by remember { mutableStateOf("") }
  var mcpUrl by remember { mutableStateOf("") }

  var showPairQr by remember { mutableStateOf(false) }
  var phoneServerOn by remember { mutableStateOf(settings.phoneServerEnabled) }
  var bridgeStatus by remember { mutableStateOf(if (settings.isPcPaired) "Emparejada: ${settings.pcBridgeName}" else "No emparejada") }

  var a11yOn by remember { mutableStateOf(WeaverAccessibilityService.isRunning) }
  var termuxStatus by remember { mutableStateOf("…") }

  // Servidor HTTP local (PC → móvil)
  val phoneServer = remember {
    PhoneServer(
      context,
      settings.phonePort,
      settings.phoneToken,
      onTaskFromPc = { prompt -> viewModel.sendSuggestion(prompt) },
      onBridgeRegistered = { url, token, name ->
        settings.pcBridgeUrl = url
        settings.pcBridgeToken = token
        settings.pcBridgeName = name
        bridgeStatus = "Emparejada: $name"
      }
    )
  }
  DisposableEffect(Unit) {
    if (settings.phoneServerEnabled) phoneServer.start()
    onDispose { phoneServer.stop() }
  }

  val storagePermission = rememberLauncherForActivityResult(
    ActivityResultContracts.StartActivityForResult()
  ) { termuxStatus = "Revisa si la carpeta /sdcard/Weaver ya es accesible" }

  LaunchedEffect(Unit) {
    termuxStatus = TermuxBridge.status(context).toString(2)
    a11yOn = WeaverAccessibilityService.isRunning
  }

  // FIX "no se guarda la API key": antes SOLO se guardaba al tocar la flecha
  // de volver; con el botón/gesto atrás del sistema todo se perdía.
  // (El BackHandler se registra tras declarar save(), más abajo.)

  fun save() {
    settings.applyProviderPreset(providerId)
    settings.providerBaseUrl = baseUrl
    settings.providerApiKey = apiKey
    settings.providerModel = model
    settings.executionTarget = target
    settings.ttsEnabled = ttsEnabled
  }

  // El botón/gesto ATRÁS del sistema también guarda antes de salir.
  BackHandler { save(); onBackToChat() }

  Scaffold(snackbarHost = { SnackbarHost(snackbar) }, containerColor = ChatGptBlack) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .background(ChatGptBlack)
        .statusBarsPadding()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp)
    ) {
      // Cabecera
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 10.dp)) {
        Icon(
          imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
          contentDescription = "Volver",
          tint = Color.White,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { save(); onBackToChat() }
            .padding(4.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text("Ajustes de Weaver", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
      }

      SectionCard("Proveedor LLM") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf(
            "openrouter" to "OpenRouter",
            "openai" to "OpenAI",
            "ollama" to "Ollama",
            "custom" to "Otro"
          ).forEach { (id, label) ->
            Text(
              text = label,
              fontSize = 12.sp,
              color = if (providerId == id) Color.White else ChatGptTextMuted,
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(if (providerId == id) Color(0xFF27272A) else Color(0x14FFFFFF))
                .border(1.dp, WeaverChipBorder, RoundedCornerShape(10.dp))
                .clickable {
                  providerId = id
                  settings.applyProviderPreset(id)
                  baseUrl = settings.providerBaseUrl
                }
                .padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }
        }
        Spacer(Modifier.height(10.dp))
        LabeledField("Base URL", baseUrl) { baseUrl = it; settings.providerBaseUrl = it }
        if (settings.needsApiKey()) {
          LabeledField("API Key", apiKey, password = true) { apiKey = it; settings.providerApiKey = it }
        }
        LabeledField("Modelo", model) { model = it; settings.providerModel = it }
        Text(
          text = "Ej: openrouter/auto · gpt-4o-mini · llama3.2 · north-mini-code-free",
          fontSize = 11.sp, color = ChatGptTextMuted, modifier = Modifier.padding(top = 4.dp)
        )
      }

      SectionCard("Objetivo de ejecución") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "📱 Móvil (Termux + Accesibilidad)",
            fontSize = 12.sp,
            color = if (target == Settings.TARGET_MOVIL) Color.White else ChatGptTextMuted,
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(if (target == Settings.TARGET_MOVIL) Color(0xFF27272A) else Color(0x14FFFFFF))
              .border(1.dp, WeaverChipBorder, RoundedCornerShape(10.dp))
              .clickable { target = Settings.TARGET_MOVIL; save() }
              .padding(horizontal = 10.dp, vertical = 6.dp)
          )
          Text(
            "🖥️ PC (bridge)",
            fontSize = 12.sp,
            color = if (target == Settings.TARGET_PC) Color.White else ChatGptTextMuted,
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(if (target == Settings.TARGET_PC) Color(0xFF27272A) else Color(0x14FFFFFF))
              .border(1.dp, WeaverChipBorder, RoundedCornerShape(10.dp))
              .clickable {
                if (settings.isPcPaired) { target = Settings.TARGET_PC; save() }
                else scope.launch { snackbar.showSnackbar("Primero escanea el QR del bridge de tu PC (abajo)") }
              }
              .padding(horizontal = 10.dp, vertical = 6.dp)
          )
        }
      }

      SectionCard("Cuerpo del agente (permisos)") {
        PermissionRow(
          title = "Servicio de accesibilidad",
          desc = "Leer pantalla, clics, escritura, scroll, zoom",
          active = a11yOn,
          onEnable = {
            context.startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
          }
        )
        PermissionRow(
          title = "Termux (shell real)",
          desc = termuxStatus.take(140),
          active = TermuxBridge.isTermuxInstalled(context),
          onEnable = { TermuxBridge.openTermuxApp(context) }
        )
        PermissionRow(
          title = "Almacenamiento (intercambio /sdcard/Weaver)",
          desc = "Necesario para leer la salida de Termux",
          active = java.io.File(android.os.Environment.getExternalStorageDirectory(), "Weaver").canWrite(),
          onEnable = {
            if (Build.VERSION.SDK_INT >= 30) {
              storagePermission.launch(
                Intent(AndroidSettings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
              )
            }
          }
        )
        PermissionRow(
          title = "Leer respuestas en voz alta (TTS)",
          desc = "Weaver habla sus respuestas finales",
          active = ttsEnabled,
          onEnable = { ttsEnabled = !ttsEnabled; save() }
        )
      }

      SectionCard("Servidores MCP (HTTP)") {
        for (i in 0 until mcpServers.length()) {
          val s = mcpServers.optJSONObject(i) ?: continue
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
              Text(s.optString("name"), fontSize = 13.sp, color = Color.White)
              Text(s.optString("url"), fontSize = 11.sp, color = ChatGptTextMuted, maxLines = 1)
            }
            Switch(
              checked = s.optBoolean("enabled", true),
              onCheckedChange = { en ->
                settings.setMcpServerEnabled(s.optString("id"), en)
                mcpServers = settings.mcpServers
              },
              colors = SwitchDefaults.colors(checkedTrackColor = Color(0xFF4ADE80))
            )
            Text(
              "✕", color = ChatGptTextMuted,
              modifier = Modifier
                .clickable { settings.removeMcpServer(s.optString("id")); mcpServers = settings.mcpServers }
                .padding(6.dp)
            )
          }
        }
        Text(
          text = "+ Agregar servidor",
          fontSize = 13.sp, color = Color(0xFF7DD3FC),
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { showAddMcp = !showAddMcp }
            .padding(vertical = 6.dp)
        )
        if (showAddMcp) {
          LabeledField("Nombre", mcpName) { mcpName = it }
          LabeledField("URL (http://IP:puerto/mcp)", mcpUrl) { mcpUrl = it }
          Text(
            "Guardar",
            fontSize = 13.sp, color = Color(0xFF4ADE80),
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .clickable {
                if (mcpUrl.startsWith("http")) {
                  settings.upsertMcpServer(
                    id = mcpName.ifBlank { "mcp${mcpServers.length()}" },
                    name = mcpName.ifBlank { "MCP" },
                    url = mcpUrl,
                    enabled = true
                  )
                  mcpServers = settings.mcpServers
                  mcpName = ""; mcpUrl = ""; showAddMcp = false
                }
              }
              .padding(vertical = 8.dp)
          )
        }
      }

      SectionCard("Emparejamiento con la PC") {
        Text(bridgeStatus, fontSize = 13.sp, color = ChatGptTextPrimary)
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "Mostrar mi QR",
            fontSize = 12.sp, color = Color.White,
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(Color(0xFF27272A))
              .border(1.dp, WeaverChipBorder, RoundedCornerShape(10.dp))
              .clickable { showPairQr = !showPairQr }
              .padding(horizontal = 10.dp, vertical = 6.dp)
          )
          Text(
            if (phoneServerOn) "Servidor local: ON" else "Servidor local: OFF",
            fontSize = 12.sp, color = if (phoneServerOn) Color(0xFF4ADE80) else ChatGptTextMuted,
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(Color(0x14FFFFFF))
              .border(1.dp, WeaverChipBorder, RoundedCornerShape(10.dp))
              .clickable {
                phoneServerOn = !phoneServerOn
                settings.phoneServerEnabled = phoneServerOn
                if (phoneServerOn) phoneServer.start() else phoneServer.stop()
              }
              .padding(horizontal = 10.dp, vertical = 6.dp)
          )
          Text(
            "Escanear QR PC",
            fontSize = 12.sp, color = Color.White,
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(Color(0xFF27272A))
              .border(1.dp, WeaverChipBorder, RoundedCornerShape(10.dp))
              .clickable { save() }
          )
        }

        if (showPairQr) {
          Spacer(Modifier.height(10.dp))
          val host = PhoneServer.lanAddress() ?: "0.0.0.0"
          val payload = QrPayloads.phonePairing(
            settings.deviceName, host, settings.phonePort, settings.phoneToken, settings.deviceId
          )
          val bmp = remember(payload) { QrCodec.encode(payload, 620) }
          androidx.compose.foundation.Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = "QR de emparejamiento",
            modifier = Modifier
              .fillMaxWidth()
              .height(260.dp)
          )
          Text(
            "Abre Weaver en tu PC → Workspace → Weaver Mobile → Encender → y escanea aquí el código que muestra.\nIP local del teléfono: $host · Puerto: ${settings.phonePort}",
            fontSize = 11.sp, color = ChatGptTextMuted, modifier = Modifier.padding(top = 6.dp)
          )
        }

        // Escáner integrado
        var showScanner by remember { mutableStateOf(false) }
        Text(
          "📷 Escanear QR del bridge de la PC",
          fontSize = 13.sp, color = Color(0xFF7DD3FC),
          modifier = Modifier
            .padding(top = 8.dp)
            .clickable { showScanner = true }
            .padding(vertical = 4.dp)
        )
        if (showScanner) {
          com.example.ui.scan.QrScanScreen(
            onScanned = { payload ->
              showScanner = false
              val parsed = QrPayloads.parse(payload)
              when {
                parsed != null && parsed.first == "bridge" -> {
                  save()
                  if (viewModel.agentController.pairPcBridge(payload)) {
                    target = Settings.TARGET_PC; save()
                    bridgeStatus = "Emparejada: ${settings.pcBridgeName}"
                    scope.launch { snackbar.showSnackbar("PC emparejada ✓ — Modo PC activado") }
                  }
                }
                parsed != null && parsed.first == "sync" -> {
                  scope.launch { snackbar.showSnackbar("QR de chats: escanea todos los códigos (${'N'} partes)") }
                }
                else -> scope.launch { snackbar.showSnackbar("QR no reconocido") }
              }
            },
            onClose = { showScanner = false }
          )
        }
      }

      SectionCard("Chats (sincronización)") {
        var exporting by remember { mutableStateOf(false) }
        // ── Sincronización de chats con la PC (vía el QR escaneado) ──
        if (settings.isPcPaired) {
          var syncingDown by remember { mutableStateOf(false) }
          Text(
            if (syncingDown) " Trayendo…" else "⬇ Traer chats de la PC (${settings.pcBridgeName})",
            fontSize = 13.sp, color = Color(0xFF7DD3FC),
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .clickable(enabled = !syncingDown) {
                syncingDown = true
                scope.launch {
                  val pc = PcBridgeClient(settings.pcBridgeUrl ?: "", settings.pcBridgeToken)
                  val json = pc.fetchPcChats()
                  syncingDown = false
                  if (json == null) {
                    snackbar.showSnackbar("No se pudo conectar con la PC (¿misma red? ¿servidor encendido?)")
                  } else {
                    val n = ChatSync.importAll(context, viewModel.database, json)
                    snackbar.showSnackbar("Importados $n chat(s) de la PC ✓")
                  }
                }
              }
              .padding(vertical = 6.dp)
          )
          var syncingUp by remember { mutableStateOf(false) }
          Text(
            if (syncingUp) "Enviando…" else "⬆ Enviar mis chats a la PC",
            fontSize = 13.sp, color = Color(0xFF7DD3FC),
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .clickable(enabled = !syncingUp) {
                syncingUp = true
                scope.launch {
                  val json = ChatSync.exportAll(viewModel.database)
                  val pc = PcBridgeClient(settings.pcBridgeUrl ?: "", settings.pcBridgeToken)
                  val n = pc.pushPcChats(json)
                  syncingUp = false
                  if (n >= 0) snackbar.showSnackbar("Enviados $n chat(s) a la PC ✓")
                  else snackbar.showSnackbar("No se pudo conectar con la PC")
                }
              }
              .padding(vertical = 6.dp)
          )
        }

        Text(
          if (exporting) "Exportando…" else "⬆ Exportar chats a /sdcard/Weaver",
          fontSize = 13.sp, color = Color(0xFF7DD3FC),
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(enabled = !exporting) {
              exporting = true
              scope.launch {
                val f = ChatSync.exportToFile(context, viewModel.database)
                exporting = false
                snackbar.showSnackbar("Exportado: ${f.absolutePath}")
              }
            }
            .padding(vertical = 6.dp)
        )
        var showImport by remember { mutableStateOf(false) }
        Text(
          "⬇ Importar chats (escanea QRs exportados)",
          fontSize = 13.sp, color = Color(0xFF7DD3FC),
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { showImport = !showImport }
            .padding(vertical = 6.dp)
        )
        if (showImport) {
          val assembler = remember { ChatSync.MultiQrAssembler() }
          var scannedCount by remember { mutableStateOf(0) }
          Text("Escanea los QR en orden. Partes leídas: $scannedCount", fontSize = 12.sp, color = ChatGptTextMuted)
          com.example.ui.scan.QrScanScreen(
            onScanned = { payload ->
              if (assembler.offer(payload)) {
                val json = assembler.result ?: return@QrScanScreen
                scope.launch {
                  val n = ChatSync.importAll(context, viewModel.database, json)
                  snackbar.showSnackbar("Importados $n chats ✓")
                  showImport = false
                }
              } else {
                scannedCount = assembler.parts.size.coerceAtLeast(scannedCount)
              }
            },
            onClose = { showImport = false }
          )
        }
      }

      Text(
        "Weaver Android · agente ReAct con Termux + Accesibilidad · misma arquitectura que Weaver PC",
        fontSize = 11.sp, color = ChatGptTextMuted,
        modifier = Modifier.padding(vertical = 18.dp)
      )
      Spacer(Modifier.height(40.dp))
    }
  }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(bottom = 14.dp)
      .clip(RoundedCornerShape(14.dp))
      .background(ChatGptInputBg)
      .border(1.dp, WeaverCardBorder, RoundedCornerShape(14.dp))
      .padding(14.dp)
  ) {
    Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
    Spacer(Modifier.height(10.dp))
    content()
  }
}

@Composable
private fun LabeledField(label: String, value: String, password: Boolean = false, onChange: (String) -> Unit) {
  Column(modifier = Modifier.padding(bottom = 8.dp)) {
    Text(label, fontSize = 11.sp, color = ChatGptTextMuted)
    BasicTextField(
      value = value,
      onValueChange = onChange,
      singleLine = true,
      visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
      textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp),
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(8.dp))
        .background(Color(0x14FFFFFF))
        .padding(horizontal = 10.dp, vertical = 8.dp),
      decorationBox = { inner ->
        if (value.isEmpty()) Text("…", color = ChatGptTextMuted, fontSize = 12.sp)
        inner()
      }
    )
  }
}

@Composable
private fun PermissionRow(title: String, desc: String, active: Boolean, onEnable: () -> Unit) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
  ) {
    Column(Modifier.weight(1f)) {
      Text(title, fontSize = 13.sp, color = Color.White)
      if (desc.isNotBlank()) Text(desc, fontSize = 11.sp, color = ChatGptTextMuted, maxLines = 2)
    }
    Spacer(Modifier.width(8.dp))
    Text(
      text = if (active) "OK ✓" else "Activar",
      fontSize = 12.sp,
      color = if (active) Color(0xFF4ADE80) else Color(0xFFFACC15),
      modifier = Modifier
        .clip(RoundedCornerShape(8.dp))
        .clickable { if (!active) onEnable() }
        .padding(horizontal = 8.dp, vertical = 5.dp)
    )
  }
}
