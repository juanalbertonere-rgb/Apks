package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

enum class DeviceSegmentMode {
  MOVIL,
  PC
}

// Colors matching exact CSS variables from user snippet
private val ControlBg = Color(0xFF18181B)
private val ControlBorder = Color(0x14FFFFFF) // rgba(255, 255, 255, 0.08)
private val IndicatorBg = Color(0xFF27272A)
private val IndicatorBorder = Color(0x1FFFFFFF) // rgba(255, 255, 255, 0.12)
private val TextMuted = Color(0xFFA1A1AA)
private val TextActive = Color(0xFFFFFFFF)

@Composable
fun OpenAiSegmentedControl(
  selectedMode: DeviceSegmentMode,
  onModeSelected: (DeviceSegmentMode) -> Unit,
  modifier: Modifier = Modifier
) {
  val targetIndex = if (selectedMode == DeviceSegmentMode.MOVIL) 0f else 1f

  // Smooth OpenAI spring animation
  val animatedIndex by animateFloatAsState(
    targetValue = targetIndex,
    animationSpec = spring(
      dampingRatio = 0.82f,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "SegmentedControlSpring"
  )

  val itemWidth = 58.dp
  val controlHeight = 28.dp
  val innerPadding = 2.dp
  val indicatorHeight = controlHeight - (innerPadding * 2)

  Box(
    modifier = modifier
      .clip(CircleShape)
      .background(ControlBg)
      .border(1.dp, ControlBorder, CircleShape)
      .padding(innerPadding)
      .height(indicatorHeight)
  ) {
    // Sliding Indicator Pill
    Box(
      modifier = Modifier
        .offset {
          IntOffset(
            x = (animatedIndex * itemWidth.toPx()).roundToInt(),
            y = 0
          )
        }
        .width(itemWidth)
        .height(indicatorHeight)
        .shadow(2.dp, CircleShape, spotColor = Color.Black.copy(alpha = 0.4f))
        .clip(CircleShape)
        .background(IndicatorBg)
        .border(1.dp, IndicatorBorder, CircleShape)
    )

    // Two buttons row: Móvil and PC
    Row(
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Button 1: Móvil
      SegmentButton(
        title = "Móvil",
        isSelected = selectedMode == DeviceSegmentMode.MOVIL,
        width = itemWidth,
        height = indicatorHeight,
        onClick = { onModeSelected(DeviceSegmentMode.MOVIL) },
        icon = { tint -> MovilIcon(tint = tint) }
      )

      // Button 2: PC
      SegmentButton(
        title = "PC",
        isSelected = selectedMode == DeviceSegmentMode.PC,
        width = itemWidth,
        height = indicatorHeight,
        onClick = { onModeSelected(DeviceSegmentMode.PC) },
        icon = { tint -> PcIcon(tint = tint) }
      )
    }
  }
}

@Composable
private fun SegmentButton(
  title: String,
  isSelected: Boolean,
  width: androidx.compose.ui.unit.Dp,
  height: androidx.compose.ui.unit.Dp,
  onClick: () -> Unit,
  icon: @Composable (Color) -> Unit
) {
  val contentColor = if (isSelected) TextActive else TextMuted
  val interactionSource = remember { MutableInteractionSource() }

  Box(
    modifier = Modifier
      .width(width)
      .height(height)
      .clip(CircleShape)
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        onClick = onClick
      ),
    contentAlignment = Alignment.Center
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically
    ) {
      icon(contentColor)
      Spacer(modifier = Modifier.width(5.dp))
      Text(
        text = title,
        color = contentColor,
        fontSize = 11.5.sp,
        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
        letterSpacing = (-0.2).sp
      )
    }
  }
}

/**
 * Mobile phone vector matching the user's SVG:
 * <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
 * <line x1="12" y1="18" x2="12.01" y2="18"></line>
 */
@Composable
private fun MovilIcon(tint: Color) {
  Canvas(modifier = Modifier.size(13.dp)) {
    val strokeWidth = 1.5.dp.toPx()
    val w = size.width
    val h = size.height

    // Phone body
    val bodyLeft = w * (5f / 24f)
    val bodyTop = h * (2f / 24f)
    val bodyWidth = w * (14f / 24f)
    val bodyHeight = h * (20f / 24f)
    val cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())

    drawRoundRect(
      color = tint,
      topLeft = Offset(bodyLeft, bodyTop),
      size = Size(bodyWidth, bodyHeight),
      cornerRadius = cornerRadius,
      style = Stroke(width = strokeWidth)
    )

    // Home button line/dot
    val dotY = h * (18f / 24f)
    val dotX1 = w * (11.5f / 24f)
    val dotX2 = w * (12.5f / 24f)
    drawLine(
      color = tint,
      start = Offset(dotX1, dotY),
      end = Offset(dotX2, dotY),
      strokeWidth = strokeWidth,
      cap = StrokeCap.Round
    )
  }
}

/**
 * PC / Desktop computer vector matching the user's SVG:
 * <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
 * <line x1="8" y1="21" x2="16" y2="21"></line>
 * <line x1="12" y1="17" x2="12" y2="21"></line>
 */
@Composable
private fun PcIcon(tint: Color) {
  Canvas(modifier = Modifier.size(13.dp)) {
    val strokeWidth = 1.5.dp.toPx()
    val w = size.width
    val h = size.height

    // Monitor screen
    val screenLeft = w * (2f / 24f)
    val screenTop = h * (3f / 24f)
    val screenWidth = w * (20f / 24f)
    val screenHeight = h * (14f / 24f)
    val cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())

    drawRoundRect(
      color = tint,
      topLeft = Offset(screenLeft, screenTop),
      size = Size(screenWidth, screenHeight),
      cornerRadius = cornerRadius,
      style = Stroke(width = strokeWidth)
    )

    // Vertical stand leg: line x1="12" y1="17" x2="12" y2="21"
    drawLine(
      color = tint,
      start = Offset(w * 0.5f, h * (17f / 24f)),
      end = Offset(w * 0.5f, h * (21f / 24f)),
      strokeWidth = strokeWidth,
      cap = StrokeCap.Round
    )

    // Base line: line x1="8" y1="21" x2="16" y2="21"
    drawLine(
      color = tint,
      start = Offset(w * (8f / 24f), h * (21f / 24f)),
      end = Offset(w * (16f / 24f), h * (21f / 24f)),
      strokeWidth = strokeWidth,
      cap = StrokeCap.Round
    )
  }
}
