package com.example.sync

import android.content.Context
import com.example.data.Settings
import com.example.data.db.WeaverDb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Servidor HTTP mínimo (ServerSocket puro, cero dependencias) que corre en el
 * teléfono para que la PC pueda:
 *
 *   GET  /health                     → estado
 *   GET  /api/chats                  → exportar chats (mismo JSON de ChatSync)
 *   POST /api/chats/import           → importar chats (body JSON)
 *   POST /api/task                   → la PC envía un prompt para ejecutar EN el móvil
 *   POST /api/bridge/register        → la PC se registra (host/port/token del bridge)
 *
 * Autenticación: header Authorization: Bearer <phoneToken> (el token viaja en
 * el QR de emparejamiento del teléfono).
 */
class PhoneServer(
  private val context: Context,
  private val port: Int,
  private val token: String,
  private val onTaskFromPc: (prompt: String) -> Unit,
  private val onBridgeRegistered: (url: String, token: String, name: String) -> Unit
) {

  private val running = AtomicBoolean(false)
  private var serverSocket: ServerSocket? = null
  private var acceptThread: Thread? = null
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private var taskJob: Job? = null

  val isRunning: Boolean get() = running.get()

  fun start() {
    if (running.get()) return
    running.set(true)
    acceptThread = Thread {
      try {
        serverSocket = ServerSocket(port, 8, InetAddress.getByName("0.0.0.0"))
        while (running.get()) {
          val socket = serverSocket?.accept() ?: break
          scope.launch { handle(socket) }
        }
      } catch (_: Exception) {
        // Socket cerrado al hacer stop()
      }
    }.also { it.start() }
  }

  fun stop() {
    running.set(false)
    runCatching { serverSocket?.close() }
    acceptThread?.interrupt()
    // Nota: el scope NO se cancela para poder reiniciar el servidor luego.
  }

  private suspend fun handle(socket: Socket) {
    socket.use { s ->
      try {
        s.soTimeout = 15_000
        val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
        val requestLine = reader.readLine() ?: return
        val parts = requestLine.split(" ")
        if (parts.size < 2) return
        val method = parts[0]
        val path = parts[1]

        // Headers
        var authOk = false
        var contentLength = 0
        while (true) {
          val line = reader.readLine() ?: break
          if (line.isEmpty()) break
          val lower = line.lowercase()
          if (lower.startsWith("authorization:")) {
            authOk = line.substringAfter("Bearer ").trim() == token
          } else if (lower.startsWith("content-length:")) {
            contentLength = line.substringAfter(":").trim().toIntOrNull() ?: 0
          }
        }
        val body = if (contentLength > 0) {
          val buf = CharArray(contentLength)
          var read = 0
          while (read < contentLength) {
            val r = reader.read(buf, read, contentLength - read)
            if (r < 0) break
            read += r
          }
          String(buf, 0, read)
        } else ""

        val noAuthNeeded = path == "/health"
        if (!authOk && !noAuthNeeded) {
          respond(s, 401, JSONObject().put("error", "Token inválido — usa el QR de emparejamiento"))
          return
        }

        val db = WeaverDb.get(context)
        when {
          path == "/health" -> respond(s, 200, JSONObject().put("ok", true).put("app", "weaver-android").put("device", android.os.Build.MODEL))

          path == "/api/chats" && method == "GET" -> {
            val json = ChatSync.exportAll(db)
            respondRaw(s, 200, json, "application/json")
          }

          path == "/api/chats/import" && method == "POST" -> {
            val imported = ChatSync.importAll(context, db, body)
            respond(s, 200, JSONObject().put("ok", true).put("imported", imported))
          }

          path == "/api/task" && method == "POST" -> {
            val prompt = JSONObject(body).optString("prompt")
            if (prompt.isBlank()) {
              respond(s, 400, JSONObject().put("error", "Falta 'prompt'"))
            } else {
              taskJob?.cancel()
              taskJob = scope.launch { onTaskFromPc(prompt) }
              respond(s, 202, JSONObject().put("ok", true).put("queued", true))
            }
          }

          path == "/api/bridge/register" && method == "POST" -> {
            val o = JSONObject(body)
            val host = s.getInetAddress()?.hostAddress ?: o.optString("host")
            val portB = o.optInt("port", 8787)
            val tokenB = o.optString("token")
            val name = o.optString("name", "PC")
            withContext(Dispatchers.Main) { onBridgeRegistered("http://$host:$portB", tokenB, name) }
            respond(s, 200, JSONObject().put("ok", true).put("paired", true))
          }

          else -> respond(s, 404, JSONObject().put("error", "Ruta desconocida"))
        }
      } catch (_: Exception) {
        // Conexión abortada — siguiente.
      }
    }
  }

  private fun respond(socket: Socket, code: Int, json: JSONObject) =
    respondRaw(socket, code, json.toString(), "application/json")

  private fun respondRaw(socket: Socket, code: Int, body: String, contentType: String) {
    val os: OutputStream = socket.getOutputStream()
    val bytes = body.toByteArray(Charsets.UTF_8)
    val headers = "HTTP/1.1 $code OK\r\n" +
      "Content-Type: $contentType; charset=utf-8\r\n" +
      "Content-Length: ${bytes.size}\r\n" +
      "Connection: close\r\n\r\n"
    os.write(headers.toByteArray(Charsets.UTF_8))
    os.write(bytes)
    os.flush()
  }

  companion object {
    /** IP LAN del teléfono para el QR de emparejamiento. */
    fun lanAddress(): String? {
      return runCatching {
        val interfaces = NetworkInterface.getNetworkInterfaces()
        while (interfaces.hasMoreElements()) {
          val ni = interfaces.nextElement()
          if (!ni.isUp || ni.isLoopback) continue
          val addresses = ni.inetAddresses
          while (addresses.hasMoreElements()) {
            val addr = addresses.nextElement()
            if (!addr.isLoopbackAddress && addr is java.net.Inet4Address) {
              return addr.hostAddress
            }
          }
        }
        null
      }.getOrNull()
    }
  }
}
