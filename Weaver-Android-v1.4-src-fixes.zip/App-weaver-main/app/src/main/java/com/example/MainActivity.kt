package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.UserPreferences
import com.example.ui.chat.ChatScreen
import com.example.ui.chat.ChatViewModel
import com.example.ui.complementos.ComplementosScreen
import com.example.ui.components.AppSection
import com.example.ui.components.DrawerContent
import com.example.ui.components.ModelSelectorSheet
import com.example.ui.components.OfferDialog
import com.example.ui.components.VoiceModeSheet
import com.example.ui.notebooks.NotebooksScreen
import com.example.ui.onboarding.OnboardingScreen
import com.example.ui.schedules.SchedulesScreen
import com.example.ui.theme.ChatGptBlack
import com.example.ui.theme.ChatGptDrawerBg
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        MainAppContent()
      }
    }
  }
}

@Composable
fun MainAppContent(
  chatViewModel: ChatViewModel = viewModel(
    factory = ChatViewModel.Factory(LocalContext.current.applicationContext as android.app.Application)
  )
) {
  val context = LocalContext.current
  val userPrefs = remember { UserPreferences(context) }
  var showOnboarding by remember { mutableStateOf(!userPrefs.isOnboardingCompleted) }
  var currentSection by remember { mutableStateOf(AppSection.CHAT) }

  val uiState by chatViewModel.uiState.collectAsState()
  val recentChats by chatViewModel.recentChats.collectAsState()
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()

  // Onboarding flow on first launch or when triggered manually
  if (showOnboarding) {
    OnboardingScreen(
      onComplete = { name, language ->
        userPrefs.agentCallingName = name
        userPrefs.preferredLanguage = language
        userPrefs.isOnboardingCompleted = true
        showOnboarding = false
      }
    )
    return
  }

  // Handle back button: close drawer first, or return to chat if in another section
  BackHandler(enabled = drawerState.isOpen || currentSection != AppSection.CHAT) {
    if (drawerState.isOpen) {
      scope.launch { drawerState.close() }
    } else if (currentSection != AppSection.CHAT) {
      currentSection = AppSection.CHAT
    }
  }

  Surface(
    modifier = Modifier.fillMaxSize(),
    color = ChatGptBlack
  ) {
    ModalNavigationDrawer(
      drawerState = drawerState,
      scrimColor = Color.Black.copy(alpha = 0.70f),
      drawerContent = {
        ModalDrawerSheet(
          drawerContainerColor = ChatGptDrawerBg,
          drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
          windowInsets = WindowInsets(0, 0, 0, 0)
        ) {
          DrawerContent(
            recentChats = recentChats,
            selectedChatId = uiState.selectedChatId,
            currentSection = currentSection,
            onSectionSelected = { section ->
              currentSection = section
            },
            onChatSelected = { chat -> chatViewModel.selectChat(chat) },
            onNewChat = { chatViewModel.startNewChat() },
            onSearchClick = { /* search clicked */ },
            onCloseDrawer = { scope.launch { drawerState.close() } },
            onSettingsClick = {
              scope.launch { drawerState.close() }
              currentSection = AppSection.SETTINGS
            },
            onResetOnboarding = {
              scope.launch { drawerState.close() }
              showOnboarding = true
            }
          )
        }
      }
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        when (currentSection) {
          AppSection.CHAT -> {
            ChatScreen(
              viewModel = chatViewModel,
              uiState = uiState,
              onOpenDrawer = {
                scope.launch { drawerState.open() }
              },
              onOpenComplementos = {
                currentSection = AppSection.COMPLEMENTOS
              }
            )
          }
          AppSection.COMPLEMENTOS -> {
            ComplementosScreen(
              onOpenDrawer = { scope.launch { drawerState.open() } },
              onBackToChat = { currentSection = AppSection.CHAT },
              viewModel = chatViewModel
            )
          }
          AppSection.SCHEDULES -> {
            SchedulesScreen(
              onOpenDrawer = { scope.launch { drawerState.open() } },
              onBackToChat = { currentSection = AppSection.CHAT },
              viewModel = chatViewModel
            )
          }
          AppSection.NOTEBOOKS -> {
            NotebooksScreen(
              onOpenDrawer = { scope.launch { drawerState.open() } },
              onBackToChat = { currentSection = AppSection.CHAT },
              viewModel = chatViewModel
            )
          }
          AppSection.SETTINGS -> {
            com.example.ui.settings.SettingsScreen(
              viewModel = chatViewModel,
              onBackToChat = { currentSection = AppSection.CHAT }
            )
          }
        }
      }
    }

    // Modal Selector Sheet (modelos reales del proveedor configurado)
    if (uiState.showModelSelector) {
      ModelSelectorSheet(
        selectedModelId = uiState.selectedModel.id,
        models = uiState.providerModels,
        isLoading = uiState.modelsLoading,
        error = uiState.modelsError,
        providerName = when (chatViewModel.settings.providerId) {
          com.example.data.Settings.PROVIDER_OPENROUTER -> "OpenRouter"
          com.example.data.Settings.PROVIDER_OPENAI -> "OpenAI"
          com.example.data.Settings.PROVIDER_OLLAMA -> "Ollama"
          else -> "Proveedor"
        },
        apiKeyConfigured = !chatViewModel.settings.needsApiKey() || chatViewModel.settings.providerApiKey.isNotBlank(),
        onModelSelected = { chatViewModel.selectModel(it) },
        onRetry = { chatViewModel.retryFetchModels() },
        onSaveApiKey = { chatViewModel.saveApiKeyAndReload(it) },
        onDismiss = { chatViewModel.toggleModelSelector(false) }
      )
    }

    // Voice Mode Fullscreen overlay con STT real
    if (uiState.showVoiceMode) {
      VoiceModeSheet(
        onDismiss = { chatViewModel.toggleVoiceMode(false) },
        onTranscript = { text, send ->
          chatViewModel.onVoiceInput(text, send)
          if (send) chatViewModel.toggleVoiceMode(false)
        }
      )
    }

    // Plus Offer Dialog
    if (uiState.showOfferDialog) {
      OfferDialog(
        onDismiss = { chatViewModel.toggleOfferDialog(false) }
      )
    }
  }
}

// Retained for tests and previews
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}
