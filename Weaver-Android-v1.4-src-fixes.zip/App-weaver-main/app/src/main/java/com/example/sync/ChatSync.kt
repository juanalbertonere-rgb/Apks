package com.example.sync

import android.content.Context
import com.example.data.db.ConversationEntity
import com.example.data.db.MessageEntity
import com.example.data.db.WeaverDb
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Exportar / importar chats de Weaver (mismo formato JSON que el agente de PC
 * entenderá: {version, conversations:[{id,title,target,messages:[{role,content,tool_calls,tool_call_id}]}]}).
 * Los QR grandes se parten en trozos base64 (weaver://sync?i=&n=&data=).
 */
object ChatSync {

  suspend fun exportAll(db: WeaverDb): String {
    val root = JSONObject().put("version", 1).put("app", "weaver-android")
    val convs = JSONArray()
    val convList = db.conversations().observeAll().first()
    for (c in convList) {
      val msgs = db.messages().list(c.id)
      val arr = JSONArray()
      for (m in msgs) {
        val o = JSONObject()
          .put("role", m.role)
          .put("content", m.content ?: JSONObject.NULL)
          .put("ts", m.ts)
        m.toolCallsJson?.let { o.put("tool_calls", JSONArray(it)) }
        m.toolCallId?.let { o.put("tool_call_id", it) }
        m.toolName?.let { o.put("tool_name", it) }
        m.reasoning?.let { o.put("reasoning", it) }
        arr.put(o)
      }
      convs.put(
        JSONObject()
          .put("id", c.id)
          .put("title", c.title)
          .put("target", c.target)
          .put("messages", arr)
      )
    }
    root.put("conversations", convs)
    return root.toString(2)
  }

  suspend fun importAll(context: Context, db: WeaverDb, json: String): Int {
    val root = JSONObject(json)
    val convs = root.optJSONArray("conversations") ?: return 0
    var imported = 0
    for (i in 0 until convs.length()) {
      val c = convs.optJSONObject(i) ?: continue
      val id = c.optString("id").ifEmpty { UUID.randomUUID().toString() }
      db.conversations().upsert(
        ConversationEntity(
          id = id,
          title = c.optString("title", "Chat importado"),
          target = c.optString("target", "movil")
        )
      )
      db.messages().deleteAllFor(id)
      val msgs = c.optJSONArray("messages") ?: continue
      var seq = 0L
      for (j in 0 until msgs.length()) {
        val m = msgs.optJSONObject(j) ?: continue
        db.messages().upsert(
          MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = id,
            role = m.optString("role", "user"),
            content = if (m.isNull("content")) null else m.optString("content"),
            toolCallsJson = m.optJSONArray("tool_calls")?.toString(),
            toolCallId = m.optString("tool_call_id", null),
            toolName = m.optString("tool_name", null),
            reasoning = m.optString("reasoning", null),
            seq = ++seq,
            ts = m.optLong("ts", System.currentTimeMillis())
          )
        )
      }
      imported++
    }
    return imported
  }

  // ───────────────────── Exportar / importar por QR ─────────────────────

  /** Parte un JSON en payloads QR (máx ~1200 chars por QR para fiabilidad). */
  fun splitIntoQrPayloads(json: String, chunkSize: Int = 1200): List<String> {
    val bytes = json.toByteArray(Charsets.UTF_8)
    val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE)
    val chunks = b64.chunked(chunkSize)
    val n = chunks.size
    return chunks.mapIndexed { i, part -> "weaver://sync?v=1&i=$i&n=$n&data=${java.net.URLEncoder.encode(part, "UTF-8")}" }
  }

  /** Acumula QR escaneados y devuelve el JSON completo cuando están todos. */
  class MultiQrAssembler {
    val parts = HashMap<Int, String>()
    var total: Int = -1
      private set

    /** true cuando el JSON está completo (y fija result). */
    fun offer(payload: String): Boolean {
      val parsed = QrPayloads.parse(payload) ?: return false
      if (parsed.first != "sync") return false
      val i = parsed.second["i"]?.toIntOrNull() ?: return false
      val n = parsed.second["n"]?.toIntOrNull() ?: return false
      total = n
      parts[i] = parsed.second["data"].orEmpty()
      if (parts.size == n) {
        val b64 = (0 until n).joinToString("") { parts[it] ?: "" }
        val bytes = android.util.Base64.decode(b64, android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE)
        result = String(bytes, Charsets.UTF_8)
        return true
      }
      return false
    }

    var result: String? = null
      private set
  }

  /** Exporta a archivo compartible en /sdcard/Weaver (además del QR). */
  suspend fun exportToFile(context: Context, db: WeaverDb): File {
    val dir = File(android.os.Environment.getExternalStorageDirectory(), "Weaver")
    if (!dir.exists()) dir.mkdirs()
    val f = File(dir, "weaver-chats-${System.currentTimeMillis()}.json")
    f.writeText(exportAll(db))
    return f
  }
}
