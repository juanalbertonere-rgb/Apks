package com.example.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Conversación de chat. `target` recuerda con qué objetivo se ejecutó
 * (movil/pc) para mostrarlo en el drawer.
 */
@Entity(tableName = "conversations")
data class ConversationEntity(
  @PrimaryKey val id: String,
  val title: String,
  val target: String = "movil",
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis(),
  val pinned: Boolean = false
)

/**
 * Mensaje con soporte completo del bucle agéntico:
 *  - role: "user" | "assistant" | "tool" | "system"
 *  - toolCallsJson: array OpenAI de tool_calls en mensajes assistant
 *  - toolCallId: id del tool_call al que responde un mensaje tool
 *  - reasoning: cadena de pensamiento mostrada colapsable
 */
@Entity(
  tableName = "messages",
  indices = [Index("conversationId"), Index("seq")]
)
data class MessageEntity(
  @PrimaryKey val id: String,
  val conversationId: String,
  val role: String,
  val content: String?,
  val toolCallsJson: String? = null,
  val toolCallId: String? = null,
  val toolName: String? = null,
  val reasoning: String? = null,
  val seq: Long,
  val ts: Long = System.currentTimeMillis()
)

/**
 * Memoria del agente. scope == "global" → memory_save_fact (sobre el usuario,
 * cruza chats). scope == <chatId> → project_memory (bitácora de ese chat).
 */
@Entity(
  tableName = "facts",
  indices = [Index("scope"), Index(value = ["scope", "key"], unique = true)]
)
data class FactEntity(
  @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
  val scope: String,
  val key: String,
  val value: String,
  val ts: Long = System.currentTimeMillis()
)

/**
 * Sección "MI" (notas / tareas / eventos / lista de compras / notebooks).
 * kind: note | task | event | shopping | notebook
 */
@Entity(tableName = "me_items", indices = [Index("kind"), Index("updatedAt")])
data class MeItemEntity(
  @PrimaryKey val id: String,
  val kind: String,
  val title: String,
  val detail: String = "",
  /** Para eventos: epoch millis; para tareas: fecha objetivo opcional. */
  val dueAt: Long? = null,
  val done: Boolean = false,
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis(),
  /** Recurrencia de tareas agendadas (once, daily, weekly...). */
  val toolCallId: String? = null
)
