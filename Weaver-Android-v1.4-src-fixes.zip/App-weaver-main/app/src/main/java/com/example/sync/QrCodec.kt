package com.example.sync

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter

/** Codifica y decodifica QR reales con ZXing (sin Google Play Services). */
object QrCodec {

  /** Genera un Bitmap QR para el payload dado. */
  fun encode(payload: String, size: Int = 720): Bitmap {
    val matrix = QRCodeWriter().encode(
      payload,
      BarcodeFormat.QR_CODE,
      size,
      size,
      mapOf(com.google.zxing.EncodeHintType.MARGIN to 1)
    )
    val bmp = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.RGB_565)
    for (x in 0 until matrix.width) {
      for (y in 0 until matrix.height) {
        bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
      }
    }
    return bmp
  }

  /** Decodifica un frame YUV de CameraX. Devuelve el texto o null. */
  fun decodeYuv(data: ByteArray, width: Int, height: Int, rotationDegrees: Int): String? {
    fun tryDecode(w: Int, h: Int, bytes: ByteArray): String? {
      return try {
        val source = PlanarYUVLuminanceSource(bytes, w, h, 0, 0, w, h, false)
        val bmp = BinaryBitmap(HybridBinarizer(source))
        MultiFormatReader().decode(bmp, mapOf(DecodeHintType.TRY_HARDER to true)).text
      } catch (_: Exception) {
        null
      }
    }

    // Intento directo y rotado 90° (los sensores suelen venir rotados).
    return tryDecode(width, height, data)
      ?: run {
        val rotated = ByteArray(data.size)
        var i = 0
        for (x in 0 until width) {
          for (y in 0 until height) {
            rotated[i++] = data[y * width + x]
          }
        }
        tryDecode(height, width, rotated)
      }
      ?: run {
        // Último intento con binarizador simple
        try {
          val source = PlanarYUVLuminanceSource(data, width, height, 0, 0, width, height, false)
          MultiFormatReader().decode(BinaryBitmap(GlobalHistogramBinarizer(source))).text
        } catch (_: Exception) {
          null
        }
      }
  }
}

/** Construcción y parseo de los payloads weaver:// intercambiados por QR. */
object QrPayloads {

  const val SCHEME = "weaver"

  /** Payload que ESTE teléfono muestra en el onboarding para que la PC lo use. */
  fun phonePairing(name: String, host: String, port: Int, token: String, deviceId: String): String =
    "weaver://phone?v=1&name=${enc(name)}&host=$host&port=$port&token=${enc(token)}&device=${enc(deviceId)}"

  /** Payload que el bridge de la PC imprime/QR-ifica para que el móvil lo escanee. */
  fun bridgePairing(name: String, host: String, port: Int, token: String): String =
    "weaver://bridge?v=1&name=${enc(name)}&host=$host&port=$port&token=${enc(token)}"

  fun parse(payload: String): Pair<String, Map<String, String>>? {
    if (!payload.startsWith("weaver://")) return null
    val uri = android.net.Uri.parse(payload)
    val kind = uri.host ?: return null
    val params = mutableMapOf<String, String>()
    for (key in listOf("v", "name", "host", "port", "token", "device", "data", "i", "n")) {
      uri.getQueryParameter(key)?.let { params[key] = it }
    }
    return kind to params
  }

  private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")
}
