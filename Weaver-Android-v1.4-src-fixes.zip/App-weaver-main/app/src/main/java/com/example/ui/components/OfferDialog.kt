package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.ChatGptBorderSubtle
import com.example.ui.theme.ChatGptDrawerBg
import com.example.ui.theme.ChatGptPillSelected
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptTextSecondary

@Composable
fun OfferDialog(
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(24.dp))
        .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(24.dp)),
      color = ChatGptDrawerBg,
      tonalElevation = 6.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(ChatGptPillSelected),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.CardGiftcard,
              contentDescription = null,
              tint = Color(0xFF60A5FA),
              modifier = Modifier.size(22.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Text(
            text = "ChatGPT Plus",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = ChatGptTextPrimary,
            modifier = Modifier.weight(1f)
          )

          IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Cerrar",
              tint = ChatGptTextSecondary
            )
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
          text = "Desbloquea el poder completo de OpenAI",
          fontSize = 15.sp,
          fontWeight = FontWeight.Medium,
          color = ChatGptTextPrimary,
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(14.dp))

        val perks = listOf(
          "Acceso prioritario a GPT-4o sin restricciones",
          "Modo de voz avanzado en tiempo real",
          "Creación de imágenes ultrarrápida con DALL·E 3",
          "Análisis de datos, archivos de código y navegación web"
        )

        perks.forEach { perk ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 5.dp),
            verticalAlignment = Alignment.Top
          ) {
            Icon(
              imageVector = Icons.Default.Check,
              contentDescription = null,
              tint = Color(0xFF34D399),
              modifier = Modifier
                .size(18.dp)
                .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = perk,
              fontSize = 13.sp,
              color = ChatGptTextSecondary,
              lineHeight = 18.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
          shape = RoundedCornerShape(24.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = Color.White,
            contentColor = Color.Black
          )
        ) {
          Text(
            text = "Reclamar 1 mes gratis",
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "Cancela cuando quieras. Aplican términos y condiciones.",
          fontSize = 11.sp,
          color = ChatGptTextMuted
        )
      }
    }
  }
}
