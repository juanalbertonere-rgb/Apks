package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ChatGPTColorScheme = darkColorScheme(
  primary = ChatGptVoiceBlue,
  onPrimary = Color.White,
  primaryContainer = ChatGptInputBg,
  onPrimaryContainer = ChatGptTextPrimary,
  secondary = ChatGptPillSelected,
  onSecondary = ChatGptTextPrimary,
  background = ChatGptBlack,
  onBackground = ChatGptTextPrimary,
  surface = ChatGptSurface,
  onSurface = ChatGptTextPrimary,
  surfaceVariant = ChatGptInputBg,
  onSurfaceVariant = ChatGptTextSecondary,
  outline = ChatGptBorderSubtle
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  // ChatGPT mobile dark mode aesthetic
  MaterialTheme(
    colorScheme = ChatGPTColorScheme,
    typography = Typography,
    content = content
  )
}
