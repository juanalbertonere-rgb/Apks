package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Weaver / ChatGPT Pure Dark Palette
val ChatGptBlack = Color(0xFF000000)
val ChatGptDrawerBg = Color(0xFF0C0C0C)
val ChatGptSurface = Color(0xFF141414)
val ChatGptInputBg = Color(0xFF161616)
val ChatGptPillSelected = Color(0xFF1F1F1F)
val ChatGptPillHover = Color(0xFF262626)
val ChatGptBorderSubtle = Color(0xFF262626)

// Text Colors
val ChatGptTextPrimary = Color(0xFFEDEDED)
val ChatGptTextSecondary = Color(0xFFA1A1AA)
val ChatGptTextMuted = Color(0xFF71717A)

// Weaver Accent & Tool Colors
val WeaverCardBg = Color(0xFF111111)
val WeaverCardBorder = Color(0xFF222222)
val WeaverInputBorder = Color(0xFF2C2C2C)
val WeaverChipBg = Color(0xFF18181B)
val WeaverChipBorder = Color(0xFF27272A)
val WeaverChipActiveBg = Color(0xFF27272A)

// Accent Colors
val ChatGptVoiceBlue = Color(0xFF3B82F6)
val ChatGptDotBlue = Color(0xFF3B82F6)
val ChatGptTagBg = Color(0xFF1E293B)
val ChatGptTagText = Color(0xFF60A5FA)
val ChatGptAvatarOrange = Color(0xFFE59B20)
val ChatGptOfferBlue = Color(0xFF1E293B)
val ChatGptOfferBorder = Color(0xFF3B82F6)

// Button States
val ChatGptIconColor = Color(0xFFECECEC)
val ChatGptIconMuted = Color(0xFF8E8E93)
