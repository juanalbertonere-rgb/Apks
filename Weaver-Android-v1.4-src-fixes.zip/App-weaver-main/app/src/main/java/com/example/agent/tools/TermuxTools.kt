package com.example.agent.tools

import android.content.Context
import com.example.agent.core.ToolDef
import com.example.agent.core.ToolOutput
import com.example.agent.core.ToolSpec
import com.example.termux.TermuxBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Tools de shell real en el dispositivo vía Termux. */
object TermuxTools {

  fun specs(context: Context): List<ToolSpec> = listOf(
    ToolSpec(
      ToolDef(
        "termux_exec",
        "Ejecuta un comando shell de Linux real en el teléfono vía Termux (sin root). Tienes bash, python, git, curl, etc. si están instalados en Termux. Devuelve stdout, stderr y código de salida. Ejecuta en /data/data/com.termux/files/home por defecto.",
        Schema.obj(
          "command" to "string", "workdir" to "string", "timeout_ms" to "number",
          required = listOf("command")
        )
      ),
      group = "Shell (Termux)",
      destructive = true
    ) { args, ctx ->
      if (ctx.cancelled) return@ToolSpec ToolOutput(false, "", "cancelado")
      val cmd = args.optString("command", "")
      if (cmd.isBlank()) return@ToolSpec ToolOutput(false, "", "command vacío")
      val timeout = args.optLong("timeout_ms", 60_000).coerceIn(5_000, 300_000)
      val result = withContext(Dispatchers.IO) {
        TermuxBridge.execute(context, cmd, args.optString("workdir", "/data/data/com.termux/files/home"), timeout)
      }
      ToolOutput(result.optBoolean("ok"), result.toString(), result.optString("error").takeIf { it.isNotEmpty() && it != "null" })
    },

    ToolSpec(
      ToolDef(
        "termux_status",
        "Comprueba si Termux está instalado, dónde vive la carpeta de intercambio y si es accesible.",
        Schema.obj()
      ),
      group = "Shell (Termux)"
    ) { _, _ ->
      val st = TermuxBridge.status(context)
      ToolOutput(true, st.toString())
    }
  )
}
