package com.example.ui.scan

import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.sync.QrCodec
import java.util.concurrent.Executors

/**
 * Escáner de QR con CameraX + ZXing (sin Google Play Services).
 * onScanned se dispara con el contenido; la cámara sigue activa para
 * escanear QR múltiples (sincronización por partes).
 */
@Composable
fun QrScanScreen(
  onScanned: (String) -> Unit,
  onClose: () -> Unit
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val executor = remember { Executors.newSingleThreadExecutor() }
  var lastScan by remember { mutableStateOf("") }
  var lastScanAt by remember { mutableStateOf(0L) }

  DisposableEffect(Unit) {
    onDispose { executor.shutdown() }
  }

  Box(
    modifier = Modifier
      .fillMaxWidth()
      .height(380.dp)
      .clip(RoundedCornerShape(14.dp))
      .background(Color.Black)
  ) {
    AndroidView(
      factory = { ctx ->
        val previewView = PreviewView(ctx)
        val providerFuture = ProcessCameraProvider.getInstance(ctx)
        providerFuture.addListener({
          val provider = providerFuture.get()
          val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
          }
          val analysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
          analysis.setAnalyzer(executor) { imageProxy ->
            val text = decodeFrame(imageProxy)
            imageProxy.close()
            if (text != null) {
              val now = System.currentTimeMillis()
              // Antirebote: mismo payload ignora 2.5s
              if (!(text == lastScan && now - lastScanAt < 2500)) {
                lastScan = text
                lastScanAt = now
                ContextCompat.getMainExecutor(ctx).execute { onScanned(text) }
              }
            }
          }
          runCatching {
            provider.unbindAll()
            provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
          }
        }, ContextCompat.getMainExecutor(ctx))
        previewView
      },
      modifier = Modifier.fillMaxSize()
    )

    // Marco guía
    Box(
      modifier = Modifier
        .align(Alignment.Center)
        .size(230.dp)
        .border(2.dp, Color(0xFF4ADE80), RoundedCornerShape(16.dp))
    )

    Text(
      "Enfoca el QR del bridge o de chats de Weaver",
      fontSize = 12.sp,
      color = Color.White,
      modifier = Modifier
        .align(Alignment.TopCenter)
        .padding(top = 14.dp)
        .background(Color(0x99000000), RoundedCornerShape(8.dp))
        .padding(horizontal = 10.dp, vertical = 5.dp)
    )

    Icon(
      imageVector = Icons.Default.Close,
      contentDescription = "Cerrar",
      tint = Color.White,
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(10.dp)
        .clip(RoundedCornerShape(50))
        .background(Color(0x66000000))
        .clickable { onClose() }
        .padding(6.dp)
        .size(20.dp)
    )
  }
}

private fun decodeFrame(image: ImageProxy): String? {
  return try {
    val plane = image.planes[0]
    val buffer = plane.buffer
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    QrCodec.decodeYuv(bytes, image.width, image.height, image.imageInfo.rotationDegrees)
  } catch (_: Exception) {
    null
  }
}
