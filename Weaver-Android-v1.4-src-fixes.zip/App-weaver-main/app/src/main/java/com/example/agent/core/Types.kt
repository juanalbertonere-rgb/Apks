package com.example.agent.core

import org.json.JSONArray
import org.json.JSONObject

/** Roles soportados en el protocolo OpenAI-compatible. */
const val ROLE_SYSTEM = "system"
const val ROLE_USER = "user"
const val ROLE_ASSISTANT = "assistant"
const val ROLE_TOOL = "tool"

/** Mensaje del protocolo. Equivalente a Message en el agente de PC. */
data class LMessage(
  val role: String,
  val content: String?,
  val toolCalls: List<LToolCall> = emptyList(),
  val toolCallId: String? = null,
  val reasoning: String? = null
) {
  fun toJson(): JSONObject {
    val o = JSONObject().put("role", role)
    when (role) {
      ROLE_ASSISTANT -> {
        o.put("content", content ?: JSONObject.NULL)
        if (toolCalls.isNotEmpty()) {
          val arr = JSONArray()
          toolCalls.forEach { arr.put(it.toJson()) }
          o.put("tool_calls", arr)
        }
      }
      ROLE_TOOL -> {
        o.put("content", content ?: "")
        o.put("tool_call_id", toolCallId ?: "")
      }
      else -> o.put("content", content ?: "")
    }
    return o
  }

  companion object {
    fun system(content: String) = LMessage(ROLE_SYSTEM, content)
    fun user(content: String) = LMessage(ROLE_USER, content)
    fun assistant(content: String?, toolCalls: List<LToolCall> = emptyList()) =
      LMessage(ROLE_ASSISTANT, content, toolCalls)
    fun tool(toolCallId: String, content: String) = LMessage(ROLE_TOOL, content, toolCallId = toolCallId)

    fun fromEntityJson(json: JSONObject): LMessage {
      val role = json.optString("role", ROLE_USER)
      val content = if (json.isNull("content")) null else json.optString("content")
      val calls = mutableListOf<LToolCall>()
      val arr = json.optJSONArray("tool_calls")
      if (arr != null) for (i in 0 until arr.length()) {
        val tc = arr.optJSONObject(i) ?: continue
        val fn = tc.optJSONObject("function") ?: continue
        calls.add(LToolCall(tc.optString("id"), fn.optString("name"), fn.optString("arguments", "{}")))
      }
      return LMessage(
        role = role,
        content = content,
        toolCalls = calls,
        toolCallId = json.optString("tool_call_id", null),
        reasoning = json.optString("reasoning", null)
      )
    }
  }
}

/** Tool call OpenAI: {id, type:"function", function:{name, arguments}}. */
data class LToolCall(
  val id: String,
  val name: String,
  val arguments: String
) {
  fun parsedArgs(): JSONObject = runCatching { JSONObject(arguments.ifBlank { "{}" }) }.getOrElse { JSONObject() }

  fun toJson(): JSONObject = JSONObject()
    .put("id", id)
    .put("type", "function")
    .put("function", JSONObject().put("name", name).put("arguments", arguments))
}

/** Definición de herramienta (schema OpenAI). */
data class ToolDef(val name: String, val description: String, val parameters: JSONObject) {
  fun toJson(): JSONObject = JSONObject()
    .put("type", "function")
    .put("function", JSONObject()
      .put("name", name)
      .put("description", description)
      .put("parameters", parameters))
}

/** Resultado de ejecutar una herramienta. */
data class ToolOutput(val ok: Boolean, val output: String, val error: String? = null)

/** Handler de una herramienta. */
fun interface ToolHandler {
  suspend fun invoke(args: JSONObject, ctx: ToolContext): ToolOutput
}

/** Contexto de ejecución disponible para los handlers. */
class ToolContext(
  val conversationId: String,
  val round: Int,
  val signal: java.util.concurrent.atomic.AtomicBoolean? = null
) {
  val cancelled: Boolean get() = signal?.get() == true
}

/** Registro de una herramienta en el registry. */
class ToolSpec(
  val def: ToolDef,
  val group: String,
  val destructive: Boolean = false,
  val handler: ToolHandler
)

/** Record de un round del bucle agéntico. */
data class RoundRecord(
  val round: Int,
  val assistantText: String? = null,
  val reasoning: String? = null,
  val toolCalls: List<ExecutedCall> = emptyList(),
  val ts: Long = System.currentTimeMillis()
)

data class ExecutedCall(val call: LToolCall, val args: JSONObject, val result: ToolOutput)

/** Estado normalizado de la sesión (reconstruible, como en PC). */
class SessionState(
  val sessionId: String,
  var goal: String,
  val rounds: MutableList<RoundRecord> = mutableListOf()
) {
  var outcome: String? = null
}

/** Eventos que el runner emite hacia la UI en vivo. */
sealed class AgentEvent {
  data class TextDelta(val delta: String) : AgentEvent()
  data class ReasoningDelta(val delta: String) : AgentEvent()
  data class ThinkingDuration(val seconds: Long) : AgentEvent()
  data class ToolCallStarted(val round: Int, val call: LToolCall) : AgentEvent()
  data class ToolCallFinished(val round: Int, val call: LToolCall, val result: ToolOutput) : AgentEvent()
  data class RoundFinished(val round: Int) : AgentEvent()
  data class AwaitingUserInput(val call: LToolCall, val args: JSONObject) : AgentEvent()
  data class Finished(val status: String, val summary: String) : AgentEvent()
}

/** Interfaz del proveedor LLM que consume AgentRunner (fun interface para lambdas). */
fun interface LlmApi {
  suspend fun chat(
    model: String,
    messages: List<LMessage>,
    tools: List<ToolDef>,
    onTextDelta: suspend (String) -> Unit,
    onReasoningDelta: suspend (String) -> Unit
  ): LlmApiResult
}

data class LlmApiResult(val text: String, val toolCalls: List<LToolCall>)
