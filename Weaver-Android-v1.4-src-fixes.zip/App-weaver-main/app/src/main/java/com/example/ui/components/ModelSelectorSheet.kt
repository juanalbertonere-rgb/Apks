package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChatGptBorderSubtle
import com.example.ui.theme.ChatGptDrawerBg
import com.example.ui.theme.ChatGptInputBg
import com.example.ui.theme.ChatGptPillSelected
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptTextSecondary

/**
 * Una opción de modelo REAL del proveedor (viene de /models).
 *  - id      → identificador que se envía a la API (ej: "openai/gpt-4o-mini")
 *  - name    → nombre limpio sin vendor (ej: "GPT-4o mini")
 *  - vendor  → casa del modelo (ej: "OpenAI", "Anthropic", "google") para el chip
 */
data class ModelOption(
  val id: String,
  val name: String,
  val description: String,
  val icon: ImageVector,
  val vendor: String = ""
)

/**
 * Selector de modelos DENTRO del chat (píldora del compositor).
 *
 * Fixes incluidos:
 *  - Buscador para filtrar por nombre/id/vendor (OpenRouter trae cientos).
 *  - Lista LazyColumn desplazable (antes un Column fijo se congelaba).
 *  - Estado de carga y error con "Reintentar".
 *  - Si falta la API key (o fue rechazada 401), se puede escribir AQUÍ,
 *    guardar y recargar sin ir a Ajustes.
 *  - Chip de vendor por modelo: los modelos de OpenRouter ya no se muestran
 *    todos como "OpenAI: …"; el prefijo queda en el chip y el nombre limpio.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelSelectorSheet(
  selectedModelId: String,
  models: List<ModelOption>,
  isLoading: Boolean,
  error: String?,
  providerName: String,
  apiKeyConfigured: Boolean,
  onModelSelected: (ModelOption) -> Unit,
  onRetry: () -> Unit,
  onSaveApiKey: (String) -> Unit,
  onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState()
  var query by remember { mutableStateOf("") }
  var apiKeyDraft by remember { mutableStateOf("") }
  var showKey by remember { mutableStateOf(false) }

  val filtered = remember(models, query) {
    val q = query.trim().lowercase()
    if (q.isEmpty()) models
    else models.filter {
      it.name.lowercase().contains(q) ||
        it.id.lowercase().contains(q) ||
        it.vendor.lowercase().contains(q)
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = ChatGptDrawerBg,
    contentColor = ChatGptTextPrimary,
    dragHandle = {
      Box(
        modifier = Modifier
          .padding(top = 10.dp, bottom = 10.dp)
          .size(width = 36.dp, height = 4.dp)
          .clip(RoundedCornerShape(2.dp))
          .background(ChatGptBorderSubtle)
      )
    },
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .imePadding()
        .padding(horizontal = 16.dp)
        .navigationBarsPadding()
        .padding(bottom = 16.dp)
    ) {
      // ── Cabecera ──
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp)
      ) {
        Text(
          text = "Modelos",
          fontSize = 18.sp,
          fontWeight = FontWeight.SemiBold,
          color = ChatGptTextPrimary,
          modifier = Modifier.weight(1f)
        )
        Text(
          text = providerName,
          fontSize = 12.sp,
          color = ChatGptTextMuted
        )
        Spacer(modifier = Modifier.width(8.dp))
        Icon(
          imageVector = Icons.Default.Close,
          contentDescription = "Cerrar",
          tint = ChatGptTextMuted,
          modifier = Modifier
            .size(20.dp)
            .clip(CircleShape)
            .clickable { onDismiss() }
            .padding(2.dp)
        )
      }

      // ── Buscador ──
      OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        singleLine = true,
        placeholder = {
          Text("Buscar modelo…", fontSize = 13.sp, color = ChatGptTextMuted)
        },
        leadingIcon = {
          Icon(Icons.Default.Search, contentDescription = null, tint = ChatGptTextMuted, modifier = Modifier.size(18.dp))
        },
        trailingIcon = {
          if (query.isNotEmpty()) {
            Icon(
              Icons.Default.Close, contentDescription = "Limpiar",
              tint = ChatGptTextMuted, modifier = Modifier
                .size(16.dp)
                .clickable { query = "" }
            )
          }
        },
        keyboardOptions = KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { /* filtrado en vivo */ }),
        textStyle = androidx.compose.ui.text.TextStyle(color = ChatGptTextPrimary, fontSize = 14.sp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = ChatGptBorderSubtle,
          unfocusedBorderColor = ChatGptBorderSubtle,
          focusedContainerColor = ChatGptInputBg,
          unfocusedContainerColor = ChatGptInputBg,
          cursorColor = ChatGptTextPrimary
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp)
      )

      Spacer(modifier = Modifier.height(8.dp))

      // ── API key inline (falta o fue rechazada) ──
      if (!apiKeyConfigured || error?.contains("API key", ignoreCase = true) == true) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ChatGptInputBg)
            .padding(12.dp)
        ) {
          Text(
            text = if (apiKeyConfigured) "API key rechazada por el proveedor" else "Falta tu API key de $providerName",
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFFFACC15)
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
              value = apiKeyDraft,
              onValueChange = { apiKeyDraft = it },
              singleLine = true,
              placeholder = { Text("sk-or-v1-…", fontSize = 12.sp, color = ChatGptTextMuted) },
              visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
              textStyle = androidx.compose.ui.text.TextStyle(color = ChatGptTextPrimary, fontSize = 13.sp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ChatGptBorderSubtle,
                unfocusedBorderColor = ChatGptBorderSubtle,
                focusedContainerColor = Color(0x14FFFFFF),
                unfocusedContainerColor = Color(0x14FFFFFF),
                cursorColor = ChatGptTextPrimary
              ),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (showKey) "Ocultar" else "Ver",
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium,
              color = ChatGptTextMuted,
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable { showKey = !showKey }
                .padding(horizontal = 10.dp, vertical = 8.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Guardar",
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF4ADE80),
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable(enabled = apiKeyDraft.isNotBlank()) {
                  onSaveApiKey(apiKeyDraft)
                  apiKeyDraft = ""
                }
                .padding(horizontal = 10.dp, vertical = 8.dp)
            )
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
      }

      // ── Estado de carga ──
      if (isLoading) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp)
        ) {
          CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = ChatGptTextSecondary)
          Spacer(modifier = Modifier.width(10.dp))
          Text("Buscando modelos en $providerName…", fontSize = 13.sp, color = ChatGptTextSecondary)
        }
      }

      // ── Estado de error ──
      if (!isLoading && error != null) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ChatGptInputBg)
            .padding(12.dp)
        ) {
          Text("No se pudieron cargar los modelos", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = ChatGptTextPrimary)
          Spacer(modifier = Modifier.height(4.dp))
          Text(error, fontSize = 12.sp, color = ChatGptTextSecondary, lineHeight = 16.sp)
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Reintentar",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF7DD3FC),
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .clickable { onRetry() }
              .padding(horizontal = 10.dp, vertical = 6.dp)
          )
        }
      }

      // ── Lista desplazable de modelos ──
      if (!isLoading) {
        if (filtered.isEmpty()) {
          Text(
            text = if (query.isBlank()) "Sin modelos disponibles" else "Sin resultados para \"$query\"",
            fontSize = 13.sp,
            color = ChatGptTextMuted,
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 8.dp, vertical = 20.dp)
          )
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(max = 430.dp)
          ) {
            items(filtered, key = { it.id }) { model ->
              val isSelected = model.id == selectedModelId
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(16.dp))
                  .background(if (isSelected) ChatGptPillSelected else Color.Transparent)
                  .clickable {
                    onModelSelected(model)
                    onDismiss()
                  }
                  .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(ChatGptPillSelected),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = model.icon,
                    contentDescription = null,
                    tint = ChatGptTextPrimary,
                    modifier = Modifier.size(18.dp)
                  )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    if (model.vendor.isNotBlank()) {
                      Box(
                        modifier = Modifier
                          .clip(RoundedCornerShape(5.dp))
                          .background(Color(0xFF2A2A2A))
                          .padding(horizontal = 6.dp, vertical = 2.dp)
                      ) {
                        Text(
                          text = model.vendor,
                          fontSize = 10.sp,
                          fontWeight = FontWeight.SemiBold,
                          color = ChatGptTextSecondary
                        )
                      }
                      Spacer(modifier = Modifier.width(7.dp))
                    }
                    Text(
                      text = model.name,
                      fontWeight = FontWeight.Medium,
                      fontSize = 14.sp,
                      color = ChatGptTextPrimary,
                      maxLines = 1,
                      overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                  }
                  Text(
                    text = model.description,
                    fontSize = 11.sp,
                    color = ChatGptTextMuted,
                    lineHeight = 14.sp,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                  )
                }

                if (isSelected) {
                  Spacer(modifier = Modifier.width(8.dp))
                  Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Seleccionado",
                    tint = ChatGptTextPrimary,
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.height(2.dp))
            }
          }
          if (query.isNotBlank()) {
            Text(
              text = "${filtered.size} de ${models.size} modelos",
              fontSize = 11.sp,
              color = ChatGptTextMuted,
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp)
            )
          }
        }
      }
    }
  }
}
