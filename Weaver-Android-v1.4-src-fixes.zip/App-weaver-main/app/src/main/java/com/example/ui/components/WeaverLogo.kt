package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Geometric folded ribbon "W" logo for Weaver as shown in the screenshot.
 * Precision polygon and ribbon paths for crisp rendering at any size.
 */
@Composable
fun WeaverLogo(
  modifier: Modifier = Modifier,
  size: Dp = 48.dp,
  color: Color = Color.White
) {
  Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height

    // Geometric Origami W:
    // Composed of two angled folded ribbon chevrons
    // Left ribbon:
    val leftPath = Path().apply {
      moveTo(w * 0.12f, h * 0.22f)
      lineTo(w * 0.28f, h * 0.22f)
      lineTo(w * 0.44f, h * 0.78f)
      lineTo(w * 0.32f, h * 0.78f)
      close()
    }

    val leftFoldPath = Path().apply {
      moveTo(w * 0.32f, h * 0.78f)
      lineTo(w * 0.44f, h * 0.78f)
      lineTo(w * 0.54f, h * 0.38f)
      lineTo(w * 0.44f, h * 0.38f)
      close()
    }

    // Right ribbon:
    val rightFoldPath = Path().apply {
      moveTo(w * 0.56f, h * 0.38f)
      lineTo(w * 0.46f, h * 0.38f)
      lineTo(w * 0.56f, h * 0.78f)
      lineTo(w * 0.68f, h * 0.78f)
      close()
    }

    val rightPath = Path().apply {
      moveTo(w * 0.56f, h * 0.78f)
      lineTo(w * 0.68f, h * 0.78f)
      lineTo(w * 0.88f, h * 0.22f)
      lineTo(w * 0.72f, h * 0.22f)
      close()
    }

    // Draw folded facets with subtle opacity differences for depth
    drawPath(path = leftPath, color = color, style = Fill)
    drawPath(path = leftFoldPath, color = color.copy(alpha = 0.88f), style = Fill)
    drawPath(path = rightFoldPath, color = color.copy(alpha = 0.88f), style = Fill)
    drawPath(path = rightPath, color = color, style = Fill)
  }
}
