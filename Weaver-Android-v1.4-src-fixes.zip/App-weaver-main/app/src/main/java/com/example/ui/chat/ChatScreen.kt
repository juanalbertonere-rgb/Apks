package com.example.ui.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.DeviceSegmentMode
import com.example.ui.components.OpenAiSegmentedControl
import com.example.ui.components.WeaverLogo
import com.example.ui.theme.ChatGptBlack
import com.example.ui.theme.ChatGptBorderSubtle
import com.example.ui.theme.ChatGptDrawerBg
import com.example.ui.theme.ChatGptIconColor
import com.example.ui.theme.ChatGptIconMuted
import com.example.ui.theme.ChatGptInputBg
import com.example.ui.theme.ChatGptPillSelected
import com.example.ui.theme.ChatGptTagBg
import com.example.ui.theme.ChatGptTagText
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptTextSecondary
import com.example.ui.theme.WeaverCardBg
import com.example.ui.theme.WeaverCardBorder
import com.example.ui.theme.WeaverChipActiveBg
import com.example.ui.theme.WeaverChipBg
import com.example.ui.theme.WeaverChipBorder
import com.example.ui.theme.WeaverInputBorder
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
  viewModel: ChatViewModel,
  uiState: ChatUiState,
  onOpenDrawer: () -> Unit,
  onOpenComplementos: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val listState = rememberLazyListState()
  val coroutineScope = rememberCoroutineScope()
  var showMenuOverflow by remember { mutableStateOf(false) }
  var toolDetail by remember { mutableStateOf<ChatMessage?>(null) }

  // Keyboard dismiss controllers
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current

  fun dismissKeyboard() {
    focusManager.clearFocus()
    keyboardController?.hide()
  }

  val isScrolledUp by remember {
    derivedStateOf {
      listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 200
    }
  }

  // Auto scroll on new messages
  LaunchedEffect(uiState.messages.size, uiState.isGenerating) {
    if (uiState.messages.isNotEmpty()) {
      listState.animateScrollToItem(uiState.messages.size - 1)
    }
  }

  // Dismiss keyboard when user scrolls chat
  LaunchedEffect(listState.isScrollInProgress) {
    if (listState.isScrollInProgress) {
      dismissKeyboard()
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(ChatGptBlack)
      .statusBarsPadding()
      .pointerInput(Unit) {
        detectTapGestures(onTap = { dismissKeyboard() })
      }
  ) {
      // -------------------------------------------------------------
      // TOP APP BAR: Centered OpenAI Segmented Control in the middle at the top
      // -------------------------------------------------------------
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .padding(horizontal = 10.dp)
          .pointerInput(Unit) {
            detectTapGestures(onTap = { dismissKeyboard() })
          },
        contentAlignment = Alignment.Center
      ) {
        // Left: Drawer menu toggle + "Weaver" title
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .align(Alignment.CenterStart)
            .clip(RoundedCornerShape(8.dp))
            .clickable { onOpenDrawer() }
            .padding(vertical = 4.dp, horizontal = 2.dp)
        ) {
          Icon(
            imageVector = Icons.Outlined.Menu,
            contentDescription = "Abrir menú",
            tint = Color.White,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Weaver",
            fontSize = 15.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White
          )
        }

        // Center: OpenAI Segmented Control (Móvil / PC) exactly in the middle at the top
        OpenAiSegmentedControl(
          selectedMode = uiState.deviceSegmentMode,
          onModeSelected = { viewModel.setDeviceSegmentMode(it) },
          modifier = Modifier.align(Alignment.Center)
        )

        // Right: Model label + overflow button
        Row(
          modifier = Modifier.align(Alignment.CenterEnd),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .clickable { viewModel.toggleModelSelector(true) }
              .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = uiState.selectedModel.name.lowercase().replace(" ", "-"),
              fontSize = 11.5.sp,
              color = ChatGptTextSecondary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.width(2.dp))
            Icon(
              imageVector = Icons.Default.KeyboardArrowDown,
              contentDescription = "Cambiar modelo",
              tint = ChatGptTextSecondary,
              modifier = Modifier.size(15.dp)
            )
          }

          // More options overflow button
          Box {
            IconButton(
              onClick = { showMenuOverflow = true },
              modifier = Modifier.size(30.dp)
            ) {
              Icon(
                imageVector = Icons.Default.MoreHoriz,
                contentDescription = "Más opciones",
                tint = ChatGptTextSecondary,
                modifier = Modifier.size(19.dp)
              )
            }

            DropdownMenu(
              expanded = showMenuOverflow,
              onDismissRequest = { showMenuOverflow = false },
              modifier = Modifier
                .background(ChatGptDrawerBg)
                .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(12.dp))
            ) {
              DropdownMenuItem(
                text = { Text("Nuevo chat", color = ChatGptTextPrimary) },
                onClick = {
                  showMenuOverflow = false
                  viewModel.startNewChat()
                }
              )
              DropdownMenuItem(
                text = { Text("Compartir conversación", color = ChatGptTextPrimary) },
                onClick = {
                  showMenuOverflow = false
                  val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, "Conversación de Weaver: ${uiState.currentChatTitle}")
                    type = "text/plain"
                  }
                  context.startActivity(Intent.createChooser(sendIntent, "Compartir chat"))
                }
              )
            }
          }
        }
      }

      // -------------------------------------------------------------
      // MAIN CONTENT: Welcome state OR Message List
      // Takes available space and contracts when keyboard opens
      // -------------------------------------------------------------
      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
          .pointerInput(Unit) {
            detectTapGestures(onTap = { dismissKeyboard() })
          }
      ) {
        if (uiState.messages.isEmpty()) {
          // Welcome Screen (exact layout from user screenshot)
          Column(
            modifier = Modifier
              .fillMaxSize()
              .verticalScroll(rememberScrollState())
              .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Origami Geometric "W" Logo
            WeaverLogo(
              size = 46.dp,
              color = Color.White
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Heading
            Text(
              text = "¿En qué deberíamos trabajar?",
              fontSize = 20.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Subtitle
            Text(
              text = "Dile a Weaver qué quieres lograr. Planeará, ejecutará acciones en tus apps vía accesibilidad AT-SPI, verificará y reflexionará para aprender.",
              fontSize = 12.5.sp,
              lineHeight = 18.sp,
              color = ChatGptTextSecondary,
              textAlign = TextAlign.Center,
              modifier = Modifier.widthIn(max = 380.dp)
            )

            Spacer(modifier = Modifier.height(26.dp))

            // Suggestion Cards (4 cards from screenshot)
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 440.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              defaultSuggestions.forEach { suggestion ->
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(WeaverCardBg)
                    .border(1.dp, WeaverCardBorder, RoundedCornerShape(10.dp))
                  .clickable {
                    dismissKeyboard()
                    viewModel.sendSuggestion(suggestion)
                  }
                  .padding(horizontal = 14.dp, vertical = 11.dp)
                ) {
                  Text(
                    text = suggestion,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = Color(0xFFD4D4D8)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))
          }
        } else {
          // Active Chat Messages
          LazyColumn(
            state = listState,
            modifier = Modifier
              .fillMaxSize()
              .pointerInput(Unit) {
                detectTapGestures(onTap = { dismissKeyboard() })
              }
              .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            item {
              Spacer(modifier = Modifier.height(6.dp))
            }

            items(uiState.messages, key = { it.id }) { message ->
              when (message.kind) {
                "tool" -> {
                  ToolActivityRow(message = message, onTap = { dismissKeyboard(); toolDetail = message })
                }
                "ask_user" -> {
                  InteractivePromptWidget(
                    message = message,
                    enabled = !message.answered && !uiState.isGenerating,
                    onSubmit = { answer -> viewModel.submitAskUser(message.toolCallId ?: "", answer) },
                    onTap = { dismissKeyboard() }
                  )
                }
                else -> {
                  if (message.isUser) {
                    UserMessageBubble(
                      message = message,
                      onTap = { dismissKeyboard() }
                    )
                  } else {
                    AssistantMessageBubble(
                      message = message,
                      onCopy = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Weaver", message.text)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Copiado al portapapeles", Toast.LENGTH_SHORT).show()
                      },
                      onShare = {
                        val sendIntent = Intent().apply {
                          action = Intent.ACTION_SEND
                          putExtra(Intent.EXTRA_TEXT, message.text)
                          type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Compartir mensaje"))
                      },
                      onEdit = {
                        viewModel.onInputTextChanged(message.text.take(80))
                      },
                      onTap = { dismissKeyboard() }
                    )
                  }
                }
              }
            }

            if (uiState.isGenerating) {
              item {
                Row(
                  modifier = Modifier.padding(vertical = 12.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = ChatGptIconColor,
                    strokeWidth = 2.dp
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Text(
                    text = uiState.liveActivity ?: "Weaver está planificando acciones...",
                    fontSize = 13.sp,
                    color = ChatGptTextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Cancelar",
                    fontSize = 12.sp,
                    color = Color(0xFFF87171),
                    modifier = Modifier
                      .clip(RoundedCornerShape(8.dp))
                      .clickable { viewModel.cancelGeneration() }
                      .padding(horizontal = 6.dp, vertical = 3.dp)
                  )
                }
              }
            }

            item {
              Spacer(modifier = Modifier.height(8.dp))
            }
          }
        }

        // Floating scroll-to-bottom button inside the main content area
        androidx.compose.animation.AnimatedVisibility(
          visible = isScrolledUp && uiState.messages.isNotEmpty(),
          enter = fadeIn(),
          exit = fadeOut(),
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 12.dp)
        ) {
          Box(
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(ChatGptInputBg)
              .border(1.dp, ChatGptBorderSubtle, CircleShape)
              .clickable {
                coroutineScope.launch {
                  if (uiState.messages.isNotEmpty()) {
                    listState.animateScrollToItem(uiState.messages.size - 1)
                  }
                }
              },
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.ArrowDownward,
              contentDescription = "Ir abajo",
              tint = ChatGptIconColor,
              modifier = Modifier.size(16.dp)
            )
          }
        }
      }

    // -------------------------------------------------------------
    // BOTTOM INPUT CARD & DISCLAIMER (Exact Weaver Replica from Screenshot)
    // Sits directly at the bottom of the Column, resting cleanly on top of
    // the system navigation bar or keyboard!
    // -------------------------------------------------------------
    val combinedInsets = WindowInsets.navigationBars.union(WindowInsets.ime)

    Column(
      modifier = Modifier
        .fillMaxWidth()
        .windowInsetsPadding(combinedInsets.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal))
        .padding(horizontal = 14.dp, vertical = 4.dp)
    ) {
      // Main Input Container
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(ChatGptInputBg)
          .border(1.dp, WeaverInputBorder, RoundedCornerShape(16.dp))
          .padding(horizontal = 12.dp, vertical = 10.dp)
      ) {
        Column(
          modifier = Modifier.fillMaxWidth()
        ) {
          // Context tag if active
          if (uiState.activeContextTag != null) {
            Row(
              modifier = Modifier
                .padding(bottom = 6.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(ChatGptTagBg)
                .clickable { viewModel.removeContextTag() }
                .padding(horizontal = 8.dp, vertical = 3.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = uiState.activeContextTag,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = ChatGptTagText
              )
              Spacer(modifier = Modifier.width(4.dp))
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Quitar etiqueta",
                tint = ChatGptTagText,
                modifier = Modifier.size(12.dp)
              )
            }
          }

          // Top: Multi-line Text Field with prompt placeholder
          BasicTextField(
            value = uiState.inputText,
            onValueChange = { viewModel.onInputTextChanged(it) },
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(min = 28.dp, max = 120.dp),
            textStyle = TextStyle(
              color = Color.White,
              fontSize = 14.sp,
              lineHeight = 20.sp
            ),
            cursorBrush = SolidColor(Color.White),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = {
              viewModel.sendMessage()
              dismissKeyboard()
            }),
            decorationBox = { innerTextField ->
              if (uiState.inputText.isEmpty()) {
                Text(
                  text = "Dime lo que quieres hacer... (usa @ para mencionar skills, proyectos, proveedores)",
                  color = ChatGptTextMuted,
                  fontSize = 13.5.sp,
                  lineHeight = 18.sp
                )
              }
              innerTextField()
            }
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Bottom Toolbar inside input container:
          // [+] [Model] [Perseguir] [Memoria] [Bitacora] [Mic] [Send]
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically
          ) {
            // [+] button
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .clickable { viewModel.toggleAttachmentSheet(true) },
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Añadir herramienta o archivo",
                tint = ChatGptIconMuted,
                modifier = Modifier.size(18.dp)
              )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Model pill: vendor dinámico + nombre del modelo configurado
            Row(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(WeaverChipBg)
                .border(1.dp, WeaverChipBorder, RoundedCornerShape(14.dp))
                .clickable { viewModel.toggleModelSelector(true) }
                .padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (uiState.selectedModel.vendor.isNotBlank()) {
                Text(
                  text = uiState.selectedModel.vendor + " ",
                  fontSize = 11.5.sp,
                  color = ChatGptTextMuted
                )
              }
              Text(
                text = uiState.selectedModel.name,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Medium,
                color = ChatGptTextPrimary
              )
              Spacer(modifier = Modifier.width(3.dp))
              Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = null,
                tint = ChatGptIconMuted,
                modifier = Modifier.size(13.dp)
              )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Chip: Perseguir (SVG Target vector icon)
            Row(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (uiState.isPursueActive) WeaverChipActiveBg else WeaverChipBg)
                .border(1.dp, WeaverChipBorder, RoundedCornerShape(14.dp))
                .clickable { viewModel.togglePursue() }
                .padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              TargetSvgIcon(isActive = uiState.isPursueActive)
              Spacer(modifier = Modifier.width(5.dp))
              Text(
                text = "Perseguir",
                fontSize = 11.5.sp,
                color = if (uiState.isPursueActive) Color.White else ChatGptTextMuted
              )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Chip: Memoria (SVG Bookmark vector icon)
            Row(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (uiState.isMemoryActive) WeaverChipActiveBg else WeaverChipBg)
                .border(1.dp, WeaverChipBorder, RoundedCornerShape(14.dp))
                .clickable { viewModel.toggleMemory() }
                .padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Outlined.BookmarkBorder,
                contentDescription = null,
                tint = if (uiState.isMemoryActive) Color.White else ChatGptTextMuted,
                modifier = Modifier.size(13.dp)
              )
              Spacer(modifier = Modifier.width(5.dp))
              Text(
                text = "Memoria",
                fontSize = 11.5.sp,
                color = if (uiState.isMemoryActive) Color.White else ChatGptTextMuted
              )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Chip: Bitácora (SVG Code vector icon)
            Row(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (uiState.isLogActive) WeaverChipActiveBg else WeaverChipBg)
                .border(1.dp, WeaverChipBorder, RoundedCornerShape(14.dp))
                .clickable { viewModel.toggleLog() }
                .padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Outlined.Code,
                contentDescription = null,
                tint = if (uiState.isLogActive) Color.White else ChatGptTextMuted,
                modifier = Modifier.size(13.dp)
              )
              Spacer(modifier = Modifier.width(5.dp))
              Text(
                text = "Bitácora",
                fontSize = 11.5.sp,
                color = if (uiState.isLogActive) Color.White else ChatGptTextMuted
              )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Mic button
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .clickable {
                  Toast.makeText(context, "Escuchando instrucción por voz...", Toast.LENGTH_SHORT).show()
                },
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Dictado por voz",
                tint = ChatGptIconMuted,
                modifier = Modifier.size(17.dp)
              )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Upward arrow Send button
            val hasText = uiState.inputText.isNotBlank()
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(if (hasText) Color.White else Color(0xFF262626))
                .clickable(enabled = hasText) {
                  viewModel.sendMessage()
                  dismissKeyboard()
                },
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.ArrowUpward,
                contentDescription = "Enviar",
                tint = if (hasText) Color.Black else Color(0xFF71717A),
                modifier = Modifier.size(15.dp)
              )
            }
          }
        }
      }

      // Disclaimer text centered below input
      Text(
        text = "Weaver puede equivocarse. Verifica acciones críticas.",
        fontSize = 11.sp,
        color = Color(0xFF666666),
        textAlign = TextAlign.Center,
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 6.dp, bottom = 2.dp)
      )
    }
  }

  // -------------------------------------------------------------
  // ATTACHMENT / TOOLS / MODES PICKER SHEET (+)
  // -------------------------------------------------------------
  if (uiState.showAttachmentSheet) {
    val currentActiveMode = when {
      uiState.isPursueActive -> WeaverExecutionMode.PURSUIT
      uiState.isMemoryActive -> WeaverExecutionMode.CHAT_MEMORY
      uiState.isLogActive -> WeaverExecutionMode.PROJECT_MEMORY
      else -> null
    }

    WeaverAddMenuSheet(
      activeMode = currentActiveMode,
      onModeChanged = { newMode ->
        when (newMode) {
          WeaverExecutionMode.PLAN -> {
            if (uiState.isPursueActive) viewModel.togglePursue()
            if (uiState.isMemoryActive) viewModel.toggleMemory()
            if (uiState.isLogActive) viewModel.toggleLog()
            Toast.makeText(context, "Modo plan activado", Toast.LENGTH_SHORT).show()
          }
          WeaverExecutionMode.PURSUIT -> {
            if (!uiState.isPursueActive) viewModel.togglePursue()
            if (uiState.isMemoryActive) viewModel.toggleMemory()
            if (uiState.isLogActive) viewModel.toggleLog()
          }
          WeaverExecutionMode.COGNITIVE -> {
            if (uiState.isPursueActive) viewModel.togglePursue()
            if (uiState.isMemoryActive) viewModel.toggleMemory()
            if (uiState.isLogActive) viewModel.toggleLog()
            Toast.makeText(context, "Modo cognitivo activado", Toast.LENGTH_SHORT).show()
          }
          WeaverExecutionMode.CHAT_MEMORY -> {
            if (uiState.isPursueActive) viewModel.togglePursue()
            if (!uiState.isMemoryActive) viewModel.toggleMemory()
            if (uiState.isLogActive) viewModel.toggleLog()
          }
          WeaverExecutionMode.PROJECT_MEMORY -> {
            if (uiState.isPursueActive) viewModel.togglePursue()
            if (uiState.isMemoryActive) viewModel.toggleMemory()
            if (!uiState.isLogActive) viewModel.toggleLog()
          }
          WeaverExecutionMode.RLM -> {
            if (uiState.isPursueActive) viewModel.togglePursue()
            if (uiState.isMemoryActive) viewModel.toggleMemory()
            if (uiState.isLogActive) viewModel.toggleLog()
            Toast.makeText(context, "Modo RLM activado", Toast.LENGTH_SHORT).show()
          }
          null -> {
            if (uiState.isPursueActive) viewModel.togglePursue()
            if (uiState.isMemoryActive) viewModel.toggleMemory()
            if (uiState.isLogActive) viewModel.toggleLog()
          }
        }
      },
      onAddFiles = {
        viewModel.setContextTag("Archivos")
        Toast.makeText(context, "Adjuntar fotos y archivos", Toast.LENGTH_SHORT).show()
      },
      onUploadFolder = {
        viewModel.setContextTag("Carpeta")
        Toast.makeText(context, "Subir carpeta recursivamente", Toast.LENGTH_SHORT).show()
      },
      onAddFromUrl = {
        viewModel.setContextTag("URL")
        Toast.makeText(context, "Añadir desde URL", Toast.LENGTH_SHORT).show()
      },
      onAttachApp = {
        viewModel.setContextTag("Tauri App")
        Toast.makeText(context, "Adjuntar app (Tauri)", Toast.LENGTH_SHORT).show()
      },
      onOpenComplementos = {
        onOpenComplementos()
      },
      onDismiss = { viewModel.toggleAttachmentSheet(false) }
    )
  }

  // Visor del resultado completo de una tool (tap en la fila de actividad)
  toolDetail?.let { tm ->
    ModalBottomSheet(
      onDismissRequest = { toolDetail = null },
      containerColor = Color(0xFF171717)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 18.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Text(
          text = (if (tm.toolOk == false) "✕ " else "⚙ ") + (tm.toolName ?: "tool"),
          fontSize = 15.sp,
          fontWeight = FontWeight.SemiBold,
          color = if (tm.toolOk == false) Color(0xFFF87171) else Color(0xFF7DD3FC)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = tm.text,
          fontSize = 12.5.sp,
          lineHeight = 17.sp,
          color = Color(0xFFD4D4D8)
        )
        Spacer(modifier = Modifier.height(28.dp))
      }
    }
  }
}

@Composable
fun UserMessageBubble(
  message: ChatMessage,
  onTap: (() -> Unit)? = null
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.End
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth(0.88f)
        .clip(RoundedCornerShape(16.dp))
        .background(ChatGptPillSelected)
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null
        ) { onTap?.invoke() }
        .padding(horizontal = 15.dp, vertical = 11.dp)
    ) {
      Text(
        text = message.text,
        color = Color.White,
        fontSize = 14.5.sp,
        lineHeight = 21.sp
      )
    }
  }
}

@Composable
fun AssistantMessageBubble(
  message: ChatMessage,
  onCopy: () -> Unit,
  onShare: () -> Unit,
  onEdit: () -> Unit,
  onTap: (() -> Unit)? = null
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null
      ) { onTap?.invoke() }
      .padding(vertical = 4.dp)
  ) {
    // Render formatted assistant markdown
    RenderFormattedText(text = message.text)

    Spacer(modifier = Modifier.height(12.dp))

    // Action toolbar (copy, share, edit)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = Icons.Outlined.ContentCopy,
        contentDescription = "Copiar",
        tint = ChatGptIconMuted,
        modifier = Modifier
          .size(17.dp)
          .clickable(onClick = onCopy)
      )
      Icon(
        imageVector = Icons.Outlined.Share,
        contentDescription = "Compartir",
        tint = ChatGptIconMuted,
        modifier = Modifier
          .size(17.dp)
          .clickable(onClick = onShare)
      )
      Icon(
        imageVector = Icons.Outlined.Edit,
        contentDescription = "Editar o regenerar",
        tint = ChatGptIconMuted,
        modifier = Modifier
          .size(17.dp)
          .clickable(onClick = onEdit)
      )
    }
  }
}

@Composable
fun RenderFormattedText(text: String) {
  val lines = text.split("\n")

  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    lines.forEach { line ->
      when {
        line.startsWith("[LINK:") && line.endsWith("]") -> {
          val linkText = line.removePrefix("[LINK:").removeSuffix("]")
          Text(
            text = linkText,
            color = Color.White,
            fontSize = 14.5.sp,
            fontWeight = FontWeight.Normal,
            textDecoration = TextDecoration.Underline,
            modifier = Modifier.clickable { /* Link tapped */ }
          )
        }

        line.startsWith("1.") || line.startsWith("2.") || line.startsWith("3.") -> {
          Text(
            text = line,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            lineHeight = 21.sp
          )
        }

        line.startsWith("**") && line.endsWith("**") -> {
          val boldContent = line.removeSurrounding("**")
          Text(
            text = boldContent,
            color = Color.White,
            fontSize = 14.5.sp,
            fontWeight = FontWeight.Bold
          )
        }

        line.isNotBlank() -> {
          val annotated = buildAnnotatedString {
            var currentIndex = 0
            val pattern = Regex("\\*\\*(.*?)\\*\\*")
            val matches = pattern.findAll(line)

            for (match in matches) {
              append(line.substring(currentIndex, match.range.first))
              withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) {
                append(match.groupValues[1])
              }
              currentIndex = match.range.last + 1
            }
            if (currentIndex < line.length) {
              append(line.substring(currentIndex))
            }
          }

          Text(
            text = annotated,
            color = Color(0xFFE4E4E7),
            fontSize = 14.5.sp,
            lineHeight = 22.sp
          )
        }
      }
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Widgets agénticos: fila compacta de tool call + widget interactivo
// ask_user_input (opciones, texto libre y omitir) — espejo del agente de PC.
// ═══════════════════════════════════════════════════════════════════════════

@Composable
fun ToolActivityRow(message: ChatMessage, onTap: () -> Unit) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(10.dp))
      .background(Color(0x14FFFFFF))
      .clickable { onTap() }
      .padding(horizontal = 10.dp, vertical = 7.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = when {
        message.toolOk == false -> "✕"
        message.toolName == "respuesta" || message.toolName == "ask_user_input" -> "↩"
        else -> "⚙"
      },
      fontSize = 12.sp,
      color = if (message.toolOk == false) Color(0xFFF87171) else Color(0xFF7DD3FC)
    )
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = message.text,
      fontSize = 12.5.sp,
      color = ChatGptTextSecondary,
      maxLines = 3,
      overflow = TextOverflow.Ellipsis,
      modifier = Modifier.weight(1f)
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InteractivePromptWidget(
  message: ChatMessage,
  enabled: Boolean,
  onSubmit: (String) -> Unit,
  onTap: () -> Unit
) {
  var showCustomInput by remember { mutableStateOf(false) }
  var customText by remember { mutableStateOf("") }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(ChatGptInputBg)
      .border(1.dp, WeaverCardBorder, RoundedCornerShape(14.dp))
      .padding(14.dp)
      .clickable { onTap() }
  ) {
    // Pregunta
    Text(
      text = message.question ?: message.text,
      fontSize = 14.5.sp,
      fontWeight = FontWeight.SemiBold,
      color = Color.White
    )

    Spacer(modifier = Modifier.height(12.dp))

    if (message.answered) {
      // Estado respondido
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(Color(0xFF123A24))
          .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(text = "✓ Seleccionado: ", fontSize = 12.5.sp, color = Color(0xFF4ADE80))
        Text(
          text = message.selectedAnswer ?: "",
          fontSize = 12.5.sp,
          fontWeight = FontWeight.SemiBold,
          color = Color(0xFF4ADE80)
        )
      }
    } else {
      // Opciones
      message.options.forEach { option ->
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 7.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(WeaverChipBg)
            .border(1.dp, WeaverChipBorder, RoundedCornerShape(10.dp))
            .clickable(enabled = enabled) { onSubmit(option) }
            .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
          Text(text = option, fontSize = 13.sp, color = Color(0xFFE4E4E7))
        }
      }

      if (message.allowCustom) {
        if (!showCustomInput) {
          Text(
            text = "Algo más...",
            fontSize = 12.5.sp,
            color = ChatGptTextMuted,
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .clickable(enabled = enabled) { showCustomInput = true }
              .padding(horizontal = 4.dp, vertical = 6.dp)
          )
        } else {
          Row(verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
              value = customText,
              onValueChange = { customText = it },
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x14FFFFFF))
                .padding(horizontal = 10.dp, vertical = 8.dp),
              textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
              cursorBrush = SolidColor(Color.White),
              decorationBox = { inner ->
                if (customText.isEmpty()) {
                  Text("Escribe tu respuesta personalizada...", color = ChatGptTextMuted, fontSize = 12.5.sp)
                }
                inner()
              }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Enviar",
              fontSize = 12.5.sp,
              fontWeight = FontWeight.SemiBold,
              color = if (customText.isBlank()) ChatGptTextMuted else Color(0xFF4ADE80),
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(enabled = enabled && customText.isNotBlank()) {
                  onSubmit(customText.trim())
                }
                .padding(horizontal = 6.dp, vertical = 6.dp)
            )
          }
        }
      }

      // Omitir
      Text(
        text = "Omitir",
        fontSize = 11.5.sp,
        color = Color(0xFFFACC15),
        modifier = Modifier
          .padding(top = 6.dp)
          .clip(RoundedCornerShape(8.dp))
          .clickable(enabled = enabled) {
            onSubmit("El usuario omitió responder a esta pregunta — continúa con tu mejor criterio.")
          }
          .padding(horizontal = 4.dp, vertical = 4.dp)
      )
    }
  }
}
