package com.example.agent.tools

import com.example.agent.core.ToolDef
import com.example.agent.core.ToolOutput
import com.example.agent.core.ToolSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.UUID

/**
 * Cliente MCP sobre HTTP "streamable" (JSON-RPC 2.0).
 *
 * Soporta servidores que responden JSON plano o SSE (data: líneas).
 * Flujo por servidor: initialize → notifications/initialized → tools/list
 * (en el arranque) y tools/call (en cada ejecución).
 */
class McpHttpClient(
  val id: String,
  val name: String,
  val url: String,
  private val timeoutMs: Long = 15_000
) {

  private val client = OkHttpClient.Builder()
    .connectTimeout(timeoutMs / 2, TimeUnit.MILLISECONDS)
    .readTimeout(timeoutMs * 2, TimeUnit.MILLISECONDS)
    .build()

  private var sessionId: String? = null

  private fun rpc(method: String, params: JSONObject, isNotification: Boolean = false): JSONObject? {
    val body = JSONObject()
      .put("jsonrpc", "2.0")
      .put("method", method)
      .put("params", params)
    if (!isNotification) body.put("id", UUID.randomUUID().toString().take(8))

    val rb = Request.Builder()
      .url(url)
      .header("Accept", "application/json, text/event-stream")
      .header("Content-Type", "application/json")
      .post(body.toString().toRequestBody("application/json".toMediaType()))
    sessionId?.let { rb.header("Mcp-Session-Id", it) }

    client.newCall(rb.build()).execute().use { resp ->
      resp.header("Mcp-Session-Id")?.let { sessionId = it }
      if (!resp.isSuccessful) throw McpException("MCP $name: HTTP ${resp.code}")
      val ct = resp.header("Content-Type") ?: ""
      val raw = resp.body?.string() ?: return null
      if (isNotification) return null
      val jsonText = if (ct.contains("event-stream") || raw.contains("data:")) {
        // Extraer el primer payload JSON de las líneas data:
        raw.lineSequence().filter { it.startsWith("data:") }
          .map { it.removePrefix("data:").trim() }
          .firstOrNull { it.isNotEmpty() } ?: return null
      } else raw
      val obj = JSONObject(jsonText)
      obj.optJSONObject("error")?.let { e ->
        throw McpException("MCP $name: ${e.optString("message", "error desconocido")}")
      }
      return obj
    }
  }

  fun initialize() {
    rpc(
      "initialize",
      JSONObject()
        .put("protocolVersion", "2024-11-05")
        .put("capabilities", JSONObject())
        .put("clientInfo", JSONObject().put("name", "weaver-android").put("version", "1.0"))
    )
    rpc("notifications/initialized", JSONObject(), isNotification = true)
  }

  /** Lista las tools del servidor: [{"name","description","inputSchema"}]. */
  fun listTools(): JSONArray {
    val resp = rpc("tools/list", JSONObject()) ?: throw McpException("MCP $name: sin respuesta a tools/list")
    return resp.optJSONObject("result")?.optJSONArray("tools") ?: JSONArray()
  }

  fun callTool(toolName: String, args: JSONObject): String {
    val resp = rpc("tools/call", JSONObject().put("name", toolName).put("arguments", args))
      ?: throw McpException("MCP $name: sin respuesta a tools/call")
    val result = resp.optJSONObject("result") ?: return "{}"
    val content = result.optJSONArray("content")
    val texts = mutableListOf<String>()
    if (content != null) for (i in 0 until content.length()) {
      val c = content.optJSONObject(i) ?: continue
      when (c.optString("type")) {
        "text" -> texts.add(c.optString("text"))
        "resource" -> texts.add(c.optJSONObject("resource")?.toString() ?: "")
        else -> texts.add(c.toString())
      }
    }
    val isError = result.optBoolean("isError", false)
    val payload = JSONObject()
      .put("ok", !isError)
      .put("content", if (texts.isEmpty()) result.toString() else texts.joinToString("\n\n"))
    return payload.toString()
  }

  class McpException(message: String) : Exception(message)
}

/** Fábrica de specs MCP (una tool por cada tool del servidor). */
object McpTools {

  suspend fun discover(server: McpHttpClient): List<ToolSpec> = withContext(Dispatchers.IO) {
    try {
      server.initialize()
      val tools = server.listTools()
      val specs = mutableListOf<ToolSpec>()
      for (i in 0 until tools.length()) {
        val t = tools.optJSONObject(i) ?: continue
        val tName = t.optString("name")
        if (tName.isEmpty()) continue
        val schema = t.optJSONObject("inputSchema") ?: JSONObject().put("type", "object").put("properties", JSONObject())
        specs.add(
          ToolSpec(
            ToolDef(
              "mcp__${server.id}__$tName",
              "[MCP:${server.name}] ${t.optString("description", "Herramienta MCP $tName")}".take(300),
              schema
            ),
            group = "MCP · ${server.name}"
          ) { args, ctx ->
            if (ctx.cancelled) return@ToolSpec ToolOutput(false, "", "cancelado")
            withContext(Dispatchers.IO) {
              try {
                val out = server.callTool(tName, args)
                val json = JSONObject(out)
                ToolOutput(json.optBoolean("ok", true), json.optString("content"))
              } catch (e: Exception) {
                ToolOutput(false, "", e.message ?: "error MCP")
              }
            }
          }
        )
      }
      specs
    } catch (e: Exception) {
      // Un servidor MCP caído NO debe tumbar el agente: se informa y se sigue.
      listOf(
        ToolSpec(
          ToolDef(
            "mcp__${server.id}__status",
            "[MCP:${server.name}] Herramienta de diagnóstico — el servidor no respondió.",
            JSONObject().put("type", "object").put("properties", JSONObject())
          ),
          group = "MCP · ${server.name}"
        ) { _, _ ->
          ToolOutput(false, "", "Servidor MCP '${server.name}' no disponible: ${e.message ?: e.toString()}")
        }
      )
    }
  }
}
