package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.ChatGptBlack
import com.example.ui.theme.ChatGptInputBg
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptVoiceBlue

@Composable
fun VoiceModeSheet(
  onDismiss: () -> Unit,
  onTranscript: (text: String, sendDirectly: Boolean) -> Unit = { _, _ -> }
) {
  var isMuted by remember { mutableStateOf(false) }
  val context = androidx.compose.ui.platform.LocalContext.current

  // Permiso RECORD_AUDIO en runtime (si falta, se pide antes de escuchar).
  val micPermission = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
  ) { }
  androidx.compose.runtime.LaunchedEffect(Unit) {
    if (androidx.core.content.ContextCompat.checkSelfPermission(
        context, android.Manifest.permission.RECORD_AUDIO
      ) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
      micPermission.launch(android.Manifest.permission.RECORD_AUDIO)
    }
  }

  // STT real con el reconocedor del sistema ( SpeechRecognizer).
  val speech = remember {
    val holder = arrayOfNulls<android.speech.SpeechRecognizer>(1)
    val handler = android.os.Handler(android.os.Looper.getMainLooper())
    fun restartIfListening() {
      handler.postDelayed({
        val sr = holder[0] ?: return@postDelayed
        if (!isMuted) {
          val again = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
          }
          runCatching { sr.startListening(again) }
        }
      }, 350)
    }
    runCatching {
      android.speech.SpeechRecognizer.createSpeechRecognizer(context).apply {
        setRecognitionListener(object : android.speech.RecognitionListener {
          override fun onResults(results: android.os.Bundle?) {
            val text = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) onTranscript(text, true)
            restartIfListening()
          }
          override fun onError(error: Int) { restartIfListening() }
          override fun onReadyForSpeech(params: android.os.Bundle?) {}
          override fun onBeginningOfSpeech() {}
          override fun onRmsChanged(rmsdB: Float) {}
          override fun onBufferReceived(buffer: ByteArray?) {}
          override fun onEndOfSpeech() {}
          override fun onPartialResults(partialResults: android.os.Bundle?) {
            val partial = partialResults?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!partial.isNullOrBlank()) onTranscript(partial, false)
          }
          override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
      }.also { holder[0] = it }
    }.getOrNull()
  }

  // Escucha continua: mientras no esté silenciado, (re)lanza el reconocedor.
  LaunchedEffect(isMuted) {
    if (speech == null) return@LaunchedEffect
    if (!isMuted) {
      val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, java.util.Locale.getDefault().toLanguageTag())
      }
      speech.startListening(intent)
    } else {
      speech.stopListening()
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      runCatching { speech?.destroy() }
    }
  }

  // Pulsing orb animation
  val infiniteTransition = rememberInfiniteTransition(label = "voice_orb")
  val orbScale by infiniteTransition.animateFloat(
    initialValue = 0.92f,
    targetValue = 1.12f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "orb_scale"
  )
  val haloScale by infiniteTransition.animateFloat(
    initialValue = 1.0f,
    targetValue = 1.35f,
    animationSpec = infiniteRepeatable(
      animation = tween(1600, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "halo_scale"
  )
  val haloAlpha by infiniteTransition.animateFloat(
    initialValue = 0.4f,
    targetValue = 0.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(1600, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "halo_alpha"
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier.fillMaxSize(),
      color = ChatGptBlack
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .statusBarsPadding()
          .navigationBarsPadding()
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        // Top row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (isMuted) Color(0xFFEF4444) else ChatGptVoiceBlue)
            )
            Spacer(modifier = Modifier.size(8.dp))
            Text(
              text = if (isMuted) "Silenciado" else "Escuchando...",
              fontSize = 15.sp,
              fontWeight = FontWeight.Medium,
              color = ChatGptTextPrimary
            )
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(ChatGptInputBg)
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Cerrar voz",
              tint = ChatGptTextPrimary
            )
          }
        }

        // Animated Glowing Orb
        Box(
          modifier = Modifier
            .size(240.dp),
          contentAlignment = Alignment.Center
        ) {
          // Radiating pulse halo
          Box(
            modifier = Modifier
              .size(180.dp)
              .scale(haloScale)
              .clip(CircleShape)
              .background(
                Brush.radialGradient(
                  colors = listOf(
                    ChatGptVoiceBlue.copy(alpha = haloAlpha),
                    Color(0xFF8B5CF6).copy(alpha = haloAlpha * 0.5f),
                    Color.Transparent
                  )
                )
              )
          )

          // Glowing multi-color dynamic orb
          Box(
            modifier = Modifier
              .size(150.dp)
              .scale(if (isMuted) 0.85f else orbScale)
              .clip(CircleShape)
              .background(
                Brush.linearGradient(
                  colors = if (isMuted) {
                    listOf(Color(0xFF4B5563), Color(0xFF1F2937))
                  } else {
                    listOf(
                      Color(0xFF60A5FA),
                      Color(0xFF3B82F6),
                      Color(0xFF8B5CF6),
                      Color(0xFFEC4899)
                    )
                  }
                )
              )
          )
        }

        // Subtitle instructions
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "Modo de voz avanzado",
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = ChatGptTextPrimary
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Habla con naturalidad. Toca el micrófono para silenciar.",
            fontSize = 13.sp,
            color = ChatGptTextMuted
          )
        }

        // Bottom Controls
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Keyboard switch
          IconButton(
            onClick = onDismiss,
            modifier = Modifier
              .size(54.dp)
              .clip(CircleShape)
              .background(ChatGptInputBg)
          ) {
            Icon(
              imageVector = Icons.Default.Keyboard,
              contentDescription = "Teclado",
              tint = ChatGptTextPrimary
            )
          }

          // Mute / Unmute
          IconButton(
            onClick = { isMuted = !isMuted },
            modifier = Modifier
              .size(68.dp)
              .clip(CircleShape)
              .background(if (isMuted) Color(0xFFEF4444) else ChatGptInputBg)
          ) {
            Icon(
              imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
              contentDescription = "Micrófono",
              tint = Color.White,
              modifier = Modifier.size(28.dp)
            )
          }

          // Hang up / End
          IconButton(
            onClick = onDismiss,
            modifier = Modifier
              .size(54.dp)
              .clip(CircleShape)
              .background(Color(0xFFDC2626))
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Finalizar",
              tint = Color.White
            )
          }
        }
      }
    }
  }
}
