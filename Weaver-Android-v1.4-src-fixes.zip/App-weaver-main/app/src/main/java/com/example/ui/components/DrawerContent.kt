package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowLeft
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChatGptBorderSubtle
import com.example.ui.theme.ChatGptDrawerBg
import com.example.ui.theme.ChatGptIconColor
import com.example.ui.theme.ChatGptIconMuted
import com.example.ui.theme.ChatGptPillSelected
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptTextSecondary

data class DrawerItem(
  val title: String,
  val icon: ImageVector,
  val badge: String? = null,
  val trailingIcon: ImageVector? = null,
  val trailingText: String? = null
)

val workspaceNavItems = listOf(
  DrawerItem("ME", Icons.Outlined.DateRange),
  DrawerItem("Complementos", Icons.Outlined.Extension),
  DrawerItem("Schedules", Icons.Outlined.Schedule),
  DrawerItem("Workflows", Icons.Outlined.Bolt),
  DrawerItem("Notebooks", Icons.Outlined.AutoStories),
  DrawerItem("Subagentes", Icons.Outlined.SmartToy),
  DrawerItem("Memoria", Icons.Outlined.Psychology),
  DrawerItem("Métricas", Icons.Outlined.BarChart),
  DrawerItem("RLM Agent", Icons.Outlined.Tune)
)

data class ProjectItem(
  val name: String,
  val count: Int = 0
)

val projectItems = listOf(
  ProjectItem("Mdhf", 0),
  ProjectItem("Gf", 0),
  ProjectItem("Juijhh", 0),
  ProjectItem("Jj", 0)
)

data class RecentChat(
  val id: String,
  val title: String,
  val isPinned: Boolean = false
)

enum class AppSection {
  CHAT,
  COMPLEMENTOS,
  SCHEDULES,
  NOTEBOOKS,
  SETTINGS
}

@Composable
fun DrawerContent(
  recentChats: List<RecentChat>,
  selectedChatId: String,
  currentSection: AppSection = AppSection.CHAT,
  onSectionSelected: (AppSection) -> Unit = {},
  onChatSelected: (RecentChat) -> Unit,
  onNewChat: () -> Unit,
  onSearchClick: () -> Unit,
  onCloseDrawer: () -> Unit,
  onSettingsClick: () -> Unit = {},
  onResetOnboarding: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxHeight()
      .width(300.dp)
      .background(ChatGptDrawerBg)
      .statusBarsPadding()
      .navigationBarsPadding()
      .padding(horizontal = 12.dp, vertical = 6.dp)
  ) {
    // Top Row: Weaver Logo + "weaver" text and collapse Chevron (<)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 6.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.clickable { onCloseDrawer() }
      ) {
        WeaverLogo(size = 20.dp, color = Color.White)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "weaver",
          fontSize = 17.sp,
          fontWeight = FontWeight.SemiBold,
          color = Color.White
        )
      }

      IconButton(
        onClick = onCloseDrawer,
        modifier = Modifier.size(32.dp)
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Outlined.KeyboardArrowLeft,
          contentDescription = "Cerrar menú",
          tint = ChatGptTextMuted,
          modifier = Modifier.size(20.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Scrollable navigation list
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
    ) {
      // 1. + Nuevo chat
      item {
        val isNewChatActive = currentSection == AppSection.CHAT && selectedChatId == "new_chat"
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isNewChatActive) ChatGptPillSelected else Color.Transparent)
            .clickable {
              onSectionSelected(AppSection.CHAT)
              onNewChat()
              onCloseDrawer()
            }
            .padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = null,
            tint = if (isNewChatActive) Color.White else ChatGptIconColor,
            modifier = Modifier.size(17.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Nuevo chat",
            fontSize = 13.5.sp,
            fontWeight = if (isNewChatActive) FontWeight.SemiBold else FontWeight.Normal,
            color = if (isNewChatActive) Color.White else ChatGptTextPrimary
          )
        }
      }

      // 2. Buscar
      item {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onSearchClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = null,
            tint = ChatGptIconColor,
            modifier = Modifier.size(17.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Buscar",
            fontSize = 13.5.sp,
            color = ChatGptTextPrimary
          )
        }
        Spacer(modifier = Modifier.height(14.dp))
      }

      // SECTION: WORKSPACE
      item {
        Text(
          text = "WORKSPACE",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = ChatGptTextMuted,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
          letterSpacing = 0.5.sp
        )
      }

      items(workspaceNavItems) { item ->
        val isItemActive = when (item.title) {
          "Complementos" -> currentSection == AppSection.COMPLEMENTOS
          "Schedules" -> currentSection == AppSection.SCHEDULES
          "Notebooks" -> currentSection == AppSection.NOTEBOOKS
          else -> false
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isItemActive) ChatGptPillSelected else Color.Transparent)
            .clickable {
              when (item.title) {
                "Complementos" -> onSectionSelected(AppSection.COMPLEMENTOS)
                "Schedules" -> onSectionSelected(AppSection.SCHEDULES)
                "Notebooks" -> onSectionSelected(AppSection.NOTEBOOKS)
                else -> { /* other workspace actions */ }
              }
              onCloseDrawer()
            }
            .padding(horizontal = 10.dp, vertical = 7.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = item.icon,
            contentDescription = null,
            tint = if (isItemActive) Color.White else ChatGptIconMuted,
            modifier = Modifier.size(17.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = item.title,
            fontSize = 13.sp,
            fontWeight = if (isItemActive) FontWeight.SemiBold else FontWeight.Normal,
            color = if (isItemActive) Color.White else ChatGptTextPrimary
          )
        }
      }

      // SECTION: PROYECTOS
      item {
        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "PROYECTOS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = ChatGptTextMuted,
            letterSpacing = 0.5.sp
          )
          Icon(
            imageVector = Icons.Outlined.CreateNewFolder,
            contentDescription = "Nuevo proyecto",
            tint = ChatGptTextMuted,
            modifier = Modifier.size(15.dp)
          )
        }
      }

      items(projectItems) { project ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { /* open project */ }
            .padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Outlined.Folder,
            contentDescription = null,
            tint = ChatGptIconMuted,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = project.name,
            fontSize = 13.sp,
            color = ChatGptTextPrimary,
            modifier = Modifier.weight(1f)
          )
          Text(
            text = project.count.toString(),
            fontSize = 12.sp,
            color = ChatGptTextMuted
          )
        }
      }

      // SECTION: CHATS
      item {
        Spacer(modifier = Modifier.height(14.dp))
        Text(
          text = "CHATS",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = ChatGptTextMuted,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
          letterSpacing = 0.5.sp
        )
      }

      items(recentChats) { chat ->
        val isSelected = currentSection == AppSection.CHAT && chat.id == selectedChatId
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) ChatGptPillSelected else Color.Transparent)
            .clickable {
              onSectionSelected(AppSection.CHAT)
              onChatSelected(chat)
              onCloseDrawer()
            }
            .padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Outlined.Chat,
            contentDescription = null,
            tint = if (isSelected) Color.White else ChatGptIconMuted,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = chat.title,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Medium else FontWeight.Normal,
            color = if (isSelected) Color.White else ChatGptTextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }

      item {
        Spacer(modifier = Modifier.height(16.dp))
      }
    }

    // Bottom Sticky: Configuración & Repetir bienvenida
    HorizontalDivider(
      thickness = 1.dp,
      color = ChatGptBorderSubtle,
      modifier = Modifier.padding(vertical = 4.dp)
    )

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(8.dp))
        .clickable {
          onResetOnboarding()
          onCloseDrawer()
        }
        .padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = Icons.Outlined.AutoAwesome,
        contentDescription = null,
        tint = ChatGptTextSecondary,
        modifier = Modifier.size(17.dp)
      )
      Spacer(modifier = Modifier.width(12.dp))
      Text(
        text = "Bienvenida / Onboarding",
        fontSize = 13.sp,
        color = ChatGptTextSecondary
      )
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(8.dp))
        .clickable {
          onSettingsClick()
          onCloseDrawer()
        }
        .padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = Icons.Outlined.Settings,
        contentDescription = "Configuración",
        tint = ChatGptIconMuted,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(12.dp))
      Text(
        text = "Configuración",
        fontSize = 13.5.sp,
        color = ChatGptTextPrimary
      )
    }
  }
}
