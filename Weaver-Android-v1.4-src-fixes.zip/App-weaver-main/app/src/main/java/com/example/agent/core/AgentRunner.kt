package com.example.agent.core

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive

/**
 * Bucle agéntico ReAct — espejo Kotlin del runSession() del PC:
 *  - Reconstruye los mensajes desde SessionState en cada round (nunca acumula
 *    texto a ciegas), insertando el historial de la conversación entre el
 *    system prompt y el "Objetivo:" (FIX anti-amnesia: en la reanudación tras
 *    ask_user_input el modelo SÍ ve la pregunta original y la respuesta).
 *  - pauseOnTools: ask_user_input pausa la sesión en vez de ejecutarse.
 *  - Protocolo RESULT:/STUCK:, detección de bloqueo por repetición,
 *    límite externo de rounds y modo "perseguir" con reintentos.
 */
class AgentRunner(
  private val llm: LlmApi,
  private val model: String,
  private val registry: ToolRegistry,
  private val systemPrompt: String,
  private val onEvent: suspend (AgentEvent) -> Unit,
  private val signal: java.util.concurrent.atomic.AtomicBoolean? = null,
  private val pauseOnTools: Set<String> = setOf("ask_user_input"),
  private val maxRounds: Int = 24,
  private val pursueMaxAttempts: Int = 3,
  private val blockedAfterConsecutiveRounds: Int = 3
) {

  data class Result(
    val status: String, // succeeded | stuck | cancelled | failed | awaiting_user_input
    val summary: String,
    val state: SessionState
  )

  suspend fun run(
    state: SessionState,
    history: List<LMessage> = emptyList()
  ): Result {
    var round = 0
    var consecutiveNoProgress = 0
    var lastFingerprint: String? = null
    var pursueAttempt = 1

    fun finish(status: String, summary: String): Result {
      state.outcome = summary
      return Result(status, summary, state)
    }

    while (true) {
      if (signal?.get() == true) return finish("cancelled", "Cancelado por el usuario.")
      if (round >= maxRounds) return finish("failed", "Se alcanzó el límite de $maxRounds rounds sin RESULT ni STUCK.")
      round++

      val messages = buildMessages(state, systemPrompt, history)
      val result = try {
        llm.chat(model, messages, registry.defs(),
          onTextDelta = { onEvent(AgentEvent.TextDelta(it)) },
          onReasoningDelta = { onEvent(AgentEvent.ReasoningDelta(it)) })
      } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
      } catch (e: Exception) {
        return finish("failed", e.message ?: "Error de red desconocido")
      }

      if (result.toolCalls.isEmpty()) {
        val text = result.text.trim()
        val record = RoundRecord(round, assistantText = text)
        state.rounds.add(record)
        onEvent(AgentEvent.RoundFinished(round))

        when {
          text.startsWith("RESULT:") -> {
            onEvent(AgentEvent.Finished("succeeded", text.removePrefix("RESULT:").trim()))
            return finish("succeeded", text.removePrefix("RESULT:").trim())
          }
          text.startsWith("STUCK:") -> {
            val reason = text.removePrefix("STUCK:").trim()
            if (pursueAttempt < pursueMaxAttempts) {
              pursueAttempt++
              consecutiveNoProgress = 0
              lastFingerprint = null
              state.rounds.add(
                RoundRecord(
                  round, "(PERSEGUIR OBJETIVO: intento bloqueado — \"$reason\". Re-planificando, intento $pursueAttempt/$pursueMaxAttempts.)"
                )
              )
              continue
            }
            onEvent(AgentEvent.Finished("stuck", reason))
            return finish("stuck", reason)
          }
          else -> {
            // Texto plano sin marcador = cierre natural del turno (como en PC).
            if (text.isEmpty()) {
              consecutiveNoProgress++
            } else if (lastFingerprint == "text:$text") {
              consecutiveNoProgress++
            } else {
              lastFingerprint = "text:$text"
              onEvent(AgentEvent.Finished("succeeded", text))
              return finish("succeeded", text)
            }
          }
        }
      } else {
        // Tool de pausa (ej. ask_user_input): termina la sesión sin ejecutar.
        val pauseCall = result.toolCalls.firstOrNull { it.name in pauseOnTools }
        if (pauseCall != null) {
          val args = pauseCall.parsedArgs()
          state.rounds.add(
            RoundRecord(
              round,
              assistantText = result.text.ifBlank { null },
              toolCalls = listOf(ExecutedCall(pauseCall, args, ToolOutput(true, "(esperando respuesta del usuario)")))
            )
          )
          onEvent(AgentEvent.AwaitingUserInput(pauseCall, args))
          return finish("awaiting_user_input", "Esperando respuesta del usuario (${pauseCall.name}).")
        }

        // Ejecutar tool calls (una por una; Android no necesita paralelismo masivo).
        val executed = mutableListOf<ExecutedCall>()
        for (call in result.toolCalls) {
          if (signal?.get() == true) return finish("cancelled", "Cancelado por el usuario.")
          onEvent(AgentEvent.ToolCallStarted(round, call))
          val args = call.parsedArgs()
          val spec = registry.get(call.name)
          val out: ToolOutput = when {
            spec == null -> ToolOutput(false, "", "Tool desconocida: ${call.name}")
            else -> try {
              spec.handler.invoke(args, ToolContext(state.sessionId, round, signal))
            } catch (e: kotlinx.coroutines.CancellationException) {
              throw e
            } catch (e: Exception) {
              ToolOutput(false, "", e.message ?: e.toString())
            }
          }
          val truncated = if (out.output.length > 4000) out.output.substring(0, 4000) + "…" else out.output
          val finalOut = if (out.ok) out.copy(output = truncated) else out
          executed.add(ExecutedCall(call, args, finalOut))
          onEvent(AgentEvent.ToolCallFinished(round, call, finalOut))
        }

        state.rounds.add(RoundRecord(round, result.text.ifBlank { null }, toolCalls = executed))

        // Detección de bloqueo: mismo fingerprint de (tool, args) que el round anterior.
        val fingerprint = executed.joinToString("|") { "${it.call.name}:${it.call.arguments}" }
        if (fingerprint == lastFingerprint) consecutiveNoProgress++ else consecutiveNoProgress = 0
        lastFingerprint = fingerprint
      }

      if (consecutiveNoProgress >= blockedAfterConsecutiveRounds) {
        val msg = "Bloqueo detectado: $consecutiveNoProgress rounds consecutivos sin progreso."
        onEvent(AgentEvent.Finished("stuck", msg))
        return finish("stuck", msg)
      }
    }
  }

  /**
   * Reconstrucción del prompt: system → historial de la conversación →
   * "Objetivo: <goal>" → rounds ejecutados (assistant+tool_calls → tool results).
   */
  fun buildMessages(state: SessionState, systemPrompt: String, history: List<LMessage>): List<LMessage> {
    val messages = mutableListOf<LMessage>()
    messages += LMessage.system(systemPrompt)
    history.forEach { h ->
      if (h.role == ROLE_USER || h.role == ROLE_ASSISTANT || h.role == ROLE_TOOL) messages += h
    }
    messages += LMessage.user("Objetivo: ${state.goal}")
    for (r in state.rounds) {
      if (r.toolCalls.isNotEmpty()) {
        messages += LMessage.assistant(r.assistantText, r.toolCalls.map { it.call })
        for (tc in r.toolCalls) {
          messages += LMessage.tool(
            tc.call.id,
            if (tc.result.ok) tc.result.output else "ERROR: ${tc.result.error ?: "desconocido"}"
          )
        }
      } else if (r.assistantText != null) {
        messages += LMessage.assistant(r.assistantText)
      }
    }
    return messages
  }
}
