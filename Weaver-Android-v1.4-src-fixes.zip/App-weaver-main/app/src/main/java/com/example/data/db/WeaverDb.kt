package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [
    ConversationEntity::class,
    MessageEntity::class,
    FactEntity::class,
    MeItemEntity::class
  ],
  version = 1,
  exportSchema = false
)
abstract class WeaverDb : RoomDatabase() {
  abstract fun conversations(): ConversationDao
  abstract fun messages(): MessageDao
  abstract fun facts(): FactDao
  abstract fun meItems(): MeDao

  companion object {
    @Volatile private var instance: WeaverDb? = null

    fun get(context: Context): WeaverDb =
      instance ?: synchronized(this) {
        instance ?: Room.databaseBuilder(
          context.applicationContext,
          WeaverDb::class.java,
          "weaver.db"
        ).fallbackToDestructiveMigration().build().also { instance = it }
      }
  }
}
