package com.example.ui.chat

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForwardIos
import androidx.compose.material.icons.automirrored.outlined.HelpOutline
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.Adjust
import androidx.compose.material.icons.outlined.AltRoute
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.DesktopWindows
import androidx.compose.material.icons.outlined.DeviceHub
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChatGptBorderSubtle
import com.example.ui.theme.ChatGptDrawerBg
import com.example.ui.theme.ChatGptIconColor
import com.example.ui.theme.ChatGptIconMuted
import com.example.ui.theme.ChatGptInputBg
import com.example.ui.theme.ChatGptPillSelected
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptTextSecondary
import kotlin.math.roundToInt

enum class WeaverExecutionMode(val displayName: String, val description: String) {
  PLAN("Modo plan", "Proponer plan y esperar confirmación"),
  PURSUIT("Perseguir objetivo", "Iterar hasta completar (3 intentos)"),
  COGNITIVE("Modo cognitivo", "Hiper-especializado · grafo del proyecto"),
  CHAT_MEMORY("Memoria chat", "Recuerda nombre, gustos y contexto"),
  PROJECT_MEMORY("Memoria de proyecto", "Bitácora de este chat: qué se hizo, qué falta"),
  RLM("Modo RLM", "Contexto como variable · subagentes recursivos")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeaverAddMenuSheet(
  activeMode: WeaverExecutionMode?,
  onModeChanged: (WeaverExecutionMode?) -> Unit,
  onAddFiles: () -> Unit,
  onUploadFolder: () -> Unit,
  onAddFromUrl: () -> Unit,
  onAttachApp: () -> Unit,
  onOpenComplementos: () -> Unit,
  onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var isModesExpanded by remember { mutableStateOf(false) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = Color(0xFF131315),
    contentColor = ChatGptTextPrimary,
    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
    dragHandle = {
      Box(
        modifier = Modifier
          .padding(top = 10.dp, bottom = 6.dp)
          .width(36.dp)
          .height(4.dp)
          .clip(CircleShape)
          .background(Color(0xFF3F3F46))
      )
    }
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 18.dp)
        .navigationBarsPadding()
        .padding(bottom = 24.dp)
    ) {
      // -------------------------------------------------------------
      // SECCIÓN: AÑADIR (Left column in user screenshot)
      // -------------------------------------------------------------
      Text(
        text = "AÑADIR",
        fontSize = 11.5.sp,
        fontWeight = FontWeight.SemiBold,
        color = ChatGptTextMuted,
        letterSpacing = 0.6.sp,
        modifier = Modifier.padding(start = 4.dp, bottom = 6.dp, top = 4.dp)
      )

      // 1. Agregar fotos y archivos
      AddMenuItemRow(
        title = "Agregar fotos y archivos",
        subtitle = "Texto, imagen o binario",
        icon = {
          Icon(
            imageVector = Icons.Outlined.AttachFile,
            contentDescription = null,
            tint = Color(0xFFE4E4E7),
            modifier = Modifier.size(19.dp)
          )
        },
        onClick = {
          onAddFiles()
          onDismiss()
        }
      )

      // 2. Subir carpeta
      AddMenuItemRow(
        title = "Subir carpeta",
        subtitle = "Todos los archivos recursivamente",
        icon = {
          Icon(
            imageVector = Icons.Outlined.Folder,
            contentDescription = null,
            tint = Color(0xFFE4E4E7),
            modifier = Modifier.size(19.dp)
          )
        },
        onClick = {
          onUploadFolder()
          onDismiss()
        }
      )

      // 3. Añadir desde URL
      AddMenuItemRow(
        title = "Añadir desde URL",
        subtitle = "Descarga y adjunta",
        icon = {
          Icon(
            imageVector = Icons.Outlined.Link,
            contentDescription = null,
            tint = Color(0xFFE4E4E7),
            modifier = Modifier.size(19.dp)
          )
        },
        onClick = {
          onAddFromUrl()
          onDismiss()
        }
      )

      // 4. Adjuntar app
      AddMenuItemRow(
        title = "Adjuntar app",
        subtitle = "Requiere Tauri",
        icon = {
          Icon(
            imageVector = Icons.Outlined.DesktopWindows,
            contentDescription = null,
            tint = Color(0xFFE4E4E7),
            modifier = Modifier.size(19.dp)
          )
        },
        onClick = {
          onAttachApp()
          onDismiss()
        }
      )

      // 5. Complementos
      AddMenuItemRow(
        title = "Complementos",
        subtitle = "Skills y servidores MCP",
        icon = {
          Icon(
            imageVector = Icons.Outlined.Extension,
            contentDescription = null,
            tint = Color(0xFFE4E4E7),
            modifier = Modifier.size(19.dp)
          )
        },
        trailing = {
          Icon(
            imageVector = Icons.AutoMirrored.Outlined.ArrowForwardIos,
            contentDescription = null,
            tint = ChatGptTextMuted,
            modifier = Modifier.size(13.dp)
          )
        },
        onClick = {
          onOpenComplementos()
          onDismiss()
        }
      )

      Spacer(modifier = Modifier.height(10.dp))
      HorizontalDivider(color = Color(0x1AFFFFFF), thickness = 1.dp)
      Spacer(modifier = Modifier.height(10.dp))

      // -------------------------------------------------------------
      // ELEMENTO EXPANDIBLE: "MODOS"
      // User: "un solo que este que diga modos y al presionarlo se desplaza y se muestras los modos"
      // -------------------------------------------------------------
      val chevronRotation by animateFloatAsState(
        targetValue = if (isModesExpanded) 180f else 0f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
        label = "ModesChevronRotation"
      )

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(if (isModesExpanded) Color(0xFF1B1B1E) else Color(0xFF161619))
          .border(
            1.dp,
            if (isModesExpanded) Color(0x33FFFFFF) else Color(0x14FFFFFF),
            RoundedCornerShape(12.dp)
          )
          .clickable { isModesExpanded = !isModesExpanded }
          .padding(horizontal = 14.dp, vertical = 12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color(0xFF27272A)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Outlined.Tune,
                contentDescription = null,
                tint = if (activeMode != null) Color.White else Color(0xFFA1A1AA),
                modifier = Modifier.size(18.dp)
              )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "Modos",
                  fontSize = 14.5.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = Color.White
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (activeMode != null) Color(0xFF3B82F6).copy(alpha = 0.2f) else Color(0xFF27272A))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = activeMode?.displayName ?: "Solo uno activo",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (activeMode != null) Color(0xFF60A5FA) else Color(0xFFA1A1AA)
                  )
                }
              }
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = if (isModesExpanded) "Toca para plegar" else "Toca para desplegar los modos de ejecución",
                fontSize = 11.5.sp,
                color = ChatGptTextMuted
              )
            }
          }

          Icon(
            imageVector = Icons.Default.KeyboardArrowDown,
            contentDescription = null,
            tint = Color(0xFFA1A1AA),
            modifier = Modifier
              .size(20.dp)
              .rotate(chevronRotation)
          )
        }
      }

      // Animación al presionar: se desplaza suavemente mostrando los modos
      AnimatedVisibility(
        visible = isModesExpanded,
        enter = expandVertically(
          animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)
        ) + fadeIn(),
        exit = shrinkVertically(
          animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)
        ) + fadeOut()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF141416))
            .border(1.dp, Color(0x1FFFFFFF), RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
          // Header matching screenshot: MODOS · SOLO UNO ACTIVO
          Text(
            text = "MODOS · SOLO UNO ACTIVO",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFA1A1AA),
            letterSpacing = 0.7.sp,
            modifier = Modifier.padding(bottom = 8.dp, start = 2.dp)
          )

          // 1. Modo plan
          ModeItemRow(
            mode = WeaverExecutionMode.PLAN,
            isActive = activeMode == WeaverExecutionMode.PLAN,
            onToggle = {
              onModeChanged(if (activeMode == WeaverExecutionMode.PLAN) null else WeaverExecutionMode.PLAN)
            },
            icon = {
              Icon(
                imageVector = Icons.Outlined.AltRoute,
                contentDescription = null,
                tint = if (activeMode == WeaverExecutionMode.PLAN) Color.White else Color(0xFFA1A1AA),
                modifier = Modifier.size(19.dp)
              )
            }
          )

          // 2. Perseguir objetivo
          ModeItemRow(
            mode = WeaverExecutionMode.PURSUIT,
            isActive = activeMode == WeaverExecutionMode.PURSUIT,
            onToggle = {
              onModeChanged(if (activeMode == WeaverExecutionMode.PURSUIT) null else WeaverExecutionMode.PURSUIT)
            },
            icon = { TargetSvgIcon(isActive = activeMode == WeaverExecutionMode.PURSUIT) }
          )

          // 3. Modo cognitivo
          ModeItemRow(
            mode = WeaverExecutionMode.COGNITIVE,
            isActive = activeMode == WeaverExecutionMode.COGNITIVE,
            onToggle = {
              onModeChanged(if (activeMode == WeaverExecutionMode.COGNITIVE) null else WeaverExecutionMode.COGNITIVE)
            },
            icon = {
              Icon(
                imageVector = Icons.Outlined.AccountTree,
                contentDescription = null,
                tint = if (activeMode == WeaverExecutionMode.COGNITIVE) Color.White else Color(0xFFA1A1AA),
                modifier = Modifier.size(19.dp)
              )
            }
          )

          // 4. Memoria chat
          ModeItemRow(
            mode = WeaverExecutionMode.CHAT_MEMORY,
            isActive = activeMode == WeaverExecutionMode.CHAT_MEMORY,
            onToggle = {
              onModeChanged(if (activeMode == WeaverExecutionMode.CHAT_MEMORY) null else WeaverExecutionMode.CHAT_MEMORY)
            },
            icon = {
              Icon(
                imageVector = Icons.Outlined.BookmarkBorder,
                contentDescription = null,
                tint = if (activeMode == WeaverExecutionMode.CHAT_MEMORY) Color.White else Color(0xFFA1A1AA),
                modifier = Modifier.size(19.dp)
              )
            }
          )

          // 5. Memoria de proyecto
          ModeItemRow(
            mode = WeaverExecutionMode.PROJECT_MEMORY,
            isActive = activeMode == WeaverExecutionMode.PROJECT_MEMORY,
            onToggle = {
              onModeChanged(if (activeMode == WeaverExecutionMode.PROJECT_MEMORY) null else WeaverExecutionMode.PROJECT_MEMORY)
            },
            icon = {
              Icon(
                imageVector = Icons.Outlined.Code,
                contentDescription = null,
                tint = if (activeMode == WeaverExecutionMode.PROJECT_MEMORY) Color.White else Color(0xFFA1A1AA),
                modifier = Modifier.size(19.dp)
              )
            }
          )

          // 6. Modo RLM
          ModeItemRow(
            mode = WeaverExecutionMode.RLM,
            isActive = activeMode == WeaverExecutionMode.RLM,
            onToggle = {
              onModeChanged(if (activeMode == WeaverExecutionMode.RLM) null else WeaverExecutionMode.RLM)
            },
            icon = {
              Icon(
                imageVector = Icons.Outlined.DeviceHub,
                contentDescription = null,
                tint = if (activeMode == WeaverExecutionMode.RLM) Color.White else Color(0xFFA1A1AA),
                modifier = Modifier.size(19.dp)
              )
            }
          )
        }
      }
    }
  }
}

@Composable
private fun AddMenuItemRow(
  title: String,
  subtitle: String,
  icon: @Composable () -> Unit,
  trailing: (@Composable () -> Unit)? = null,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(10.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 8.dp, vertical = 9.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      modifier = Modifier
        .size(34.dp)
        .clip(RoundedCornerShape(8.dp))
        .background(Color(0xFF1E1E22)),
      contentAlignment = Alignment.Center
    ) {
      icon()
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        color = Color.White
      )
      Spacer(modifier = Modifier.height(1.dp))
      Text(
        text = subtitle,
        fontSize = 11.5.sp,
        color = ChatGptTextSecondary
      )
    }

    if (trailing != null) {
      trailing()
    }
  }
}

@Composable
private fun ModeItemRow(
  mode: WeaverExecutionMode,
  isActive: Boolean,
  onToggle: () -> Unit,
  icon: @Composable () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .clickable(onClick = onToggle)
      .padding(horizontal = 6.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(30.dp)
          .clip(CircleShape)
          .background(if (isActive) Color(0xFF27272A) else Color(0xFF1C1C20)),
        contentAlignment = Alignment.Center
      ) {
        icon()
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column {
        Text(
          text = mode.displayName,
          fontSize = 13.5.sp,
          fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Medium,
          color = if (isActive) Color.White else Color(0xFFE4E4E7)
        )
        Spacer(modifier = Modifier.height(1.dp))
        Text(
          text = mode.description,
          fontSize = 11.sp,
          color = Color(0xFFA1A1AA),
          lineHeight = 15.sp,
          maxLines = 1
        )
      }
    }

    Spacer(modifier = Modifier.width(8.dp))

    // Modern OpenAI style Switch (off: dark track with white thumb; on: white track with dark thumb)
    WeaverSwitch(
      checked = isActive,
      onCheckedChange = { onToggle() }
    )
  }
}

/**
 * Custom Switch matching the exact screenshot design:
 * Inactive: dark track (#27272A) with white circular thumb
 * Active: bright white track (#FFFFFF) with dark circular thumb (#18181B)
 */
@Composable
fun WeaverSwitch(
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  val animatedPosition by animateFloatAsState(
    targetValue = if (checked) 1f else 0f,
    animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
    label = "SwitchThumbPosition"
  )

  val trackWidth = 38.dp
  val trackHeight = 22.dp
  val thumbSize = 16.dp
  val thumbPadding = 3.dp

  val trackColor = if (checked) Color.White else Color(0xFF27272A)
  val thumbColor = if (checked) Color(0xFF18181B) else Color.White

  Box(
    modifier = modifier
      .size(width = trackWidth, height = trackHeight)
      .clip(CircleShape)
      .background(trackColor)
      .border(1.dp, if (checked) Color.White else Color(0x2EFFFFFF), CircleShape)
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = { onCheckedChange(!checked) }
      )
      .padding(thumbPadding),
    contentAlignment = Alignment.CenterStart
  ) {
    val travelDistance = (trackWidth - (thumbPadding * 2) - thumbSize)

    Box(
      modifier = Modifier
        .offset {
          IntOffset(
            x = (animatedPosition * travelDistance.toPx()).roundToInt(),
            y = 0
          )
        }
        .size(thumbSize)
        .shadow(2.dp, CircleShape)
        .clip(CircleShape)
        .background(thumbColor)
    )
  }
}

/**
 * Pure SVG Canvas Target icon for "Perseguir objetivo"
 * Concentric circles + center dot vector
 */
@Composable
fun TargetSvgIcon(isActive: Boolean) {
  val tint = if (isActive) Color.White else Color(0xFFA1A1AA)

  Canvas(modifier = Modifier.size(18.dp)) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val strokeWidth = 1.6.dp.toPx()

    // Outer circle
    drawCircle(
      color = tint,
      radius = size.width * 0.44f,
      center = center,
      style = Stroke(width = strokeWidth)
    )

    // Inner circle
    drawCircle(
      color = tint,
      radius = size.width * 0.22f,
      center = center,
      style = Stroke(width = strokeWidth)
    )

    // Center dot
    drawCircle(
      color = tint,
      radius = size.width * 0.08f,
      center = center
    )
  }
}
