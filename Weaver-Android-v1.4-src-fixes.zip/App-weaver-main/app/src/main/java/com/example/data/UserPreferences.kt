package com.example.data

import android.content.Context
import android.content.SharedPreferences

class UserPreferences(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("weaver_user_preferences", Context.MODE_PRIVATE)

  var isOnboardingCompleted: Boolean
    get() = prefs.getBoolean(KEY_ONBOARDING_COMPLETED, false)
    set(value) = prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETED, value).apply()

  var agentCallingName: String
    get() = prefs.getString(KEY_AGENT_CALLING_NAME, "") ?: ""
    set(value) = prefs.edit().putString(KEY_AGENT_CALLING_NAME, value).apply()

  var preferredLanguage: String
    get() = prefs.getString(KEY_PREFERRED_LANGUAGE, "Español") ?: "Español"
    set(value) = prefs.edit().putString(KEY_PREFERRED_LANGUAGE, value).apply()

  fun resetOnboarding() {
    prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETED, false).apply()
  }

  companion object {
    private const val KEY_ONBOARDING_COMPLETED = "key_onboarding_completed"
    private const val KEY_AGENT_CALLING_NAME = "key_agent_calling_name"
    private const val KEY_PREFERRED_LANGUAGE = "key_preferred_language"
  }
}
