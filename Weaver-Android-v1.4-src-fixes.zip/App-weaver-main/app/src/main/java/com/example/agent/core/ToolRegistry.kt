package com.example.agent.core

/**
 * Registro de herramientas — fuente única de verdad para tools + prompt.
 * El system prompt SIEMPRE se deriva de este registro, así que añadir,
 * quitar o editar tools mantiene el prompt sincronizado automáticamente.
 */
class ToolRegistry {

  private val specs = LinkedHashMap<String, ToolSpec>()

  fun register(spec: ToolSpec): ToolRegistry {
    specs[spec.def.name] = spec
    return this
  }

  fun registerAll(list: List<ToolSpec>): ToolRegistry {
    list.forEach { register(it) }
    return this
  }

  fun get(name: String): ToolSpec? = specs[name]

  fun list(): List<ToolSpec> = specs.values.toList()

  fun defs(): List<ToolDef> = specs.values.map { it.def }

  fun byGroup(): Map<String, List<ToolSpec>> =
    specs.values.groupBy { it.group }

  /** Construye el bloque de tools agrupado por categoría para el system prompt. */
  fun promptSection(): String =
    byGroup().entries.joinToString("\n\n") { (group, list) ->
      "## $group\n" + list.joinToString("\n") { s ->
        val flag = if (s.destructive) " [requiere confirmación]" else ""
        "- ${s.def.name}$flag: ${s.def.description}"
      }
    }
}
