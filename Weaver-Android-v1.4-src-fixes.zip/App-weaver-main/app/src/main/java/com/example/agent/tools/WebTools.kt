package com.example.agent.tools

import com.example.agent.core.ToolDef
import com.example.agent.core.ToolOutput
import com.example.agent.core.ToolSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Tools de red: fetch de URLs y búsqueda web (best-effort vía DuckDuckGo HTML,
 * sin API key). Para servidores de búsqueda robustos, mejor un MCP.
 */
object WebTools {

  private val client = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(30, TimeUnit.SECONDS)
    .followRedirects(true)
    .build()

  private val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Mobile Safari/537.36 WeaverAgent/1.0"

  fun httpGet(url: String, maxChars: Int = 8000): JSONObject {
    val req = Request.Builder().url(url).header("User-Agent", UA).build()
    client.newCall(req).execute().use { resp ->
      val body = resp.body?.string() ?: ""
      val ct = resp.header("Content-Type") ?: ""
      val text = if (ct.contains("html")) htmlToText(body) else body
      return JSONObject()
        .put("ok", resp.isSuccessful)
        .put("status", resp.code)
        .put("url", resp.request.url.toString())
        .put("content", text.take(maxChars))
    }
  }

  fun search(query: String, maxResults: Int = 6): JSONObject {
    val enc = java.net.URLEncoder.encode(query, "UTF-8")
    val req = Request.Builder()
      .url("https://html.duckduckgo.com/html/?q=$enc")
      .header("User-Agent", UA)
      .build()
    client.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful) {
        return JSONObject().put("ok", false).put("error", "Búsqueda HTTP ${resp.code}")
      }
      val html = resp.body?.string() ?: ""
      val results = JSONArray()
      // Resultados del HTML de DDG: <a class="result__a" href="...">
      val regex = Regex("<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL)
      val snippetRegex = Regex("class=\"result__snippet\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL)
      val snippets = snippetRegex.findAll(html).map { clean(it.groupValues[1]) }.toList()
      for ((i, m) in regex.findAll(html).withIndex()) {
        if (i >= maxResults) break
        var href = m.groupValues[1]
        // DDG envuelve las URLs: //duckduckgo.com/l/?uddg=<urlencoded>
        val uddg = Regex("uddg=([^&]+)").find(href)?.groupValues?.get(1)
        if (uddg != null) href = java.net.URLDecoder.decode(uddg, "UTF-8")
        if (href.startsWith("//")) href = "https:$href"
        results.put(
          JSONObject()
            .put("title", clean(m.groupValues[2]))
            .put("url", href)
            .put("snippet", snippets.getOrNull(i) ?: "")
        )
      }
      if (results.length() == 0) {
        return JSONObject().put("ok", false).put("error", "Sin resultados (posible bloqueo de DDG; prueba web_fetch directo o un MCP de búsqueda)")
      }
      return JSONObject().put("ok", true).put("results", results)
    }
  }

  fun specs(): List<ToolSpec> = listOf(
    ToolSpec(
      ToolDef(
        "web_fetch",
        "Descarga una URL y devuelve su contenido como texto (HTML convertido a texto plano).",
        Schema.obj("url" to "string", "max_chars" to "number", required = listOf("url"))
      ),
      group = "Web"
    ) { args, ctx ->
      if (ctx.cancelled) return@ToolSpec ToolOutput(false, "", "cancelado")
      val url = args.optString("url")
      if (!url.startsWith("http")) return@ToolSpec ToolOutput(false, "", "URL inválida: $url")
      withContext(Dispatchers.IO) {
        val r = httpGet(url, args.optInt("max_chars", 8000))
        ToolOutput(r.optBoolean("ok"), r.toString(), r.optString("error").takeIf { it.isNotEmpty() && it != "null" })
      }
    },

    ToolSpec(
      ToolDef(
        "web_search",
        "Busca en la web (DuckDuckGo) y devuelve títulos, URLs y snippets.",
        Schema.obj("query" to "string", "max_results" to "number", required = listOf("query"))
      ),
      group = "Web"
    ) { args, ctx ->
      if (ctx.cancelled) return@ToolSpec ToolOutput(false, "", "cancelado")
      withContext(Dispatchers.IO) {
        val r = search(args.optString("query"), args.optInt("max_results", 6))
        ToolOutput(r.optBoolean("ok"), r.toString(), r.optString("error").takeIf { it.isNotEmpty() && it != "null" })
      }
    }
  )

  private fun htmlToText(html: String): String = html
    .replace(Regex("(?is)<(script|style|noscript|svg)[^>]*>.*?</\\1>"), " ")
    .replace(Regex("(?i)<br\\s*/?>"), "\n")
    .replace(Regex("(?i)</(p|div|li|h[1-6]|tr)>"), "\n")
    .replace(Regex("<[^>]+>"), " ")
    .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")
    .replace(Regex("[ \\t]{2,}"), " ")
    .replace(Regex("\n{3,}"), "\n\n")
    .trim()

  private fun clean(s: String): String = htmlToText(s).replace(Regex("\\s+"), " ").trim()
}
