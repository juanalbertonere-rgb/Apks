package com.example.agent.tools

import com.example.agent.core.ToolContext
import com.example.agent.core.ToolDef
import com.example.agent.core.ToolOutput
import com.example.agent.core.ToolSpec
import com.example.data.db.FactDao
import com.example.data.db.FactEntity
import org.json.JSONObject

const val SCOPE_GLOBAL = "global"

/** Herramientas de memoria del agente (personal global + bitácora por chat). */
object MemoryTools {

  fun specs(facts: FactDao, conversationId: () -> String): List<ToolSpec> = listOf(
    ToolSpec(
      ToolDef(
        "memory_save_fact",
        "Guarda un hecho breve sobre EL USUARIO o sus preferencias para recordarlo en TODOS los chats (ej: user:name=John, user:pref=respuestas cortas).",
        Schema.obj("key" to "string", "value" to "string", required = listOf("key", "value"))
      ),
      group = "Memoria"
    ) { args, _ ->
      val key = args.optString("key").trim()
      val value = args.optString("value").trim()
      if (key.isEmpty()) return@ToolSpec ToolOutput(false, "", "key vacía")
      val existing = facts.find(SCOPE_GLOBAL, key)
      facts.upsert(FactEntity(scope = SCOPE_GLOBAL, key = key, value = value))
      ToolOutput(true, if (existing != null) "Actualizado: $key=$value" else "Guardado: $key=$value")
    },

    ToolSpec(
      ToolDef("memory_list_facts", "Lista todos los hechos guardados sobre el usuario.", Schema.obj()),
      group = "Memoria"
    ) { _, _ ->
      val list = facts.listByScope(SCOPE_GLOBAL)
      if (list.isEmpty()) ToolOutput(true, "(memoria vacía — aún no has guardado ningún hecho)")
      else ToolOutput(true, list.joinToString("\n") { "- ${it.key}: ${it.value}" })
    },

    ToolSpec(
      ToolDef("memory_delete_fact", "Olvida un hecho específico del usuario por su key.", Schema.obj("key" to "string", required = listOf("key"))),
      group = "Memoria"
    ) { args, _ ->
      facts.delete(SCOPE_GLOBAL, args.optString("key"))
      ToolOutput(true, "Eliminado: ${args.optString("key")}")
    },

    // ─── Bitácora del proyecto/chat ───
    ToolSpec(
      ToolDef(
        "project_memory_save",
        "Guarda una entrada en la bitácora de ESTE chat: qué se hizo, qué falta, decisiones. Claves útiles: hecho:*, pendiente:*, decision:*, objetivo.",
        Schema.obj("key" to "string", "value" to "string", required = listOf("key", "value"))
      ),
      group = "Bitácora del chat"
    ) { args, _ ->
      val key = args.optString("key").trim()
      if (key.isEmpty()) return@ToolSpec ToolOutput(false, "", "key vacía")
      facts.upsert(FactEntity(scope = conversationId(), key = key, value = args.optString("value")))
      ToolOutput(true, "Bitácora actualizada: ${key}")
    },

    ToolSpec(
      ToolDef("project_memory_list", "Lista la bitácora de trabajo de este chat.", Schema.obj()),
      group = "Bitácora del chat"
    ) { _, ctx: ToolContext ->
      val list = facts.listByScope(conversationId())
      if (list.isEmpty()) ToolOutput(true, "(bitácora vacía)")
      else ToolOutput(true, list.joinToString("\n") { "- ${it.key}: ${it.value}" })
    },

    ToolSpec(
      ToolDef("project_memory_delete", "Elimina una entrada de la bitácora de este chat.", Schema.obj("key" to "string", required = listOf("key"))),
      group = "Bitácora del chat"
    ) { args, _ ->
      facts.delete(conversationId(), args.optString("key"))
      ToolOutput(true, "Eliminado de la bitácora: ${args.optString("key")}")
    }
  )
}
