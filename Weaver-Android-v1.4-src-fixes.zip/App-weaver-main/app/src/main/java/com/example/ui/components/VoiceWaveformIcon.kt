package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ChatGptVoiceBlue

/**
 * Signature ChatGPT Voice Mode button with audio waveform bars.
 */
@Composable
fun VoiceWaveformButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  size: Dp = 40.dp,
  isLive: Boolean = false
) {
  val infiniteTransition = rememberInfiniteTransition(label = "waveform")
  val bar1Scale by infiniteTransition.animateFloat(
    initialValue = 0.5f,
    targetValue = if (isLive) 1.2f else 0.5f,
    animationSpec = infiniteRepeatable(
      animation = tween(400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "bar1"
  )
  val bar2Scale by infiniteTransition.animateFloat(
    initialValue = 0.9f,
    targetValue = if (isLive) 1.4f else 0.9f,
    animationSpec = infiniteRepeatable(
      animation = tween(500, delayMillis = 100, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "bar2"
  )
  val bar3Scale by infiniteTransition.animateFloat(
    initialValue = 0.7f,
    targetValue = if (isLive) 1.3f else 0.7f,
    animationSpec = infiniteRepeatable(
      animation = tween(450, delayMillis = 200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "bar3"
  )
  val bar4Scale by infiniteTransition.animateFloat(
    initialValue = 0.4f,
    targetValue = if (isLive) 1.0f else 0.4f,
    animationSpec = infiniteRepeatable(
      animation = tween(380, delayMillis = 50, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "bar4"
  )

  Box(
    modifier = modifier
      .size(size)
      .clip(CircleShape)
      .background(ChatGptVoiceBlue)
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically
    ) {
      WaveBar(height = 10.dp * bar1Scale)
      Spacer(modifier = Modifier.width(2.5.dp))
      WaveBar(height = 16.dp * bar2Scale)
      Spacer(modifier = Modifier.width(2.5.dp))
      WaveBar(height = 13.dp * bar3Scale)
      Spacer(modifier = Modifier.width(2.5.dp))
      WaveBar(height = 8.dp * bar4Scale)
    }
  }
}

@Composable
private fun WaveBar(height: Dp) {
  Box(
    modifier = Modifier
      .width(2.5.dp)
      .height(height)
      .clip(RoundedCornerShape(2.dp))
      .background(Color.White)
  )
}
