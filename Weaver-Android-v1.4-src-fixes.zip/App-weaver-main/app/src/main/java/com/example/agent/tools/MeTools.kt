package com.example.agent.tools

import com.example.agent.core.ToolDef
import com.example.agent.core.ToolOutput
import com.example.agent.core.ToolSpec
import com.example.data.db.MeDao
import com.example.data.db.MeItemEntity
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Sección "MI" del usuario: notas, tareas, eventos de calendario, lista de la
 * compra y notebooks. Persistidos en Room y visibles en las pantallas
 * Complementos / Agenda / Notebooks de la app.
 */
object MeTools {

  fun specs(meDao: MeDao): List<ToolSpec> = listOf(
    ToolSpec(
      ToolDef(
        "me_create_note",
        "Crea una NOTA en MI del usuario (sus notas personales, no tu memoria). Opcionalmente dentro de un notebook.",
        Schema.obj("title" to "string", "detail" to "string", "notebook" to "string", required = listOf("title"))
      ),
      group = "MI del usuario"
    ) { args, _ ->
      val item = MeItemEntity(
        id = UUID.randomUUID().toString(),
        kind = "note",
        title = args.optString("title"),
        detail = args.optString("detail", "")
      )
      meDao.upsert(item)
      val nb = args.optString("notebook", "")
      if (nb.isNotBlank()) meDao.upsert(MeItemEntity(UUID.randomUUID().toString(), "notebook", nb, "Contiene: ${item.title}"))
      ToolOutput(true, "Nota creada: ${item.title}")
    },

    ToolSpec(
      ToolDef(
        "me_create_task",
        "Crea una TAREA en MI del usuario. due ISO opcional ('2026-09-20T18:00').",
        Schema.obj("title" to "string", "due" to "string", "detail" to "string", required = listOf("title"))
      ),
      group = "MI del usuario"
    ) { args, _ ->
      val due = parseIso(args.optString("due", ""))
      val item = MeItemEntity(
        id = UUID.randomUUID().toString(),
        kind = "task",
        title = args.optString("title"),
        detail = args.optString("detail", ""),
        dueAt = due
      )
      meDao.upsert(item)
      ToolOutput(true, "Tarea creada: ${item.title}" + (if (due != null) " (para ${format(due)})" else ""))
    },

    ToolSpec(
      ToolDef(
        "me_create_event",
        "Crea un EVENTO en el calendario MI del usuario. due ISO requerido ('2026-09-20T20:00').",
        Schema.obj("title" to "string", "due" to "string", "detail" to "string", required = listOf("title", "due"))
      ),
      group = "MI del usuario"
    ) { args, _ ->
      val due = parseIso(args.optString("due", ""))
        ?: return@ToolSpec ToolOutput(false, "", "Formato de fecha inválido; usa ISO como 2026-09-20T20:00")
      val item = MeItemEntity(
        id = UUID.randomUUID().toString(),
        kind = "event",
        title = args.optString("title"),
        detail = args.optString("detail", ""),
        dueAt = due
      )
      meDao.upsert(item)
      ToolOutput(true, "Evento creado: ${item.title} — ${format(due)}")
    },

    ToolSpec(
      ToolDef("me_add_shopping", "Agrega un artículo a la LISTA DE LA COMPRA de MI del usuario.", Schema.obj("item" to "string", "qty" to "string", required = listOf("item"))),
      group = "MI del usuario"
    ) { args, _ ->
      val item = args.optString("item")
      val qty = args.optString("qty", "")
      meDao.upsert(
        MeItemEntity(
          id = UUID.randomUUID().toString(),
          kind = "shopping",
          title = item,
          detail = qty
        )
      )
      ToolOutput(true, "Añadido a la lista: $item${if (qty.isNotBlank()) " (x$qty)" else ""}")
    },

    ToolSpec(
      ToolDef(
        "me_list",
        "Lista los elementos de MI del usuario por tipo: 'note', 'task', 'event', 'shopping' o 'all'.",
        Schema.enumObj("kind" to "string", enums = mapOf("kind" to listOf("note", "task", "event", "shopping", "all")), required = listOf("kind"))
      ),
      group = "MI del usuario"
    ) { args, _ ->
      val all = meDao.listAll()
      val kind = args.optString("kind", "all")
      val filtered = if (kind == "all") all else all.filter { it.kind == kind }
      if (filtered.isEmpty()) return@ToolSpec ToolOutput(true, "(vacío)")
      val sdf = SimpleDateFormat("dd MMM yyyy HH:mm", Locale("es"))
      ToolOutput(
        true,
        filtered.take(50).joinToString("\n") {
          val whenS = it.dueAt?.let { d -> " — ${sdf.format(Date(d))}" } ?: ""
          val done = if (it.done) " [hecho]" else ""
          "- [${it.kind}] ${it.title}$done$whenS" + (if (it.detail.isNotBlank()) " — ${it.detail.take(80)}" else "")
        }
      )
    },

    ToolSpec(
      ToolDef("me_complete_task", "Marca una tarea de MI como hecha (match por texto del título).", Schema.obj("title" to "string", required = listOf("title"))),
      group = "MI del usuario"
    ) { args, _ ->
      val q = args.optString("title").lowercase()
      val all = meDao.listAll()
      val task = all.firstOrNull { it.kind == "task" && it.title.lowercase().contains(q) }
        ?: return@ToolSpec ToolOutput(false, "", "No encontré la tarea '${args.optString("title")}'")
      meDao.update(task.copy(done = true, updatedAt = System.currentTimeMillis()))
      ToolOutput(true, "Tarea completada: ${task.title}")
    },

    ToolSpec(
      ToolDef("me_delete_item", "Elimina un elemento de MI (nota/tarea/evento/artículo) por texto del título.", Schema.obj("title" to "string", required = listOf("title"))),
      group = "MI del usuario",
      destructive = true
    ) { args, _ ->
      val q = args.optString("title").lowercase()
      val all = meDao.listAll()
      val item = all.firstOrNull { it.title.lowercase().contains(q) }
        ?: return@ToolSpec ToolOutput(false, "", "No encontré '${args.optString("title")}'")
      meDao.delete(item.id)
      ToolOutput(true, "Eliminado: ${item.title}")
    }
  )

  private fun parseIso(s: String): Long? {
    if (s.isBlank()) return null
    return try {
      val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US)
      fmt.parse(s)?.time
    } catch (_: Exception) {
      try {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s)?.time
      } catch (_: Exception) {
        null
      }
    }
  }

  private fun format(ms: Long): String =
    SimpleDateFormat("dd MMM yyyy HH:mm", Locale("es")).format(Date(ms))
}
