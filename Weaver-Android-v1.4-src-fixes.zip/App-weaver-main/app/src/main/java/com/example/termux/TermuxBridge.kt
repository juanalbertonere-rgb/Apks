package com.example.termux

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Puente Weaver ↔ Termux.
 *
 * Ejecuta comandos reales de Linux en el dispositivo vía el servicio
 * RunCommandService de Termux (sin root, sin red) y recupera la salida
 * mediante archivos de intercambio en /sdcard/Weaver/intercambio:
 *
 *   1. La app lanza: sh -c '<cmd> > out.txt 2> err.txt; echo $? > code.txt'
 *   2. Termux ejecuta en segundo plano (RUN_COMMAND_BACKGROUND=true)
 *   3. La app hace polling de code.txt (hasta timeout) y lee out/err
 *   4. Limpia los archivos de intercambio y devuelve el JSON de resultado
 *
 * Requisitos documentados en README:
 *  - Permiso RUN_COMMAND concedido a la app (App info → Permisos)
 *  - Termux con almacenamiento: `termux-setup-storage`
 *  - /sdcard/Weaver accesible (la app pide "Todos los archivos")
 */
object TermuxBridge {

  const val TERMUX_PACKAGE = "com.termux"
  const val TERMUX_RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
  const val ACTION_RUN_COMMAND = "com.termux.RUN_COMMAND"

  /** Carpeta de intercambio compartida app↔Termux. */
  fun exchangeDir(context: Context): File {
    val base = Environment.getExternalStorageDirectory()
    val dir = File(base, "Weaver/intercambio")
    if (!dir.exists()) dir.mkdirs()
    return dir
  }

  fun isTermuxInstalled(context: Context): Boolean = runCatching {
    context.packageManager.getPackageInfo(TERMUX_PACKAGE, 0)
  }.isSuccess

  fun isTermuxSupported(): Boolean = Build.VERSION.SDK_INT >= 24

  /**
   * Ejecuta un comando en Termux y espera su salida.
   *
   * @param command comando shell completo (se ejecuta con sh -c)
   * @param workDir directorio de trabajo dentro de Termux
   * @param timeoutMs tiempo máximo de espera del resultado
   */
  @Synchronized
  fun execute(
    context: Context,
    command: String,
    workDir: String = "/data/data/com.termux/files/home",
    timeoutMs: Long = 60_000
  ): JSONObject {
    if (!isTermuxInstalled(context)) {
      return JSONObject()
        .put("ok", false)
        .put("error", "Termux no está instalado. Instálalo desde F-Droid o GitHub (no Play Store) y concede el permiso RUN_COMMAND.")
    }

    val hasRunCommandPerm = context.checkSelfPermission("com.termux.permission.RUN_COMMAND") == android.content.pm.PackageManager.PERMISSION_GRANTED
    if (!hasRunCommandPerm) {
      return JSONObject()
        .put("ok", false)
        .put("error", "Falta el permiso RUN_COMMAND. Ajustes > Apps > Weaver > Permisos > RUN_COMMAND. Concedelo y reintenta.")
    }

    val dir = exchangeDir(context)
    val id = UUID.randomUUID().toString().replace("-", "").take(12)
    val outFile = File(dir, "out-$id.txt")
    val errFile = File(dir, "err-$id.txt")
    val codeFile = File(dir, "code-$id.txt")

    // Envolver: cd + comando + captura de salida/código.cd puede fallar si no existe → avisar.
    val safeWorkDir = workDir.replace("'", "'\\''")
    val safeCmd = command.replace("'", "'\\''")
    val wrapped = "cd '$safeWorkDir' 2>/dev/null || cd /data/data/com.termux/files/home; " +
      "{ $safeCmd; } > '${outFile.absolutePath}' 2> '${errFile.absolutePath}'; " +
      "echo \$? > '${codeFile.absolutePath}'"

    val intent = Intent().apply {
      setClassName(TERMUX_PACKAGE, TERMUX_RUN_COMMAND_SERVICE)
      action = ACTION_RUN_COMMAND
      putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/sh")
      putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", wrapped))
      putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
      putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
    }

    val started = try {
      if (Build.VERSION.SDK_INT >= 26) context.startService(intent) else context.startService(intent)
      true
    } catch (e: Exception) {
      false
    }

    if (!started) {
      return JSONObject()
        .put("ok", false)
        .put("error", "No se pudo iniciar RunCommandService de Termux. Concede el permiso 'RUN_COMMAND' a Weaver (Ajustes → Apps → Weaver → Permisos) y asegúrate de que Termux está instalado.")
    }

    // Poll del código de salida.
    val deadline = System.currentTimeMillis() + timeoutMs
    var exitCode: Int? = null
    while (System.currentTimeMillis() < deadline) {
      if (codeFile.exists() && codeFile.length() > 0) {
        exitCode = codeFile.readText().trim().toIntOrNull()
        if (exitCode != null) break
      }
      Thread.sleep(350)
    }

    val stdout = if (outFile.exists()) outFile.readText() else ""
    val stderr = if (errFile.exists()) errFile.readText() else ""

    // Limpieza de los archivos de intercambio.
    runCatching { outFile.delete() }
    runCatching { errFile.delete() }
    runCatching { codeFile.delete() }

    if (exitCode == null) {
      return JSONObject()
        .put("ok", false)
        .put("error", "Termux no devolvio resultado en ${timeoutMs / 1000}s. Causa mas comun: falta allow-external-apps. En Termux ejecuta: mkdir -p ~/.termux && echo 'allow-external-apps=true' >> ~/.termux/termux.properties && termux-reload-settings; luego cierra y reabre Termux y reintenta. Verifica tambien: (1) permiso RUN_COMMAND en Ajustes > Apps > Weaver > Permisos, (2) abrir Termux al menos una vez para que instale su bootstrap. Si Termux mostro un reporte rojo 'Plugin Execution Command Error', ese es el motivo.")
        .put("hint", "Si el comando es largo, sube timeout_ms (max 300000).")
        .put("exitCode", JSONObject.NULL)
        .put("stdout", stdout.take(8000))
        .put("stderr", stderr.take(4000))
    }

    return JSONObject()
      .put("ok", exitCode == 0)
      .put("exitCode", exitCode)
      .put("stdout", stdout.take(8000))
      .put("stderr", stderr.take(4000))
  }

  /** Estado del puente para la pantalla de Ajustes. */
  fun status(context: Context): JSONObject {
    val installed = isTermuxInstalled(context)
    val dir = exchangeDir(context)
    return JSONObject()
      .put("installed", installed)
      .put("exchangeDir", dir.absolutePath)
      .put("exchangeWritable", dir.canWrite() || dir.exists())
  }

  /** Abre el intent implícito para que el usuario instale/conceda permisos a Termux. */
  fun openTermuxApp(context: Context) {
    runCatching {
      val intent = context.packageManager.getLaunchIntentForPackage(TERMUX_PACKAGE)
      intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
    }.onFailure {
      runCatching {
        context.startActivity(
          Intent(Intent.ACTION_VIEW, Uri.parse("https://f-droid.org/en/packages/com.termux/"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
      }
    }
  }
}
