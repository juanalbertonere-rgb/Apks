package com.example.agent.tools

import com.example.agent.core.ToolDef
import com.example.agent.core.ToolSpec
import org.json.JSONArray
import org.json.JSONObject

object AskUserTool {

  /**
   * Tool de PAUSA: cuando el modelo la invoca, el runner termina la sesión con
   * status awaiting_user_input, la UI dibuja el widget interactivo y, al
   * responder el usuario, se relanza la sesión con historial completo.
   * El handler nunca se ejecuta (igual que en el agente de PC).
   */
  fun spec(): ToolSpec {
    val parameters = JSONObject()
      .put("type", "object")
      .put("properties", JSONObject()
        .put("question", JSONObject().put("type", "string").put("description", "Pregunta clara y corta para el usuario"))
        .put("options", JSONObject().put("type", "array")
          .put("items", JSONObject().put("type", "string"))
          .put("description", "2 a 5 opciones concisas para elegir"))
        .put("allow_custom", JSONObject().put("type", "boolean").put("description", "Si true, permite respuesta libre además de las opciones")))
      .put("required", JSONArray(listOf("question", "options")))

    return ToolSpec(
      ToolDef(
        "ask_user_input",
        "Haz una pregunta interactiva al usuario con un widget de opciones en el chat. Úsala cuando necesites una decisión o preferencia del usuario para continuar (ej: elegir entre 2 enfoques, confirmar una acción irreversible). NO la uses si ya tienes suficiente contexto para actuar.",
        parameters
      ),
      group = "Interacción",
      handler = { _, _ ->
        // Nunca se ejecuta: es una tool de pausa gestionada por AgentRunner.
        com.example.agent.core.ToolOutput(false, "", "ask_user_input es una tool de pausa — no debería despacharse")
      }
    )
  }
}
