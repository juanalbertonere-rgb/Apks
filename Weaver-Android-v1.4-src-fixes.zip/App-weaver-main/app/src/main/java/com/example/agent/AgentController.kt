package com.example.agent

import android.content.Context
import com.example.agent.core.AgentEvent
import com.example.agent.core.AgentRunner
import com.example.agent.core.LMessage
import com.example.agent.core.LToolCall
import com.example.agent.core.LlmApi
import com.example.agent.core.Prompts
import com.example.agent.core.SessionState
import com.example.agent.core.ToolRegistry
import com.example.agent.provider.LlmClient
import com.example.agent.tools.AskUserTool
import com.example.agent.tools.AndroidTools
import com.example.agent.tools.MeTools
import com.example.agent.tools.MemoryTools
import com.example.agent.tools.McpHttpClient
import com.example.agent.tools.McpTools
import com.example.agent.tools.SCOPE_GLOBAL
import com.example.agent.tools.TermuxTools
import com.example.agent.tools.WebTools
import com.example.data.Settings
import com.example.data.db.ConversationEntity
import com.example.data.db.MessageEntity
import com.example.data.db.WeaverDb
import com.example.sync.PcBridgeClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Cerebro del agente Weaver Android — el pegamento entre la UI, Room y el
 * bucle ReAct. Reproduce la arquitectura del agente de PC:
 *
 *  - Cada mensaje del usuario arranca una sesión nueva (SessionState fresco)
 *    con el historial real de la conversación inyectado (sin amnesia).
 *  - ask_user_input pausa la sesión: la UI muestra el widget y al responder se
 *    relanza la sesión incorporando la respuesta como mensaje tool + historial
 *    (el mismo fix de reanudación del agente de PC).
 *  - Modo PC: delega el turno al bridge de la PC vía PcBridgeClient con el
 *    mismo canal de eventos para la UI.
 */
class AgentController(
  private val context: Context,
  private val scope: CoroutineScope
) {

  private val settings = Settings(context)
  private val db = WeaverDb.get(context)

  private val _events = MutableSharedFlow<AgentEvent>(extraBufferCapacity = 256)
  val events: SharedFlow<AgentEvent> = _events

  /** Estado visible de la última sesión (para diagnósticos en UI). */
  private val _busy = MutableStateFlow(false)
  val busy: StateFlow<Boolean> = _busy

  private var runJob: Job? = null
  private val cancelFlag = AtomicBoolean(false)
  /** Última pausa pendiente (tool_call de ask_user_input esperando respuesta). */
  private var pendingPause: LToolCall? = null

  // ───────────────────────────── Registry ──────────────────────────────────

  private suspend fun buildRegistry(conversationId: String): ToolRegistry {
    val registry = ToolRegistry()
    registry.registerAll(AndroidTools.specs(context))
    registry.registerAll(TermuxTools.specs(context))
    registry.registerAll(MemoryTools.specs(db.facts(), { conversationId }))
    registry.registerAll(MeTools.specs(db.meItems()))
    registry.registerAll(WebTools.specs())
    registry.register(AskUserTool.spec())

    // Servidores MCP habilitados → sus tools entran al registry.
    val servers = settings.mcpServers
    for (i in 0 until servers.length()) {
      val s = servers.optJSONObject(i) ?: continue
      if (!s.optBoolean("enabled", true)) continue
      val client = McpHttpClient(
        id = s.optString("id"),
        name = s.optString("name", s.optString("id")),
        url = s.optString("url")
      )
      registry.registerAll(withContext(Dispatchers.IO) { McpTools.discover(client) })
    }
    return registry
  }

  private suspend fun buildSystemPrompt(conversationId: String): String {
    val mem = db.facts().listByScope(SCOPE_GLOBAL)
      .takeLast(30)
      .joinToString("\n") { "- ${it.key}: ${it.value}" }
      .ifEmpty { "(memoria vacía)" }
    val proj = db.facts().listByScope(conversationId)
      .takeLast(20)
      .joinToString("\n") { "- ${it.key}: ${it.value}" }
      .ifEmpty { "(bitácora vacía — primer trabajo en este chat)" }
    return Prompts.build(
      registry = buildRegistry(conversationId),
      persona = "Eres ${settings.agentCallingName}, el agente personal del usuario.",
      memoryContext = mem,
      projectMemoryContext = proj,
      modes = Prompts.Modes(settings.planMode, settings.pursueMode),
      target = settings.executionTarget,
      agentName = settings.agentCallingName,
      userLanguage = settings.preferredLanguage
    )
  }

  // ──────────────────────────── Persistencia ───────────────────────────────

  private suspend fun nextSeq(conversationId: String): Long =
    (db.messages().maxSeq(conversationId) ?: 0L) + 1L

  private suspend fun saveMessage(
    conversationId: String,
    role: String,
    content: String?,
    toolCalls: List<LToolCall> = emptyList(),
    toolCallId: String? = null,
    toolName: String? = null,
    reasoning: String? = null
  ): MessageEntity {
    val e = MessageEntity(
      id = UUID.randomUUID().toString(),
      conversationId = conversationId,
      role = role,
      content = content,
      toolCallsJson = if (toolCalls.isEmpty()) null else org.json.JSONArray().apply {
        toolCalls.forEach { put(it.toJson()) }
      }.toString(),
      toolCallId = toolCallId,
      toolName = toolName,
      reasoning = reasoning,
      seq = nextSeq(conversationId)
    )
    db.messages().upsert(e)
    db.conversations().touch(conversationId, System.currentTimeMillis())
    return e
  }

  // ────────────────────────────── API pública ──────────────────────────────

  /** Mensaje del usuario → turno del agente (móvil o PC según ajustes). */
  fun sendMessage(conversationId: String, userText: String, titleFallback: String = "Nuevo chat") {
    if (_busy.value) return
    runJob = scope.launch {
      _busy.value = true
      cancelFlag.set(false)
      try {
        val conv = db.conversations().get(conversationId)
        if (conv == null) {
          db.conversations().upsert(ConversationEntity(conversationId, titleFallback, settings.executionTarget))
        }
        saveMessage(conversationId, "user", userText)

        if (settings.isTargetPc && settings.isPcPaired) {
          runOnPc(conversationId, userText)
        } else {
          runLocal(conversationId, userText)
        }
      } catch (e: kotlinx.coroutines.CancellationException) {
        // Cancelación normal (botón detener / ciclo de vida): NO es un error.
        // Re-lanzar para que el job muera limpio y nunca aparezca el texto
        // "StandaloneCoroutine was cancelled" como burbuja de error en el chat.
        throw e
      } catch (e: Exception) {
        _events.emit(AgentEvent.Finished("failed", e.message ?: "Error inesperado"))
      } finally {
        _busy.value = false
      }
    }
  }

  /** Respuesta del usuario al widget ask_user_input → reanudación con historial. */
  fun resumeAfterAskUser(conversationId: String, toolCallId: String, answer: String) {
    if (_busy.value) return
    runJob = scope.launch {
      _busy.value = true
      cancelFlag.set(false)
      try {
        // 1) Persistir la respuesta como mensaje tool (así queda en el historial).
        saveMessage(conversationId, "tool", answer, toolCallId = toolCallId, toolName = "ask_user_input")
        // 2) Reanudar SIN texto de usuario nuevo: el goal es una instrucción útil y
        //    el contexto real viaja en el historial (pregunta + tool call + respuesta).
        runLocal(conversationId, userText = "", isResume = true)
      } catch (e: kotlinx.coroutines.CancellationException) {
        // Misma lección: cancelar no es fallar.
        throw e
      } catch (e: Exception) {
        _events.emit(AgentEvent.Finished("failed", e.message ?: "Error al reanudar"))
      } finally {
        _busy.value = false
      }
    }
  }

  fun cancel() {
    cancelFlag.set(true)
    runJob?.cancel()
    _busy.value = false
  }

  // ─────────────────────────── Turno en el móvil ───────────────────────────

  private suspend fun runLocal(conversationId: String, userText: String, isResume: Boolean = false) {
    val registry = buildRegistry(conversationId)
    val systemPrompt = buildSystemPrompt(conversationId)

    // Historial real de la conversación (FIX anti-amnesia, espejo del PC):
    // todo MENOS el mensaje assistant vacío final si lo hubiera.
    val history = historyFromDb(conversationId)

    val goal = if (isResume) {
      "El usuario respondió a tu ask_user_input: su respuesta está en el historial como resultado de esa herramienta. Continúa la tarea original incorporando esa respuesta."
    } else userText

    val client = LlmClient(settings.providerBaseUrl, settings.providerApiKey.takeIf { settings.needsApiKey() }, settings.providerId)
    val runner = AgentRunner(
      llm = LlmClient.asApi(client),
      model = settings.providerModel,
      registry = registry,
      systemPrompt = systemPrompt,
      onEvent = { ev -> _events.emit(ev) },
      signal = cancelFlag
    )

    val state = SessionState(conversationId, goal)
    val result = runner.run(state, history)

    when (result.status) {
      "awaiting_user_input" -> {
        val lastRound = state.rounds.lastOrNull()
        val pause = lastRound?.toolCalls?.firstOrNull { it.call.name == "ask_user_input" }?.call
        if (pause != null) {
          pendingPause = pause
          // Persistir el assistant con el tool_call REAL para que la UI
          // (y futuros turnos) lo vean; el widget se dibuja desde aquí.
          saveMessage(conversationId, "assistant", result.state.rounds.lastOrNull()?.assistantText, toolCalls = listOf(pause))
        }
      }
      else -> {
        if (result.summary.isNotBlank()) {
          // El texto final ya llegó streaming a la UI; aquí solo persistimos.
          saveMessage(conversationId, "assistant", result.summary)
        }
      }
    }
  }

  /** Historial persistido → mensajes del protocolo (user/assistant+tool_calls/tool). */
  private suspend fun historyFromDb(conversationId: String): List<LMessage> {
    val rows = db.messages().list(conversationId)
    val out = mutableListOf<LMessage>()
    for (r in rows) {
      when (r.role) {
        "user" -> out.add(LMessage.user(r.content ?: ""))
        "assistant" -> {
          val calls = mutableListOf<LToolCall>()
          r.toolCallsJson?.let { raw ->
            runCatching {
              val arr = org.json.JSONArray(raw)
              for (i in 0 until arr.length()) {
                val tc = arr.optJSONObject(i) ?: continue
                val fn = tc.optJSONObject("function") ?: continue
                calls.add(LToolCall(tc.optString("id"), fn.optString("name"), fn.optString("arguments", "{}")))
              }
            }
          }
          if (r.content.isNullOrBlank() && calls.isEmpty()) continue // placeholder vacío
          out.add(LMessage.assistant(r.content, calls))
        }
        "tool" -> out.add(LMessage.tool(r.toolCallId ?: "", r.content ?: ""))
      }
    }
    // Sanitización (misma lección que el fix del PC): un assistant con
    // tool_calls debe ir seguido de sus tool results; si el usuario ignoró
    // el widget, se deshidratan para no romper la API.
    val sanitized = out.toMutableList()
    for (i in sanitized.indices) {
      val m = sanitized[i]
      if (m.role != "assistant" || m.toolCalls.isEmpty()) continue
      val answered = m.toolCalls.all { tc -> sanitized.drop(i + 1).any { it.role == "tool" && it.toolCallId == tc.id } }
      if (!answered) {
        val question = runCatching {
          m.toolCalls.first().parsedArgs().optString("question", "")
        }.getOrDefault("")
        sanitized[i] = LMessage.assistant(
          m.content?.takeIf { it.isNotBlank() }
            ?: "(Hiciste esta pregunta al usuario y quedó sin responder: \"$question\")"
        )
      }
    }
    return sanitized
  }

  // ─────────────────────────── Turno en la PC ──────────────────────────────

  private suspend fun runOnPc(conversationId: String, userText: String) {
    val bridge = PcBridgeClient(
      url = settings.pcBridgeUrl ?: return,
      token = settings.pcBridgeToken
    )
    try {
      val final = bridge.runAgent(userText) { ev -> _events.emit(ev) }
      if (final.isNotBlank()) saveMessage(conversationId, "assistant", final)
    } finally {
      bridge.close()
    }
  }

  /** Conecta un QR de bridge escaneado (weaver://bridge?host=&port=&token=&name=). */
  fun pairPcBridge(payload: String): Boolean {
    val uri = android.net.Uri.parse(payload)
    if (uri.scheme != "weaver" || !payload.contains("bridge")) return false
    val host = uri.getQueryParameter("host") ?: return false
    val port = uri.getQueryParameter("port") ?: "8787"
    val token = uri.getQueryParameter("token") ?: ""
    settings.pcBridgeUrl = "http://$host:$port"
    settings.pcBridgeToken = token
    settings.pcBridgeName = uri.getQueryParameter("name") ?: "PC"

    // Registro asíncrono en la PC: al escanear su QR, el teléfono se presenta
    // (POST /api/phone/register) para aparecer en "Teléfonos vinculados" y
    // permitir el sincronizado de chats en ambas direcciones.
    scope.launch {
      val pcUrl = settings.pcBridgeUrl ?: return@launch
      val pc = PcBridgeClient(pcUrl, settings.pcBridgeToken)
      pc.health() // verifica alcance (el resultado se refleja en el estado de la PC)
      val phoneUrl = if (settings.phoneServerEnabled) {
        val lan = com.example.sync.PhoneServer.lanAddress()
        if (lan != null) "http://$lan:${settings.phonePort}" else ""
      } else ""
      pc.registerPhone(
        deviceName = settings.deviceName,
        phoneUrl = phoneUrl,
        phoneToken = if (phoneUrl.isNotEmpty()) settings.phoneToken else ""
      )
    }
    return true
  }
}
