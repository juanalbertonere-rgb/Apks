package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
  @Query("SELECT * FROM conversations ORDER BY pinned DESC, updatedAt DESC")
  fun observeAll(): Flow<List<ConversationEntity>>

  @Query("SELECT * FROM conversations WHERE id = :id")
  suspend fun get(id: String): ConversationEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(conversation: ConversationEntity)

  @Query("UPDATE conversations SET title = :title, updatedAt = :updatedAt WHERE id = :id")
  suspend fun rename(id: String, title: String, updatedAt: Long)

  @Query("UPDATE conversations SET updatedAt = :updatedAt WHERE id = :id")
  suspend fun touch(id: String, updatedAt: Long)

  @Query("DELETE FROM conversations WHERE id = :id")
  suspend fun delete(id: String)

  @Query("SELECT COUNT(*) FROM conversations")
  suspend fun count(): Int
}

@Dao
interface MessageDao {
  @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY seq ASC")
  suspend fun list(conversationId: String): List<MessageEntity>

  @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY seq ASC")
  fun observe(conversationId: String): Flow<List<MessageEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(message: MessageEntity)

  @Query("SELECT * FROM messages WHERE id = :id")
  suspend fun get(id: String): MessageEntity?

  @Query("SELECT MAX(seq) FROM messages WHERE conversationId = :conversationId")
  suspend fun maxSeq(conversationId: String): Long?

  @Query("DELETE FROM messages WHERE conversationId = :conversationId")
  suspend fun deleteAllFor(conversationId: String)
}

@Dao
interface FactDao {
  @Query("SELECT * FROM facts WHERE scope = :scope ORDER BY rowId ASC")
  suspend fun listByScope(scope: String): List<FactEntity>

  @Query("SELECT * FROM facts WHERE scope = :scope ORDER BY rowId DESC LIMIT :limit")
  suspend fun recent(scope: String, limit: Int): List<FactEntity>

  @Query("SELECT * FROM facts WHERE scope = :scope AND `key` = :key LIMIT 1")
  suspend fun find(scope: String, key: String): FactEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(fact: FactEntity)

  @Query("DELETE FROM facts WHERE scope = :scope AND `key` = :key")
  suspend fun delete(scope: String, key: String)

  @Query("DELETE FROM facts WHERE scope = :scope")
  suspend fun deleteScope(scope: String)
}

@Dao
interface MeDao {
  @Query("SELECT * FROM me_items WHERE kind = :kind ORDER BY updatedAt DESC")
  fun observeByKind(kind: String): Flow<List<MeItemEntity>>

  @Query("SELECT * FROM me_items ORDER BY updatedAt DESC")
  suspend fun listAll(): List<MeItemEntity>

  @Query("SELECT * FROM me_items WHERE id = :id")
  suspend fun get(id: String): MeItemEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(item: MeItemEntity)

  @Update
  suspend fun update(item: MeItemEntity)

  @Query("DELETE FROM me_items WHERE id = :id")
  suspend fun delete(id: String)
}
