package com.example.ui.schedules

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChatGptBlack
import com.example.ui.theme.ChatGptBorderSubtle
import com.example.ui.theme.ChatGptDrawerBg
import com.example.ui.theme.ChatGptIconColor
import com.example.ui.theme.ChatGptIconMuted
import com.example.ui.theme.ChatGptInputBg
import com.example.ui.theme.ChatGptPillSelected
import com.example.ui.theme.ChatGptTextMuted
import com.example.ui.theme.ChatGptTextPrimary
import com.example.ui.theme.ChatGptTextSecondary

data class ScheduledTask(
  val id: String,
  var name: String,
  var scheduleTimeText: String,
  var instruction: String,
  var isActive: Boolean = true
)

@Composable
fun SchedulesScreen(
  onOpenDrawer: () -> Unit,
  onBackToChat: () -> Unit,
  viewModel: com.example.ui.chat.ChatViewModel? = null,
  modifier: Modifier = Modifier
) {
  // Datos REALES de Room (tabla me_items, kind = "schedule"). El programador
  // de ChatViewModel ejecuta estas tareas al llegar su hora.
  val scope = androidx.compose.runtime.rememberCoroutineScope()
  val dao = viewModel?.database?.meItems()
  val scheduledFlow = dao?.observeByKind("schedule")?.collectAsState(initial = emptyList())
  val tasks = remember(scheduledFlow?.value) {
    val list = scheduledFlow?.value ?: emptyList()
    androidx.compose.runtime.mutableStateListOf<ScheduledTask>().apply {
      addAll(list.map { e ->
        ScheduledTask(
          id = e.id,
          name = e.title,
          scheduleTimeText = (e.toolCallId ?: "once") + (e.dueAt?.let { " · próxima: ${java.text.SimpleDateFormat("dd MMM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(it))}" } ?: ""),
          instruction = e.detail,
          isActive = !e.done
        )
      })
    }
  }

  suspend fun createTask(name: String, scheduleText: String, instruction: String) {
    val d = dao ?: return
    val recurrence = parseRecurrence(scheduleText)
    val next = nextRun(recurrence)
    d.upsert(
      com.example.data.db.MeItemEntity(
        id = java.util.UUID.randomUUID().toString(),
        kind = "schedule",
        title = name,
        detail = instruction,
        dueAt = next,
        toolCallId = recurrence
      )
    )
  }

  suspend fun deleteTask(id: String) { dao?.delete(id) }

  suspend fun toggleTask(id: String, active: Boolean) {
    val d = dao ?: return
    d.get(id)?.let { d.update(it.copy(done = !active)) }
  }

  var showNewTaskDialog by remember { mutableStateOf(false) }
  var newTaskName by remember { mutableStateOf("") }
  var newTaskSchedule by remember { mutableStateOf("Cada día a las 08:00") }
  var newTaskInstruction by remember { mutableStateOf("") }

  Surface(
    modifier = modifier
      .fillMaxSize()
      .statusBarsPadding()
      .navigationBarsPadding(),
    color = ChatGptBlack
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
    ) {
      // Top Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = onOpenDrawer, modifier = Modifier.size(36.dp)) {
            Icon(imageVector = Icons.Default.Menu, contentDescription = "Menú", tint = ChatGptIconColor, modifier = Modifier.size(22.dp))
          }
          Spacer(modifier = Modifier.width(4.dp))
          IconButton(onClick = onBackToChat, modifier = Modifier.size(36.dp)) {
            Icon(imageVector = Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Volver", tint = ChatGptTextSecondary, modifier = Modifier.size(20.dp))
          }
        }
      }

      // Title matching Screenshot 7
      Text(
        text = "Schedules",
        fontSize = 26.sp,
        fontWeight = FontWeight.Bold,
        color = ChatGptTextPrimary
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "Crea tareas que el agente ejecutará automáticamente en el horario que elijas. El programador (cron) se ejecuta cuando Weaver está abierto. Al llegar la hora, se lanza la instrucción en un chat nuevo y el agente la procesa con las mismas herramientas que tendría a mano (MCPs, shell, archivos, web, ME calendario, etc.).",
        fontSize = 13.sp,
        color = ChatGptTextSecondary,
        lineHeight = 18.sp
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Button: + Nueva tarea
      Row(modifier = Modifier.fillMaxWidth()) {
        Button(
          onClick = { showNewTaskDialog = true },
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
          modifier = Modifier.height(36.dp)
        ) {
          Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("+ Nueva tarea", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
      HorizontalDivider(color = ChatGptBorderSubtle, thickness = 1.dp)
      Spacer(modifier = Modifier.height(14.dp))

      // Task items list
      LazyColumn(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(tasks) { task ->
          ScheduledTaskCard(
            task = task,
            onToggleActive = {
              scope.launch { toggleTask(task.id, task.isActive) }
            },
            onDelete = { scope.launch { deleteTask(task.id) } }
          )
        }

        item {
          Spacer(modifier = Modifier.height(8.dp))
          // Bottom informative card matching Screenshot 7
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(ChatGptInputBg)
              .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(12.dp))
              .padding(14.dp)
          ) {
            Row {
              Icon(imageVector = Icons.Outlined.Info, contentDescription = null, tint = ChatGptTextMuted, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "Nota: el programador (cron) se ejecuta cuando Weaver está abierto. Al llegar la hora, se lanza la instrucción en un chat nuevo y el agente la procesa con las mismas herramientas que tendría a mano (MCPs, shell, archivos, web, ME calendario, etc.). Para tareas que necesiten correr 24/7 sin la app abierta, configura un cron del sistema que llame a weaver --run \"instrucción\".",
                fontSize = 12.sp,
                color = ChatGptTextMuted,
                lineHeight = 17.sp
              )
            }
          }
          Spacer(modifier = Modifier.height(20.dp))
        }
      }
    }
  }

  // Create Task Dialog
  if (showNewTaskDialog) {
    AlertDialog(
      onDismissRequest = { showNewTaskDialog = false },
      containerColor = ChatGptDrawerBg,
      title = { Text("Nueva tarea programada", color = ChatGptTextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = newTaskName,
            onValueChange = { newTaskName = it },
            placeholder = { Text("Nombre de la tarea (ej. Resumen matutino)", color = ChatGptTextMuted, fontSize = 13.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = ChatGptInputBg,
              unfocusedContainerColor = ChatGptInputBg,
              focusedBorderColor = Color(0xFF3B82F6),
              unfocusedBorderColor = ChatGptBorderSubtle,
              focusedTextColor = ChatGptTextPrimary,
              unfocusedTextColor = ChatGptTextPrimary
            )
          )

          OutlinedTextField(
            value = newTaskSchedule,
            onValueChange = { newTaskSchedule = it },
            placeholder = { Text("Horario (ej. Cada día a las 08:00)", color = ChatGptTextMuted, fontSize = 13.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = ChatGptInputBg,
              unfocusedContainerColor = ChatGptInputBg,
              focusedBorderColor = Color(0xFF3B82F6),
              unfocusedBorderColor = ChatGptBorderSubtle,
              focusedTextColor = ChatGptTextPrimary,
              unfocusedTextColor = ChatGptTextPrimary
            )
          )

          OutlinedTextField(
            value = newTaskInstruction,
            onValueChange = { newTaskInstruction = it },
            placeholder = { Text("Instrucción para el agente...", color = ChatGptTextMuted, fontSize = 13.sp) },
            singleLine = false,
            maxLines = 3,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = ChatGptInputBg,
              unfocusedContainerColor = ChatGptInputBg,
              focusedBorderColor = Color(0xFF3B82F6),
              unfocusedBorderColor = ChatGptBorderSubtle,
              focusedTextColor = ChatGptTextPrimary,
              unfocusedTextColor = ChatGptTextPrimary
            )
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (newTaskName.isNotBlank() && newTaskInstruction.isNotBlank()) {
              scope.launch {
                createTask(newTaskName.trim(), newTaskSchedule, newTaskInstruction.trim())
              }
              newTaskName = ""
              newTaskInstruction = ""
              showNewTaskDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
        ) {
          Text("Crear tarea")
        }
      },
      dismissButton = {
        TextButton(onClick = { showNewTaskDialog = false }) {
          Text("Cancelar", color = ChatGptTextMuted)
        }
      }
    )
  }
}

@Composable
private fun ScheduledTaskCard(
  task: ScheduledTask,
  onToggleActive: () -> Unit,
  onDelete: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(ChatGptInputBg)
      .border(1.dp, ChatGptBorderSubtle, RoundedCornerShape(12.dp))
      .padding(14.dp)
  ) {
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = task.name,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = ChatGptTextPrimary
          )

          Spacer(modifier = Modifier.width(8.dp))

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(if (task.isActive) Color(0xFF064E3B) else Color(0xFF27272A))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = if (task.isActive) "Activa" else "Inactiva",
              fontSize = 10.sp,
              color = if (task.isActive) Color(0xFF34D399) else ChatGptTextMuted,
              fontWeight = FontWeight.Medium
            )
          }
        }

        // Right controls: Power, Settings, Trash
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(onClick = onToggleActive, modifier = Modifier.size(28.dp)) {
            Icon(
              imageVector = Icons.Default.PowerSettingsNew,
              contentDescription = "Activar/Desactivar",
              tint = if (task.isActive) Color(0xFF34D399) else ChatGptTextMuted,
              modifier = Modifier.size(16.dp)
            )
          }

          IconButton(onClick = { /* config */ }, modifier = Modifier.size(28.dp)) {
            Icon(
              imageVector = Icons.Outlined.Settings,
              contentDescription = "Configuración",
              tint = ChatGptTextMuted,
              modifier = Modifier.size(16.dp)
            )
          }

          IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
            Icon(
              imageVector = Icons.Default.DeleteOutline,
              contentDescription = "Eliminar",
              tint = Color(0xFFEF4444),
              modifier = Modifier.size(16.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = ChatGptTextMuted, modifier = Modifier.size(13.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = task.scheduleTimeText,
          fontSize = 12.sp,
          color = ChatGptTextMuted
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "Instrucción: ${task.instruction}",
        fontSize = 12.5.sp,
        color = ChatGptTextSecondary
      )
    }
  }
}

/** Parsea "Cada día a las HH:mm" → daily@HH:mm; "Una vez ..." → once; default daily@08:00. */
private fun parseRecurrence(scheduleText: String): String {
  val lower = scheduleText.lowercase()
  val time = Regex("(\\d{1,2})[:.](\\d{2})").find(lower)
  val hour = time?.groupValues?.get(1)?.toIntOrNull() ?: 8
  val minute = time?.groupValues?.get(2)?.toIntOrNull() ?: 0
  return if (lower.contains("una vez") || lower.contains("once")) "once" else "daily@%02d:%02d".format(hour, minute)
}

/** Próxima ejecución para una recurrencia daily@HH:mm / once (now + 1h). */
private fun nextRun(recurrence: String): Long? {
  return when {
    recurrence == "once" -> System.currentTimeMillis() + 60 * 60 * 1000
    recurrence.startsWith("daily@") -> {
      val parts = recurrence.removePrefix("daily@").split(":")
      val hour = parts.getOrNull(0)?.toIntOrNull() ?: 8
      val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
      java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, hour)
        set(java.util.Calendar.MINUTE, minute)
        set(java.util.Calendar.SECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
      }.timeInMillis
    }
    else -> null
  }
}
