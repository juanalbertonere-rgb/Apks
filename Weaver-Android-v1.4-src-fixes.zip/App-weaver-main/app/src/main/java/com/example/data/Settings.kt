package com.example.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Ajustes globales de Weaver Android.
 *
 * Extiende UserPreferences (onboarding) con todo lo que el agente necesita:
 *  - Proveedor LLM configurable (OpenRouter / OpenAI / Ollama / personalizado)
 *  - Objetivo de ejecución (MÓVIL = agente local Android, PC = bridge en la PC)
 *  - Modos del agente (plan, perseguir, memoria, bitácora)
 *  - Emparejamiento QR (payload del teléfono y del bridge PC)
 *  - Servidores MCP (HTTP streamable)
 *  - Estado del servidor HTTP local (para que la PC empuje tareas al móvil)
 */
class Settings(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("weaver_settings", Context.MODE_PRIVATE)

  // ────────────────────────────── Proveedor LLM ──────────────────────────────

  var providerId: String
    get() = prefs.getString(KEY_PROVIDER, PROVIDER_OPENROUTER) ?: PROVIDER_OPENROUTER
    set(value) = prefs.edit().putString(KEY_PROVIDER, value).apply()

  var providerBaseUrl: String
    get() = prefs.getString(KEY_BASE_URL, DEFAULT_BASE_URLS[providerId] ?: PROVIDER_OPENROUTER) ?: (DEFAULT_BASE_URLS[providerId] ?: "")
    set(value) = prefs.edit().putString(KEY_BASE_URL, value).apply()

  var providerApiKey: String
    get() = prefs.getString(KEY_API_KEY, "") ?: ""
    set(value) = prefs.edit().putString(KEY_API_KEY, value).apply()

  var providerModel: String
    get() = prefs.getString(KEY_MODEL, "openrouter/auto") ?: "openrouter/auto"
    set(value) = prefs.edit().putString(KEY_MODEL, value).apply()

  /** Ollama y otros servidores locales no llevan key; OpenRouter/OpenAI sí. */
  fun needsApiKey(): Boolean = providerId != PROVIDER_OLLAMA

  fun applyProviderPreset(provider: String) {
    providerId = provider
    DEFAULT_BASE_URLS[provider]?.let { providerBaseUrl = it }
  }

  // ────────────────────────── Objetivo de ejecución ──────────────────────────

  var executionTarget: String
    get() = prefs.getString(KEY_TARGET, TARGET_MOVIL) ?: TARGET_MOVIL
    set(value) = prefs.edit().putString(KEY_TARGET, value).apply()

  val isTargetPc: Boolean get() = executionTarget == TARGET_PC

  // ──────────────────────────── Modos del agente ─────────────────────────────

  var planMode: Boolean
    get() = prefs.getBoolean(KEY_PLAN_MODE, false)
    set(value) = prefs.edit().putBoolean(KEY_PLAN_MODE, value).apply()

  var pursueMode: Boolean
    get() = prefs.getBoolean(KEY_PURSUE_MODE, false)
    set(value) = prefs.edit().putBoolean(KEY_PURSUE_MODE, value).apply()

  var memoryMode: Boolean
    get() = prefs.getBoolean(KEY_MEMORY_MODE, true)
    set(value) = prefs.edit().putBoolean(KEY_MEMORY_MODE, value).apply()

  var projectMemoryMode: Boolean
    get() = prefs.getBoolean(KEY_PROJECT_MEMORY_MODE, true)
    set(value) = prefs.edit().putBoolean(KEY_PROJECT_MEMORY_MODE, value).apply()

  var ttsEnabled: Boolean
    get() = prefs.getBoolean(KEY_TTS_ENABLED, false)
    set(value) = prefs.edit().putBoolean(KEY_TTS_ENABLED, value).apply()

  // ─────────────────────────── Emparejamiento QR ─────────────────────────────

  /** Identidad de ESTE teléfono para el QR de emparejamiento. */
  var deviceId: String
    get() = prefs.getString(KEY_DEVICE_ID, null) ?: UUID.randomUUID().toString().also { deviceId = it }
    set(value) = prefs.edit().putString(KEY_DEVICE_ID, value).apply()

  var deviceName: String
    get() = prefs.getString(KEY_DEVICE_NAME, android.os.Build.MODEL) ?: android.os.Build.MODEL
    set(value) = prefs.edit().putString(KEY_DEVICE_NAME, value).apply()

  /** Token que la PC debe presentar al servidor HTTP del teléfono. */
  var phoneToken: String
    get() = prefs.getString(KEY_PHONE_TOKEN, null) ?: UUID.randomUUID().toString().replace("-", "").also { phoneToken = it }
    set(value) = prefs.edit().putString(KEY_PHONE_TOKEN, value).apply()

  /** Puerto del servidor HTTP local del teléfono (PC → móvil). */
  var phonePort: Int
    get() = prefs.getInt(KEY_PHONE_PORT, 8765)
    set(value) = prefs.edit().putInt(KEY_PHONE_PORT, value).apply()

  /** Si el servidor HTTP local acepta conexiones (PC → móvil). */
  var phoneServerEnabled: Boolean
    get() = prefs.getBoolean(KEY_PHONE_SERVER, false)
    set(value) = prefs.edit().putBoolean(KEY_PHONE_SERVER, value).apply()

  /** Config del bridge de la PC, obtenida al escanear su QR. */
  var pcBridgeUrl: String?
    get() = prefs.getString(KEY_PC_BRIDGE_URL, null)
    set(value) = prefs.edit().putString(KEY_PC_BRIDGE_URL, value).apply()

  var pcBridgeToken: String?
    get() = prefs.getString(KEY_PC_BRIDGE_TOKEN, null)
    set(value) = prefs.edit().putString(KEY_PC_BRIDGE_TOKEN, value).apply()

  var pcBridgeName: String?
    get() = prefs.getString(KEY_PC_BRIDGE_NAME, null)
    set(value) = prefs.edit().putString(KEY_PC_BRIDGE_NAME, value).apply()

  val isPcPaired: Boolean get() = !pcBridgeUrl.isNullOrBlank()

  // ──────────────────────────── Servidores MCP ───────────────────────────────

  /** Lista de servidores MCP: [{"id","name","url","enabled"}] */
  var mcpServers: JSONArray
    get() = runCatching { JSONArray(prefs.getString(KEY_MCP_SERVERS, "[]") ?: "[]") }.getOrDefault(JSONArray())
    set(value) = prefs.edit().putString(KEY_MCP_SERVERS, value.toString()).apply()

  fun upsertMcpServer(id: String, name: String, url: String, enabled: Boolean) {
    val arr = mcpServers
    val out = JSONArray()
    var found = false
    for (i in 0 until arr.length()) {
      val o = arr.optJSONObject(i) ?: continue
      if (o.optString("id") == id) {
        out.put(JSONObject().put("id", id).put("name", name).put("url", url).put("enabled", enabled))
        found = true
      } else out.put(o)
    }
    if (!found) out.put(JSONObject().put("id", id).put("name", name).put("url", url).put("enabled", enabled))
    mcpServers = out
  }

  fun removeMcpServer(id: String) {
    val arr = mcpServers
    val out = JSONArray()
    for (i in 0 until arr.length()) {
      val o = arr.optJSONObject(i) ?: continue
      if (o.optString("id") != id) out.put(o)
    }
    mcpServers = out
  }

  fun setMcpServerEnabled(id: String, enabled: Boolean) {
    val arr = mcpServers
    for (i in 0 until arr.length()) {
      val o = arr.optJSONObject(i) ?: continue
      if (o.optString("id") == id) o.put("enabled", enabled)
    }
    mcpServers = arr
  }

  // ──────────────────────────── Idioma / identidad ───────────────────────────

  var agentCallingName: String
    get() = prefs.getString(KEY_AGENT_NAME, "Weaver") ?: "Weaver"
    set(value) = prefs.edit().putString(KEY_AGENT_NAME, value).apply()

  var preferredLanguage: String
    get() = prefs.getString(KEY_LANG, "Español") ?: "Español"
    set(value) = prefs.edit().putString(KEY_LANG, value).apply()

  companion object {
    const val PROVIDER_OPENROUTER = "openrouter"
    const val PROVIDER_OPENAI = "openai"
    const val PROVIDER_OLLAMA = "ollama"
    const val PROVIDER_CUSTOM = "custom"

    val DEFAULT_BASE_URLS = mapOf(
      PROVIDER_OPENROUTER to "https://openrouter.ai/api/v1",
      PROVIDER_OPENAI to "https://api.openai.com/v1",
      PROVIDER_OLLAMA to "http://192.168.1.10:11434/v1"
    )

    const val TARGET_MOVIL = "movil"
    const val TARGET_PC = "pc"

    private const val KEY_PROVIDER = "provider_id"
    private const val KEY_BASE_URL = "provider_base_url"
    private const val KEY_API_KEY = "provider_api_key"
    private const val KEY_MODEL = "provider_model"
    private const val KEY_TARGET = "execution_target"
    private const val KEY_PLAN_MODE = "mode_plan"
    private const val KEY_PURSUE_MODE = "mode_pursue"
    private const val KEY_MEMORY_MODE = "mode_memory"
    private const val KEY_PROJECT_MEMORY_MODE = "mode_project_memory"
    private const val KEY_TTS_ENABLED = "tts_enabled"
    private const val KEY_DEVICE_ID = "device_id"
    private const val KEY_DEVICE_NAME = "device_name"
    private const val KEY_PHONE_TOKEN = "phone_token"
    private const val KEY_PHONE_PORT = "phone_port"
    private const val KEY_PHONE_SERVER = "phone_server_enabled"
    private const val KEY_PC_BRIDGE_URL = "pc_bridge_url"
    private const val KEY_PC_BRIDGE_TOKEN = "pc_bridge_token"
    private const val KEY_PC_BRIDGE_NAME = "pc_bridge_name"
    private const val KEY_MCP_SERVERS = "mcp_servers"
    private const val KEY_AGENT_NAME = "agent_calling_name"
    private const val KEY_LANG = "preferred_language"
  }
}
