package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ChatGptDotBlue
import com.example.ui.theme.ChatGptIconColor

/**
 * The signature ChatGPT drawer button:
 * Two horizontal rounded bars with a blue notification / status dot on the left.
 */
@Composable
fun CustomDrawerToggle(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  size: Dp = 40.dp
) {
  IconButton(
    onClick = onClick,
    modifier = modifier.size(size)
  ) {
    Canvas(modifier = Modifier.size(24.dp)) {
      val canvasWidth = this.size.width
      val canvasHeight = this.size.height

      // Blue dot on the left
      drawCircle(
        color = ChatGptDotBlue,
        radius = 3.5.dp.toPx(),
        center = Offset(x = 3.5.dp.toPx(), y = canvasHeight * 0.38f)
      )

      // Top horizontal line
      drawRoundRect(
        color = ChatGptIconColor,
        topLeft = Offset(x = 10.dp.toPx(), y = canvasHeight * 0.34f),
        size = Size(width = canvasWidth - 10.dp.toPx(), height = 2.4.dp.toPx()),
        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
      )

      // Bottom horizontal line
      drawRoundRect(
        color = ChatGptIconColor,
        topLeft = Offset(x = 0f, y = canvasHeight * 0.64f),
        size = Size(width = canvasWidth, height = 2.4.dp.toPx()),
        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
      )
    }
  }
}
