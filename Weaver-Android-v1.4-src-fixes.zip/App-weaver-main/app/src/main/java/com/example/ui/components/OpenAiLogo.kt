package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/**
 * Procedural vector rendering of the OpenAI ChatGPT spiral logo.
 * Consists of 6 interlocking rounded segments rotated by 60 degrees.
 */
@Composable
fun OpenAiLogo(
  modifier: Modifier = Modifier,
  size: Dp = 26.dp,
  color: Color = Color.White
) {
  Canvas(modifier = modifier.size(size)) {
    val center = Offset(this.size.width / 2f, this.size.height / 2f)
    val r = this.size.minDimension / 2f
    val strokeWidth = r * 0.16f

    // Draw 6 symmetrical petals
    for (i in 0 until 6) {
      rotate(degrees = i * 60f, pivot = center) {
        val path = Path().apply {
          // Loop segment coordinates scaled to radius r
          val startX = center.x + r * 0.05f
          val startY = center.y - r * 0.28f
          moveTo(startX, startY)
          
          lineTo(center.x + r * 0.52f, center.y - r * 0.55f)
          cubicTo(
            center.x + r * 0.85f, center.y - r * 0.38f,
            center.x + r * 0.88f, center.y + r * 0.15f,
            center.x + r * 0.60f, center.y + r * 0.32f
          )
          lineTo(center.x + r * 0.18f, center.y + r * 0.56f)
          cubicTo(
            center.x - r * 0.05f, center.y + r * 0.70f,
            center.x - r * 0.35f, center.y + r * 0.65f,
            center.x - r * 0.38f, center.y + r * 0.38f
          )
          lineTo(center.x - r * 0.38f, center.y + r * 0.05f)
        }
        drawPath(
          path = path,
          color = color,
          style = Stroke(
            width = strokeWidth,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
          )
        )
      }
    }
  }
}
