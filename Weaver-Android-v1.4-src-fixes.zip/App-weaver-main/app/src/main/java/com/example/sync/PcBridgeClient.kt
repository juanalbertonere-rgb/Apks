package com.example.sync

import com.example.agent.core.AgentEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Cliente del bridge de la PC (pc-bridge/weaver-bridge.mjs).
 *
 * Protocolo:
 *   POST /api/run  {prompt, token}
 *     → respuesta SSE con eventos JSON línea a línea:
 *         {"type":"text","delta":"..."}
 *         {"type":"tool_call","name":"...","args":{...}}
 *         {"type":"tool_result","name":"...","output":"...","ok":true}
 *         {"type":"final","text":"..."} | {"type":"error","message":"..."}
 *   GET  /health → {"ok":true}
 */
class PcBridgeClient(private val url: String, private val token: String?) {

  private val client = OkHttpClient.Builder()
    .connectTimeout(10, TimeUnit.SECONDS)
    .readTimeout(600, TimeUnit.SECONDS)
    .build()

  suspend fun health(): Boolean = withContext(Dispatchers.IO) {
    runCatching {
      client.newCall(Request.Builder().url(url.trimEnd('/') + "/health").build())
        .execute().use { it.isSuccessful }
    }.getOrDefault(false)
  }

  /**
   * Registra este teléfono en la PC tras escanear su QR
   * (POST /api/phone/register). Así la PC lo muestra en "Teléfonos
   * vinculados" y puede traer los chats del teléfono.
   */
  suspend fun registerPhone(deviceName: String, phoneUrl: String, phoneToken: String): Boolean =
    withContext(Dispatchers.IO) {
      runCatching {
        val body = JSONObject()
          .put("name", deviceName)
          .put("device", android.os.Build.MODEL)
          .put("url", phoneUrl)
          .put("token", phoneToken)
          .toString()
          .toRequestBody("application/json".toMediaType())
        val req = Request.Builder()
          .url(url.trimEnd('/') + "/api/phone/register")
          .header("Authorization", "Bearer ${token ?: ""}")
          .post(body)
          .build()
        client.newCall(req).execute().use { it.isSuccessful }
      }.getOrDefault(false)
    }

  /** GET /api/chats de la PC — devuelve el JSON ChatSync o null. */
  suspend fun fetchPcChats(): String? = withContext(Dispatchers.IO) {
    runCatching {
      val req = Request.Builder()
        .url(url.trimEnd('/') + "/api/chats")
        .header("Authorization", "Bearer ${token ?: ""}")
        .build()
      client.newCall(req).execute().use { resp ->
        if (!resp.isSuccessful) null else resp.body?.string()
      }
    }.getOrNull()
  }

  /** POST /api/chats/import a la PC — devuelve el número importado o -1. */
  suspend fun pushPcChats(json: String): Int = withContext(Dispatchers.IO) {
    runCatching {
      val body = json.toRequestBody("application/json".toMediaType())
      val req = Request.Builder()
        .url(url.trimEnd('/') + "/api/chats/import")
        .header("Authorization", "Bearer ${token ?: ""}")
        .post(body)
        .build()
      client.newCall(req).execute().use { resp ->
        if (!resp.isSuccessful) -1
        else {
          val text = resp.body?.string() ?: return@use -1
          runCatching { JSONObject(text).optInt("imported", -1) }.getOrDefault(-1)
        }
      }
    }.getOrDefault(-1)
  }

  /** Ejecuta un turno del agente EN la PC y emite eventos a la UI del móvil. */
  suspend fun runAgent(prompt: String, onEvent: suspend (AgentEvent) -> Unit): String =
    withContext(Dispatchers.IO) {
      val body = JSONObject()
        .put("prompt", prompt)
        .put("token", token ?: "")
        .toString()
        .toRequestBody("application/json".toMediaType())

      val req = Request.Builder()
        .url(url.trimEnd('/') + "/api/run")
        .post(body)
        .build()

      client.newCall(req).execute().use { resp ->
        if (!resp.isSuccessful) {
          val err = runCatching { resp.body?.string() }.getOrNull()
          val msg = runCatching { JSONObject(err).optString("error") }.getOrDefault("HTTP ${resp.code}")
          onEvent(AgentEvent.Finished("failed", "Bridge PC: $msg"))
          return@withContext ""
        }
        val source = resp.body?.source() ?: return@withContext ""
        val finalText = StringBuilder()
        while (true) {
          val line = source.readUtf8Line() ?: break
          if (!line.startsWith("data:")) continue
          val data = line.removePrefix("data:").trim()
          if (data.isEmpty() || data == "[DONE]") continue
          val ev = runCatching { JSONObject(data) }.getOrElse { continue }
          when (ev.optString("type")) {
            "text" -> onEvent(AgentEvent.TextDelta(ev.optString("delta")))
            "tool_call" -> onEvent(
              AgentEvent.ToolCallStarted(
                ev.optInt("round", 0),
                com.example.agent.core.LToolCall(
                  ev.optString("id", "pc"),
                  ev.optString("name"),
                  ev.optJSONObject("args")?.toString() ?: "{}"
                )
              )
            )
            "tool_result" -> onEvent(
              AgentEvent.ToolCallFinished(
                ev.optInt("round", 0),
                com.example.agent.core.LToolCall(ev.optString("id", "pc"), ev.optString("name"), "{}"),
                com.example.agent.core.ToolOutput(ev.optBoolean("ok", true), ev.optString("output"))
              )
            )
            "final" -> {
              finalText.append(ev.optString("text"))
              onEvent(AgentEvent.Finished("succeeded", ev.optString("text")))
            }
            "error" -> onEvent(AgentEvent.Finished("failed", ev.optString("message")))
          }
        }
        finalText.toString()
      }
    }

  fun close() {}
}
