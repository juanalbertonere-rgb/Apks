package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Ojos y manos del agente Weaver en Android.
 *
 * - Lee el árbol de accesibilidad de la ventana activa (screen_tree / screen_find)
 * - Ejecuta gestos reales: tap, long press, scroll, pinch-zoom (dispatchGesture)
 * - Escribe texto en campos editables (SET_TEXT con fallback a portapapeles+pegar)
 * - Pulsa teclas globales: atrás, home, recientes, notificaciones
 * - Screenshot (API 30+) cuando el usuario lo permite
 *
 * Mantiene estado mínimo: el último paquete/actividad vistos y el último screenshot.
 */
class WeaverAccessibilityService : AccessibilityService() {

  var lastPackage: String? = null
    private set
  var lastActivity: String? = null
    private set
  private var lastScreenshot: Bitmap? = null
  private val screenshotLock = Any()

  override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    if (event == null) return
    if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
      lastPackage = event.packageName?.toString() ?: lastPackage
      lastActivity = event.className?.toString() ?: lastActivity
    }
  }

  override fun onInterrupt() {}

  override fun onDestroy() {
    instance = null
    super.onDestroy()
  }

  override fun onServiceConnected() {
    super.onServiceConnected()
    instance = this
  }

  // ─────────────────────────────── Árbol UI ────────────────────────────────

  /** Espera activa a que la ventana activa exponga su arbol de accesibilidad (tras open_app tarda 0.5-3s). */
  fun awaitRoot(maxAttempts: Int = 12, delayMs: Long = 350): AccessibilityNodeInfo? {
    for (i in 0 until maxAttempts) {
      val r = rootInActiveWindow
      if (r != null) return r
      try { Thread.sleep(delayMs) } catch (_: InterruptedException) { Thread.currentThread().interrupt(); break }
    }
    return rootInActiveWindow
  }

  fun windowInfo(): JSONObject {
    val o = JSONObject()
    o.put("package", lastPackage ?: "")
    o.put("activity", lastActivity ?: "")
    return o
  }

  /** Serializa el árbol de la ventana activa con límites de profundidad/nodos. */
  fun readTree(maxDepth: Int = 12, maxNodes: Int = 400): JSONObject {
    val root = awaitRoot()
      ?: return JSONObject()
        .put("ok", false)
        .put("error", "La ventana aun no es accesible (cambiando de app?). Espera un momento y vuelve a llamar screen_tree.")
        .put("package", lastPackage ?: "")
        .put("activity", lastActivity ?: "")
        .put("nodeCount", 0)
        .put("nodes", JSONArray())
    val out = windowInfo()
    out.put("ok", true)
    val nodes = JSONArray()
    var count = 0

    fun walk(node: AccessibilityNodeInfo?, depth: Int) {
      if (node == null || depth > maxDepth || count >= maxNodes) return
      count++
      val bounds = Rect()
      node.getBoundsInScreen(bounds)
      val n = JSONObject()
        .put("i", count - 1)
        .put("cls", node.className?.toString() ?: "")
        .put("text", node.text?.toString()?.take(120) ?: "")
        .put("desc", node.contentDescription?.toString()?.take(120) ?: "")
        .put("id", node.viewIdResourceName?.takeLast(60) ?: "")
        .put("clickable", node.isClickable)
        .put("scrollable", node.isScrollable)
        .put("editable", node.isEditable)
        .put("enabled", node.isEnabled)
        .put("bounds", "[${bounds.left},${bounds.top}][${bounds.right},${bounds.bottom}]")
        .put("cx", bounds.centerX())
        .put("cy", bounds.centerY())
      val kids = JSONArray()
      for (i in 0 until node.childCount) kids.put(i)
      // marcado de posición para navegación estable
      n.put("childCount", node.childCount)
      n.put("children", kids)
      nodes.put(n)
      for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1)
    }
    walk(root, 0)
    out.put("nodeCount", count)
    out.put("nodes", nodes)
    return out
  }

  /** Busca nodos por texto/desc/id/contención y devuelve matches con coords. */
  fun findNodes(query: JSONObject): JSONObject {
    val root = awaitRoot()
      ?: return JSONObject().put("ok", false).put("error", "No hay ventana activa accesible aun (espera un momento y reintenta)")
    val text = query.optString("text", "").lowercase()
    val idPart = query.optString("id", "").lowercase()
    val clsPart = query.optString("class", "").lowercase()
    val desc = query.optString("description", "").lowercase()
    val limit = query.optInt("limit", 12)

    val matches = JSONArray()
    val queue = ArrayDeque<AccessibilityNodeInfo>()
    queue.add(root)
    var visited = 0
    while (queue.isNotEmpty() && matches.length() < limit && visited < 1200) {
      val node = queue.removeFirstOrNull() ?: continue
      visited++
      for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
      val nText = node.text?.toString()?.lowercase() ?: ""
      val nDesc = node.contentDescription?.toString()?.lowercase() ?: ""
      val nId = node.viewIdResourceName?.lowercase() ?: ""
      val nCls = node.className?.toString()?.lowercase() ?: ""
      val hit = (text.isNotEmpty() && nText.contains(text)) ||
        (desc.isNotEmpty() && nDesc.contains(desc)) ||
        (idPart.isNotEmpty() && nId.contains(idPart)) ||
        (clsPart.isNotEmpty() && nCls.contains(clsPart))
      if (!hit) continue
      val bounds = Rect()
      node.getBoundsInScreen(bounds)
      matches.put(
        JSONObject()
          .put("text", node.text?.toString() ?: "")
          .put("desc", node.contentDescription?.toString() ?: "")
          .put("id", node.viewIdResourceName ?: "")
          .put("cls", node.className?.toString() ?: "")
          .put("clickable", node.isClickable)
          .put("editable", node.isEditable)
          .put("bounds", "[${bounds.left},${bounds.top}][${bounds.right},${bounds.bottom}]")
          .put("cx", bounds.centerX())
          .put("cy", bounds.centerY())
      )
    }
    return JSONObject()
      .put("ok", true)
      .put("package", lastPackage ?: JSONObject.NULL)
      .put("matches", matches)
      .put("visited", visited)
  }

  // ─────────────────────────────── Gestos ──────────────────────────────────

  private fun gestureStroke(path: Path, startTime: Long, duration: Long): GestureDescription.StrokeDescription =
    GestureDescription.StrokeDescription(path, startTime, duration)

  private fun dispatch(path: Path, durationMs: Long): Boolean {
    val builder = GestureDescription.Builder()
    builder.addStroke(gestureStroke(path, 0, durationMs))
    return dispatchGesture(builder.build(), null, null)
  }

  fun tap(x: Float, y: Float): Boolean {
    val p = Path().apply { moveTo(x, y); lineTo(x + 0.1f, y + 0.1f) }
    return dispatch(p, 60)
  }

  fun longClick(x: Float, y: Float): Boolean {
    val p = Path().apply { moveTo(x, y); lineTo(x + 0.1f, y + 0.1f) }
    return dispatch(p, 650)
  }

  /** Swipe vertical: positive = scroll hacia arriba (contenido baja), negative = abajo. */
  fun scroll(direction: String): Boolean {
    val metrics = resources.displayMetrics
    val cx = metrics.widthPixels / 2f
    val top = metrics.heightPixels * 0.68f
    val bottom = metrics.heightPixels * 0.32f
    val p = Path()
    when (direction.lowercase()) {
      "up", "arriba" -> { p.moveTo(cx, top); p.lineTo(cx, bottom) }
      "down", "abajo" -> { p.moveTo(cx, bottom); p.lineTo(cx, top) }
      "left", "izquierda" -> {
        val right = metrics.widthPixels * 0.75f; val left = metrics.widthPixels * 0.25f
        val cy = metrics.heightPixels / 2f
        p.moveTo(right, cy); p.lineTo(left, cy)
      }
      "right", "derecha" -> {
        val right = metrics.widthPixels * 0.75f; val left = metrics.widthPixels * 0.25f
        val cy = metrics.heightPixels / 2f
        p.moveTo(left, cy); p.lineTo(right, cy)
      }
      else -> return false
    }
    return dispatch(p, 350)
  }

  /** Pinch con dos dedos: "in" aleja dedos (zoom+), "out" los junta (zoom-). */
  fun pinch(centerX: Float, centerY: Float, mode: String): Boolean {
    val gapStart = 200f
    val gapEnd = 520f
    val (g1, g2) = if (mode == "in" || mode == "zoom_in") (gapStart to gapEnd) else (gapEnd to gapStart)
    val p1 = Path().apply { moveTo(centerX - g1, centerY); lineTo(centerX - g2, centerY) }
    val p2 = Path().apply { moveTo(centerX + g1, centerY); lineTo(centerX + g2, centerY) }
    val b = GestureDescription.Builder()
    b.addStroke(gestureStroke(p1, 0, 500))
    b.addStroke(gestureStroke(p2, 0, 500))
    return dispatchGesture(b.build(), null, null)
  }

  /** Swipe libre entre dos puntos (útil para arrastrar sliders, drawer, etc.). */
  fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 400): Boolean {
    val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
    return dispatch(p, durationMs)
  }

  // ─────────────────────────── Texto y teclas ──────────────────────────────

  /** Escribe texto en un nodo editable (SET_TEXT, fallback portapapeles+pegar). */
  fun typeInto(node: AccessibilityNodeInfo, text: String): Boolean {
    if (node.isEditable) {
      val args = Bundle().apply {
        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
      }
      if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true
    }
    node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("weaver", text))
    return node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
  }

  /** Busca el primer nodo editable (o por hint/texto) y escribe. */
  fun typeText(text: String, match: String?): JSONObject {
    val root = awaitRoot()
      ?: return JSONObject().put("ok", false).put("error", "No hay ventana activa accesible aun (espera un momento y reintenta)")
    var target: AccessibilityNodeInfo? = null
    val queue = ArrayDeque<AccessibilityNodeInfo>()
    queue.add(root)
    val matchLower = match?.lowercase()
    while (queue.isNotEmpty() && target == null) {
      val node = queue.removeFirstOrNull() ?: continue
      for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
      if (!node.isEditable) continue
      if (matchLower == null) { target = node; break }
      val nText = (node.text?.toString() ?: "").lowercase()
      val nHint = if (Build.VERSION.SDK_INT >= 26) node.hintText?.toString()?.lowercase() ?: "" else ""
      val nDesc = (node.contentDescription?.toString() ?: "").lowercase()
      if (nText.contains(matchLower) || nHint.contains(matchLower) || nDesc.contains(matchLower)) target = node
    }
    if (target == null) {
      return JSONObject().put("ok", false).put("error", if (match == null) "No encontré un campo editable" else "No encontré el campo '$match'")
    }
    val ok = typeInto(target, text)
    return JSONObject().put("ok", ok).put("typed", text)
      .put("field", target.viewIdResourceName ?: target.text?.toString() ?: "editable")
  }

  fun globalAction(action: Int): Boolean = performGlobalAction(action)

  // ───────────────────────────── Screenshot ────────────────────────────────

  /** Screenshot vía API de accesibilidad (Android 11+). Requiere que el usuario lo permita. */
  fun takeScreenshot(callback: (JSONObject) -> Unit) {
    if (Build.VERSION.SDK_INT < 30) {
      callback(JSONObject().put("ok", false).put("error", "Screenshot requiere Android 11+"))
      return
    }
    val directExecutor = java.util.concurrent.Executor { it.run() }
    takeScreenshot(
      android.view.Display.DEFAULT_DISPLAY,
      directExecutor,
      object : AccessibilityService.TakeScreenshotCallback {
        override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
          val bmp = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
          synchronized(screenshotLock) {
            lastScreenshot?.recycle()
            lastScreenshot = bmp?.copy(Bitmap.Config.ARGB_8888, false)
          }
          screenshot.hardwareBuffer.close()
          val dir = File(cacheDir, "screens").apply { mkdirs() }
          val f = File(dir, "screen_${System.currentTimeMillis()}.png")
          runCatching {
            FileOutputStream(f).use { fos -> lastScreenshot?.compress(Bitmap.CompressFormat.PNG, 70, fos) }
          }
          callback(JSONObject().put("ok", true).put("path", f.absolutePath).put("note", "Puedes describir la pantalla leyendo screen_tree; el PNG queda en el cache para depuración."))
        }
        override fun onFailure(errorCode: Int) {
          callback(JSONObject().put("ok", false).put("error", "Screenshot falló (código $errorCode). El usuario debe permitir capturas en el diálogo de accesibilidad."))
        }
      }
    )
  }

  companion object {
    @Volatile var instance: WeaverAccessibilityService? = null
      private set

    const val GLOBAL_BACK = AccessibilityService.GLOBAL_ACTION_BACK
    const val GLOBAL_HOME = AccessibilityService.GLOBAL_ACTION_HOME
    const val GLOBAL_RECENTS = AccessibilityService.GLOBAL_ACTION_RECENTS
    const val GLOBAL_NOTIFICATIONS = AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
    const val GLOBAL_QUICK_SETTINGS = AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS

    val isRunning: Boolean get() = instance != null
  }
}
