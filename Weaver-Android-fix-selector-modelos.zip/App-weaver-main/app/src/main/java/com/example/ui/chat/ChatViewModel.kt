package com.example.ui.chat

import android.app.Application
import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Bolt
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.agent.AgentController
import com.example.agent.core.AgentEvent
import com.example.agent.provider.LlmClient
import com.example.data.Settings
import com.example.data.db.MessageEntity
import com.example.data.db.WeaverDb
import com.example.ui.components.ModelOption
import com.example.ui.components.RecentChat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

/**
 * Un elemento del chat. kind:
 *  - "text"     → burbuja normal
 *  - "tool"     → fila compacta de tool call/resultado
 *  - "ask_user" → widget interactivo de ask_user_input
 */
data class ChatMessage(
  val id: String = UUID.randomUUID().toString(),
  val isUser: Boolean,
  val text: String,
  val timestamp: Long = System.currentTimeMillis(),
  val kind: String = "text",
  val toolName: String? = null,
  val toolArgs: JSONObject? = null,
  val toolOk: Boolean? = null,
  val toolCallId: String? = null,
  val question: String? = null,
  val options: List<String> = emptyList(),
  val allowCustom: Boolean = false,
  val answered: Boolean = false,
  val selectedAnswer: String? = null,
  val reasoning: String? = null
)

data class ChatUiState(
  val currentChatTitle: String = "Nuevo chat",
  val selectedChatId: String = "new_chat",
  val messages: List<ChatMessage> = emptyList(),
  val inputText: String = "",
  val activeContextTag: String? = null,
  /** Solo es el valor ANTES del init; init lo sincroniza con settings.providerModel. */
  val selectedModel: ModelOption = ModelOption(
    id = "openrouter/auto",
    name = "auto",
    description = "openrouter/auto",
    icon = Icons.Outlined.AutoAwesome,
    vendor = "openrouter"
  ),
  val isPursueActive: Boolean = false,
  val isMemoryActive: Boolean = true,
  val isLogActive: Boolean = false,
  val isGenerating: Boolean = false,
  val showModelSelector: Boolean = false,
  val showVoiceMode: Boolean = false,
  val showOfferDialog: Boolean = false,
  val showAttachmentSheet: Boolean = false,
  /** Móvil / PC — selector superior. */
  val deviceSegmentMode: com.example.ui.components.DeviceSegmentMode = com.example.ui.components.DeviceSegmentMode.MOVIL,
  /** Actividad en vivo del agente ("ejecutando shell_exec…", tool calls…). */
  val liveActivity: String? = null,
  /** Modelos reales del proveedor (cache de /models). */
  val providerModels: List<ModelOption> = emptyList(),
  val providerConfigured: Boolean = true,
  val providerError: String? = null,
  /** Cargando /models del proveedor (spinner en el selector del chat). */
  val modelsLoading: Boolean = false,
  /** Error del último listado de modelos (null = sin error). */
  val modelsError: String? = null
)

val defaultSuggestions = listOf(
  "Abre WhatsApp y dile a mamá que llego bien",
  "Busca en internet las últimas noticias de IA y haz un resumen",
  "Ejecuta en Termux: uname -a y df -h",
  "En MI, apunta una nota: ideas para la web de Weaver"
)

class ChatViewModel(private val app: Application) : ViewModel() {

  val settings = Settings(app)
  private val db = WeaverDb.get(app)
  internal val database: WeaverDb get() = db
  val agentController = AgentController(app, viewModelScope)

  private var tts: TextToSpeech? = null
  private var ttsReady = false

  private val _recentChats = MutableStateFlow<List<RecentChat>>(emptyList())
  val recentChats: StateFlow<List<RecentChat>> = _recentChats.asStateFlow()

  private val _uiState = MutableStateFlow(ChatUiState())
  val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

  // Mensaje en streaming (no persistido todavía).
  private var streamingId: String? = null
  private val streamingText = StringBuilder()
  private val streamingReasoning = StringBuilder()

  init {
    observeConversations()
    observeAgentEvents()
    initTts()
    refreshProviderState()
    syncSelectedModelFromSettings()
    startScheduler()
  }

  // ─────────────────── Modelos del proveedor (selector del chat) ───────────────────

  /** "OpenAI: GPT-4o mini (chat)" → ("OpenAI", "GPT-4o mini"). */
  private fun splitVendorLabel(label: String): Pair<String, String> {
    val idx = label.indexOf(": ")
    return if (idx > 0) label.substring(0, idx).trim() to label.substring(idx + 2).trim()
    else "" to label.trim()
  }

  /** Vendor visible: del nombre, del id (openai/gpt-4o → openai) o del proveedor. */
  private fun vendorOf(id: String, label: String): String {
    splitVendorLabel(label).first.takeIf { it.isNotBlank() }?.let { return it }
    val prefix = id.substringBefore('/').trim()
    return if (prefix.isNotBlank() && prefix != id) prefix else settings.providerId
  }

  /** Nombre limpio SIN vendor ni sufijos entre paréntesis. */
  private fun modelDisplayName(id: String, label: String): String {
    val raw = splitVendorLabel(label).second
    return raw.substringBefore(" (").trim().ifBlank { id.substringAfter('/').ifBlank { id } }
  }

  /** Modelo configurado como opción de respaldo (cuando /models falla). */
  private fun currentConfiguredOption(): ModelOption = ModelOption(
    id = settings.providerModel,
    name = modelDisplayName(settings.providerModel, ""),
    description = "modelo configurado",
    icon = Icons.Outlined.Bolt,
    vendor = vendorOf(settings.providerModel, "")
  )

  /** La píldora del chat muestra SIEMPRE el modelo realmente configurado. */
  private fun syncSelectedModelFromSettings() {
    val id = settings.providerModel
    val fromCache = _uiState.value.providerModels.firstOrNull { it.id == id }
    val option = fromCache ?: ModelOption(
      id = id,
      name = modelDisplayName(id, ""),
      description = id,
      icon = Icons.Outlined.Bolt,
      vendor = vendorOf(id, "")
    )
    _uiState.value = _uiState.value.copy(selectedModel = option)
  }

  /**
   * Programador REAL de tareas (pantalla Schedules): cada minuto revisa las
   * tareas agendadas en Room y, al llegar su hora, lanza la instrucción del
   * agente en un chat nuevo con las mismas herramientas del chat normal.
   * Recurrencia guardada en toolCallId: "daily@HH:mm" | "once".
   */
  private fun startScheduler() {
    viewModelScope.launch {
      while (isActive) {
        kotlinx.coroutines.delay(60_000)
        runCatching {
          val now = System.currentTimeMillis()
          val due = db.meItems().listAll().filter {
            it.kind == "schedule" && !it.done && (it.dueAt ?: Long.MAX_VALUE) <= now
          }
          for (task in due) {
            val recurrence = task.toolCallId ?: "once"
            val next = nextOccurrence(recurrence, task.dueAt ?: now)
            if (next == null) {
              db.meItems().update(task.copy(done = true))
            } else {
              db.meItems().update(task.copy(dueAt = next))
            }
            val convId = UUID.randomUUID().toString()
            db.conversations().upsert(
              com.example.data.db.ConversationEntity(
                id = convId,
                title = task.title,
                target = settings.executionTarget
              )
            )
            agentController.sendMessage(convId, task.detail.ifBlank { task.title }, titleFallback = task.title)
          }
        }
      }
    }
  }

  private fun nextOccurrence(recurrence: String, previous: Long): Long? {
    return when {
      recurrence == "once" -> null
      recurrence.startsWith("daily@") -> {
        val parts = recurrence.removePrefix("daily@").split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: 8
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        java.util.Calendar.getInstance().apply {
          timeInMillis = previous + 24L * 60 * 60 * 1000
          set(java.util.Calendar.HOUR_OF_DAY, hour)
          set(java.util.Calendar.MINUTE, minute)
          set(java.util.Calendar.SECOND, 0)
        }.timeInMillis
      }
      else -> null
    }
  }

  private fun refreshProviderState() {
    val configured = !settings.needsApiKey() || settings.providerApiKey.isNotBlank()
    _uiState.value = _uiState.value.copy(
      providerConfigured = configured,
      deviceSegmentMode = if (settings.executionTarget == Settings.TARGET_PC)
        com.example.ui.components.DeviceSegmentMode.PC
      else com.example.ui.components.DeviceSegmentMode.MOVIL,
      isPursueActive = settings.pursueMode,
      isMemoryActive = settings.memoryMode
    )
  }

  private fun initTts() {
    if (!settings.ttsEnabled) return
    tts = TextToSpeech(app) { status ->
      ttsReady = status == TextToSpeech.SUCCESS
      if (ttsReady) tts?.language = Locale.getDefault()
    }
  }

  private fun observeConversations() {
    viewModelScope.launch {
      db.conversations().observeAll().collect { list ->
        _recentChats.value = list.map { RecentChat(it.id, it.title) }
        if (_uiState.value.selectedChatId != "new_chat" && list.none { it.id == _uiState.value.selectedChatId } && list.isNotEmpty()) {
          // La conversación activa desapareció (import/limpieza): volver al inicio.
          loadConversation(list.first().id, list.first().title)
        }
      }
    }
  }

  private fun observeAgentEvents() {
    viewModelScope.launch {
      agentController.events.collect { ev ->
        when (ev) {
          is AgentEvent.TextDelta -> appendStreaming(ev.delta)
          is AgentEvent.ReasoningDelta -> appendReasoning(ev.delta)
          is AgentEvent.ThinkingDuration -> {}
          is AgentEvent.ToolCallStarted -> setLiveActivity("▶ ${ev.call.name} ${formatArgs(ev.call)}")
          is AgentEvent.ToolCallFinished -> {
            val label = "✓ ${ev.call.name}: ${ev.result.output.take(120)}${if (ev.result.output.length > 120) "…" else ""}"
            appendToolLine(ev.call.name, ev.result.ok, label)
            setLiveActivity(null)
          }
          is AgentEvent.AwaitingUserInput -> {
            val args = ev.args
            flushStreamingAsAskUser(ev.call.id, args)
            _uiState.value = _uiState.value.copy(isGenerating = false, liveActivity = null)
          }
          is AgentEvent.Finished -> {
            // El texto final ya se llevó streaming; si es distinto al streaming
            // (p.ej. resumen tras RESULT), persistimos vía DB.
            finishStreaming(ev)
            _uiState.value = _uiState.value.copy(isGenerating = false, liveActivity = null)
          }
          is AgentEvent.RoundFinished -> {}
        }
      }
    }
  }

  private fun formatArgs(call: com.example.agent.core.LToolCall): String {
    val args = call.parsedArgs()
    val interesting = listOf("query", "command", "app_name", "question", "text", "url", "match", "direction")
    for (k in interesting) {
      val v = args.optString(k, "")
      if (v.isNotEmpty()) return "\"${v.take(40)}\""
    }
    return ""
  }

  private fun appendStreaming(delta: String) {
    ensureStreamingMessage()
    streamingText.append(delta)
    rebuildStreamingMessage()
  }

  private fun appendReasoning(delta: String) {
    ensureStreamingMessage()
    streamingReasoning.append(delta)
    rebuildStreamingMessage()
  }

  private fun appendToolLine(name: String, ok: Boolean, label: String) {
    val list = _uiState.value.messages.toMutableList()
    list.add(
      ChatMessage(
        id = UUID.randomUUID().toString(),
        isUser = false,
        text = label,
        kind = "tool",
        toolName = name,
        toolOk = ok
      )
    )
    _uiState.value = _uiState.value.copy(messages = list)
  }

  private fun setLiveActivity(activity: String?) {
    _uiState.value = _uiState.value.copy(liveActivity = activity)
  }

  private fun ensureStreamingMessage() {
    if (streamingId == null) {
      streamingId = UUID.randomUUID().toString()
      streamingText.clear()
      streamingReasoning.clear()
      val list = _uiState.value.messages.toMutableList()
      list.add(ChatMessage(id = streamingId!!, isUser = false, text = "", reasoning = null))
      _uiState.value = _uiState.value.copy(messages = list)
    }
  }

  private fun rebuildStreamingMessage() {
    val id = streamingId ?: return
    val list = _uiState.value.messages.toMutableList()
    val idx = list.indexOfFirst { it.id == id }
    if (idx >= 0) {
      list[idx] = list[idx].copy(
        text = streamingText.toString(),
        reasoning = streamingReasoning.toString().takeIf { it.isNotBlank() }
      )
      _uiState.value = _uiState.value.copy(messages = list)
    }
  }

  private fun flushStreamingAsAskUser(toolCallId: String, args: org.json.JSONObject) {
    val id = streamingId
    streamingId = null
    val list = _uiState.value.messages.toMutableList()
    val idx = if (id != null) list.indexOfFirst { it.id == id } else -1
    val options = mutableListOf<String>()
    args.optJSONArray("options")?.let { arr ->
      for (i in 0 until arr.length()) arr.optString(i, null)?.let { options.add(it) }
    }
    val ask = ChatMessage(
      id = id ?: UUID.randomUUID().toString(),
      isUser = false,
      text = args.optString("question", ""),
      kind = "ask_user",
      toolCallId = toolCallId,
      question = args.optString("question", ""),
      options = options,
      allowCustom = args.optBoolean("allow_custom", true),
      reasoning = if (idx >= 0) list[idx].reasoning else null
    )
    if (idx >= 0) list[idx] = ask else list.add(ask)
    _uiState.value = _uiState.value.copy(messages = list)
  }

  private suspend fun finishStreaming(ev: AgentEvent.Finished) {
    val id = streamingId
    streamingId = null
    val list = _uiState.value.messages.toMutableList()
    val idx = if (id != null) list.indexOfFirst { it.id == id } else -1

    if (ev.status == "awaiting_user_input") return // el widget ya se dibujó

    if (ev.status == "failed" || ev.status == "stuck") {
      val msg = ev.summary
      if (idx >= 0) {
        list[idx] = list[idx].copy(text = streamingText.toString().ifBlank { msg })
      } else {
        list.add(ChatMessage(isUser = false, text = "⚠️ $msg"))
      }
      _uiState.value = _uiState.value.copy(messages = list, providerError = if (ev.status == "failed") msg else null)
      return
    }

    // succeeded: la DB ya recibió el assistant persistido por el controller;
    // el flujo de DB se recargará vía loadConversation. Actualización inmediata:
    if (idx >= 0) {
      list[idx] = list[idx].copy(text = streamingText.toString().ifBlank { ev.summary })
      _uiState.value = _uiState.value.copy(messages = list)
    }
    speakIfEnabled(streamingText.toString().ifBlank { ev.summary })
  }

  private fun speakIfEnabled(text: String) {
    if (!settings.ttsEnabled || !ttsReady || text.isBlank()) return
    val clean = text.replace(Regex("[*#`>\\[\\]]"), "").take(600)
    tts?.speak(clean, TextToSpeech.QUEUE_ADD, null, "weaver_${System.currentTimeMillis()}")
  }

  // ─────────────────────────── Carga de chats ──────────────────────────────

  private suspend fun loadConversation(id: String, title: String) {
    val rows = db.messages().list(id)
    _uiState.value = _uiState.value.copy(
      selectedChatId = id,
      currentChatTitle = title,
      messages = rows.map { mapEntity(it, rows) },
      inputText = "",
      liveActivity = null
    )
  }

  private fun mapEntity(m: MessageEntity, allRows: List<MessageEntity>): ChatMessage {
    return when (m.role) {
      "user" -> ChatMessage(id = m.id, isUser = true, text = m.content ?: "")
      "tool" -> ChatMessage(
        id = m.id, isUser = false, text = m.content ?: "", kind = "tool",
        toolName = m.toolName ?: "respuesta", toolCallId = m.toolCallId, toolOk = true
      )
      "assistant" -> {
        // ¿Es un ask_user pendiente/contestado?
        val calls = m.toolCallsJson?.let { raw ->
          runCatching { org.json.JSONArray(raw) }.getOrNull()
        }
        val askCall = calls?.optJSONObject(0)?.takeIf { it.optJSONObject("function")?.optString("name") == "ask_user_input" }
        if (askCall != null) {
          val args = runCatching { askCall.optJSONObject("function")?.optString("arguments", "{}") }
            .getOrNull()?.let { runCatching { org.json.JSONObject(it) }.getOrNull() } ?: org.json.JSONObject()
          val opts = mutableListOf<String>()
          args.optJSONArray("options")?.let { arr -> for (i in 0 until arr.length()) arr.optString(i, null)?.let { opts.add(it) } }
          val answeredMsg = allRows.firstOrNull { it.role == "tool" && it.toolCallId == askCall.optString("id") }
          ChatMessage(
            id = m.id, isUser = false, text = args.optString("question", ""), kind = "ask_user",
            toolCallId = askCall.optString("id"),
            question = args.optString("question", ""),
            options = opts,
            allowCustom = args.optBoolean("allow_custom", true),
            answered = answeredMsg != null,
            selectedAnswer = answeredMsg?.content,
            reasoning = m.reasoning
          )
        } else if (calls != null && calls.length() > 0) {
          ChatMessage(id = m.id, isUser = false, text = m.content ?: "", kind = "tool", toolName = "tool_call", toolOk = true)
        } else {
          ChatMessage(id = m.id, isUser = false, text = m.content ?: "", reasoning = m.reasoning)
        }
      }
      else -> ChatMessage(id = m.id, isUser = false, text = m.content ?: "")
    }
  }

  // ────────────────────────────── Acciones UI ──────────────────────────────

  fun onInputTextChanged(newText: String) {
    _uiState.value = _uiState.value.copy(inputText = newText)
  }

  fun removeContextTag() {
    _uiState.value = _uiState.value.copy(activeContextTag = null)
  }

  fun setContextTag(tag: String) {
    _uiState.value = _uiState.value.copy(activeContextTag = tag)
  }

  fun togglePursue() {
    settings.pursueMode = !settings.pursueMode
    _uiState.value = _uiState.value.copy(isPursueActive = settings.pursueMode)
  }

  fun toggleMemory() {
    settings.memoryMode = !settings.memoryMode
    _uiState.value = _uiState.value.copy(isMemoryActive = settings.memoryMode)
  }

  fun toggleLog() {
    _uiState.value = _uiState.value.copy(isLogActive = !_uiState.value.isLogActive)
  }

  fun selectModel(model: ModelOption) {
    settings.providerModel = model.id
    _uiState.value = _uiState.value.copy(selectedModel = model, showModelSelector = false)
  }

  fun toggleModelSelector(show: Boolean) {
    _uiState.value = _uiState.value.copy(showModelSelector = show)
    if (show && (_uiState.value.providerModels.isEmpty() || _uiState.value.modelsError != null)) {
      fetchProviderModels(force = true)
    }
  }

  fun retryFetchModels() = fetchProviderModels(force = true)

  /** Guarda la API key desde el selector del chat y recarga los modelos. */
  fun saveApiKeyAndReload(key: String) {
    val k = key.trim()
    if (k.isEmpty()) return
    settings.providerApiKey = k
    _uiState.value = _uiState.value.copy(providerConfigured = true, modelsError = null)
    fetchProviderModels(force = true)
  }

  private fun fetchProviderModels(force: Boolean = false) {
    if (_uiState.value.modelsLoading) return
    if (!force && _uiState.value.providerModels.isNotEmpty() && _uiState.value.modelsError == null) return
    _uiState.value = _uiState.value.copy(modelsLoading = true, modelsError = null)
    viewModelScope.launch {
      try {
        val client = LlmClient(
          settings.providerBaseUrl,
          settings.providerApiKey.takeIf { settings.needsApiKey() },
          settings.providerId
        )
        val models = client.listModels()
        val options = models.map { (id, label) ->
          ModelOption(
            id = id,
            name = modelDisplayName(id, label),
            description = id,
            icon = Icons.Outlined.AutoAwesome,
            vendor = vendorOf(id, label)
          )
        }.sortedBy { it.name.lowercase() }
        if (options.isEmpty()) {
          _uiState.value = _uiState.value.copy(
            modelsLoading = false,
            modelsError = "El proveedor no devolvió modelos",
            providerModels = listOf(currentConfiguredOption())
          )
        } else {
          _uiState.value = _uiState.value.copy(
            providerModels = options,
            modelsLoading = false,
            modelsError = null,
            providerConfigured = true
          )
          syncSelectedModelFromSettings()
        }
      } catch (ce: kotlinx.coroutines.CancellationException) {
        throw ce // nunca convertir cancelación en error
      } catch (e: Exception) {
        val raw = (e as? LlmClient.LlmException)?.message ?: e.message ?: "Error listando modelos"
        val authIssue = raw.contains("401") || raw.contains("403") ||
          raw.contains("auth", ignoreCase = true) || raw.contains("api key", ignoreCase = true) ||
          raw.contains("api_key", ignoreCase = true)
        _uiState.value = _uiState.value.copy(
          modelsLoading = false,
          modelsError = if (authIssue) "$raw — revisa tu API key" else raw,
          providerModels = listOf(currentConfiguredOption())
        )
      }
    }
  }

  fun toggleVoiceMode(show: Boolean) {
    _uiState.value = _uiState.value.copy(showVoiceMode = show)
  }

  fun toggleOfferDialog(show: Boolean) {
    _uiState.value = _uiState.value.copy(showOfferDialog = show)
  }

  fun toggleAttachmentSheet(show: Boolean) {
    _uiState.value = _uiState.value.copy(showAttachmentSheet = show)
  }

  fun setDeviceSegmentMode(mode: com.example.ui.components.DeviceSegmentMode) {
    val target = if (mode == com.example.ui.components.DeviceSegmentMode.PC) Settings.TARGET_PC else Settings.TARGET_MOVIL
    settings.executionTarget = target
    _uiState.value = _uiState.value.copy(deviceSegmentMode = mode)
  }

  fun startNewChat() {
    _uiState.value = _uiState.value.copy(
      currentChatTitle = "Nuevo chat",
      selectedChatId = "new_chat",
      messages = emptyList(),
      inputText = "",
      activeContextTag = null,
      providerError = null
    )
  }

  fun selectChat(chat: RecentChat) {
    viewModelScope.launch {
      loadConversation(chat.id, chat.title)
    }
  }

  fun sendSuggestion(suggestion: String) {
    _uiState.value = _uiState.value.copy(inputText = suggestion)
    sendMessage()
  }

  fun sendMessage() {
    val text = _uiState.value.inputText.trim()
    if (text.isEmpty() || _uiState.value.isGenerating) return

    if (!settings.needsApiKey() || settings.providerApiKey.isNotBlank()) {
      val convId = ensureConversation(text)
      _uiState.value = _uiState.value.copy(
        inputText = "",
        isGenerating = true,
        providerError = null,
        selectedChatId = convId
      )
      streamingId = null
      // Optimista: burbuja del usuario inmediata.
      _uiState.value = _uiState.value.copy(
        messages = _uiState.value.messages + ChatMessage(isUser = true, text = text)
      )
      agentController.sendMessage(convId, text, titleFallback = text.take(40))
    } else {
      _uiState.value = _uiState.value.copy(
        messages = _uiState.value.messages + listOf(
          ChatMessage(isUser = true, text = text),
          ChatMessage(
            isUser = false,
            text = "Para funcionar necesito un proveedor LLM. Ve al **Drawer → Ajustes** y configura tu API key (OpenRouter, OpenAI, Ollama o personalizado)."
          )
        ),
        inputText = ""
      )
    }
  }

  /** Respuesta al widget ask_user_input (opción, texto libre u omitir). */
  fun submitAskUser(toolCallId: String, answer: String) {
    if (_uiState.value.isGenerating) return
    val convId = _uiState.value.selectedChatId.ifEmpty { "new_chat" }
    // Burbuja de la elección del usuario + limpiar pendiente.
    val list = _uiState.value.messages.map { m ->
      if (m.kind == "ask_user" && m.toolCallId == toolCallId) m.copy(answered = true, selectedAnswer = answer) else m
    } + ChatMessage(isUser = true, text = if (answer.startsWith("El usuario omitió")) "(omitido)" else answer)
    _uiState.value = _uiState.value.copy(messages = list, isGenerating = true)
    agentController.resumeAfterAskUser(convId, toolCallId, answer)
  }

  fun cancelGeneration() {
    agentController.cancel()
    _uiState.value = _uiState.value.copy(isGenerating = false, liveActivity = null)
  }

  /** Texto dictado por voz → caja de texto o envío directo. */
  fun onVoiceInput(text: String, sendDirectly: Boolean) {
    if (sendDirectly) {
      _uiState.value = _uiState.value.copy(inputText = text)
      sendMessage()
    } else {
      _uiState.value = _uiState.value.copy(inputText = text)
    }
  }

  private fun ensureConversation(firstMessage: String): String {
    var id = _uiState.value.selectedChatId
    if (id == "new_chat" || id.isEmpty()) {
      id = UUID.randomUUID().toString()
      val title = firstMessage.take(40).ifBlank { "Nuevo chat" }
      viewModelScope.launch {
        db.conversations().upsert(
          com.example.data.db.ConversationEntity(id = id, title = title, target = settings.executionTarget)
        )
      }
      _uiState.value = _uiState.value.copy(currentChatTitle = title)
    }
    return id
  }

  fun refreshConversations() {
    observeConversations()
  }

  class Factory(private val app: Application) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = ChatViewModel(app) as T
  }
}
